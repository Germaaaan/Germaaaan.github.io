
<!doctype html>
<html lang="en">
<head>

    
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <base href="https://www.gessicon.com">
    <link href="favicon.png" rel="shortcut icon" type="image/x-icon"/>

    <!-- metas -->
            <title>Pisos en Orihuela | Inmobiliarias Orihuela | Promociones ...</title>
        <meta name="title" content="Pisos en Orihuela , Inmobiliarias Orihuela , Promociones ..." />
        <meta name="description" content="Promociones Apihogares S.l con multitud de propiedades, pisos , chalet , casas, villas en todas las zonas y localidades, incluyendo toda la provincia de Alic..." />
        <meta name="robots" content="noindex, nofollow" />        <meta name="keywords" content="Promociones Apihogares S.l, inmobiliaria, real estate, promociones , obra nueva, promotores, inmobilien, Alicante, pisos, casas, campo, chalet , property, villa, venta , spain , inmobiliarias, real state, costa , coast ,apartamento" />
        <meta name="author" content="www.inmovilla.com, inmovilla dise&ntilde;o web" />

                <meta property="og:title" content="Pisos en Orihuela , Inmobiliarias Orihuela , Promociones Apihogares S.l"/>
        <meta property="og:description" content="Promociones Apihogares S.l con multitud de propiedades, pisos , chalet , casas, villas en todas las zonas y localidades, incluyendo toda la provincia de Alicante"/>
        <meta property="og:url" content="https://www.gessicon.com/alertas.php"/>
        <meta property="og:type" content="website"/>
        <meta property="fb:admins" content="494641230470"/>
        <meta property="fb:app_id" content="426208334088115"/>
        <meta property="og:image"  content="https://www.gessicon.com/img/header/logo.png"/>
        
        
        <link rel="canonical" href="https://www.gessicon.com/alertas.php?idio=2" />

    
    <style type="text/css">
        :root {
          --background1: #ffffff;
  --background1-78: #ffffff;
  --color1: #0051e6;
  --color1-78: #0051e6;
  --background2: #f0610e;
  --background2-78: #f0610e;
  --color2: #0519f2;
  --color2-78: #0519f2;
  --background3: #be00ed;
  --background3-78: #be00ed;
  --color3: #ffffff;
  --color3-78: #ffffff;

            --colorTextos: #fff;
            --colorTextos2: #333;
        }
                .fotopropiedad::after,
        .visorficha .visorficha-miniaturas li::after {
            display: block;
            opacity: 0.7;
        }
    </style>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Courgette|Muli|Comfortaa|Stardos+Stencil:700" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">
    <link rel="stylesheet" href="css/reset.css?x=20260506150310" type="text/css">
    <link rel="stylesheet" href="css/fuentes.css?x=20260506150310" type="text/css">
    <link rel="stylesheet" href="css/estiloCookies.css?x=20260506150310" type="text/css">
    <link rel="stylesheet" href="css/estilo.css?x=20260506150310" type="text/css">
    <link rel="stylesheet" href="buscadorareas/style.css?x=20260506150310" type="text/css">
    <link rel="stylesheet" href="buscadorareas/componentes-v3-externo.css?x=20260506150310" type="text/css">
    <link rel="stylesheet" href="css/modulo-disenyadoinmovilla-1.css?x=20260506150310" type="text/css">
    <link rel="stylesheet" href="css/estiloCookies.css?x=20260506150310" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.0/css/all.css">
        <link rel="stylesheet" href="css/modulo-cabecera-1.css?x=20260506150310" type="text/css">
                <link rel="stylesheet" href="css/modulo-slider-1.css?x=20260506150310" type="text/css">
                <link rel="stylesheet" href="css/modulo-alertas-1.css?x=20260506150310" type="text/css">
                <link rel="stylesheet" href="css/modulo-suscribete-1.css?x=20260506150310" type="text/css">
                <link rel="stylesheet" href="css/modulo-pie-1.css?x=20260506150310" type="text/css">
                <link rel="stylesheet" href="css/plugin-llamamos-1.css?x=20260506150310" type="text/css">
                <link rel="stylesheet" href="css/plugin-whatsapp-1.css?x=20260506150310" type="text/css">
        
    <script>
        //var tienemetricool = 0;
        var tienegooglanalitics = 0;
    </script>


</head>


<body>




<input type="hidden" id="errornombre" value="Please fill in your name">
<input type="hidden" id="erroremail" value="Wrong email address">
<input type="hidden" id="erroremailotelefono" value="You must provide email or phone number">
<input type="hidden" id="erroredebesseleccionarciudad" value="To search with the map you must select a city">
<input type="hidden" id="errortelefono" value="You must enter a valid phone number">
<input type="hidden" id="errorpolitica" value="You must accept the privacy policy">
<input type="hidden" id="errorconsulta" value="Please write your query">
<input type="hidden" id="consultaenviada" value="Consult sended">
<input type="hidden" id="errortipo" value="You have to select a type of property">
<input type="hidden" id="errorarea" value="You must select an area">
<input type="hidden" id="errorpreciodesde" value="You must enter price from">
<input type="hidden" id="errorpreciohasta" value="You must enter price to">
<input type="hidden" id="errorhab" value="You must point out the bedrooms">
<input type="hidden" id="erroralerta" value="The alert has not been able to create">
<input type="hidden" id="alertacreada" value="The warning has been given high property shortly receive your email">
<input type="hidden" id="propiedadfavorita" value="Property added to favorites">
<input type="hidden" id="propiedadeliminadafavorita" value="Property removed from Favorites">
<input type="hidden" id="propiedaddescartada" value="Property discarded">
<input type="hidden" id="propiedadeliminadadescartada" value="Property removed from Discarded">
<input type="hidden" id="proponerprecio" value="Write your price proposal and comments">
<input type="hidden" id="errorcomentarionoticia" value="Failed to send your comment">
<input type="hidden" id="comentarionoticiacreado" value="Comment sent successfully">
<input type="hidden" id="comentarionoticiarevision" value="Your comment was successfully sent. It will soon be reviewed and published.">
<input type="hidden" id="aceptar_modal" value="Accept">



    <div id="supercontenedor" class="flex-column bloque-100">
<!-- cabecera-1 / Cabecera y Pestañas -->
<header id="modulo-cabecera-1" class="bloque-modulo modulo-cabecera flex-column">
  <div id="header-bloqueidiomas" class="bloque-100 flex-justify-end">
      <ul class="flex-justify-end">
        
            <li>
                <a onmousedown="idioma('es',event)"><img id="idio" src="img/header/bandera_01.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('ca', event)" ><img id="idio" src="img/header/bandera_12.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('eu',event)"><img id="idio" src="img/header/bandera_16.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('en',event)"><img id="idio" src="img/header/bandera_02.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('de',event)"><img id="idio" src="img/header/bandera_03.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('fr',event)"><img id="idio" src="img/header/bandera_04.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('it',event)"><img id="idio" src="img/header/bandera_15.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('no',event)"><img id="idio" src="img/header/bandera_06.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('fi',event)"><img id="idio" src="img/header/bandera_10.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('sv',event)"><img id="idio" src="img/header/bandera_09.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('ru',event)"><img id="idio"src="img/header/bandera_07.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('nl',event)"><img id="idio" src="img/header/bandera_05.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('zh',event)"><img id="idio" src="img/header/bandera_11.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('pl',event)"><img id="idio"src="img/header/bandera_17.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('pt',event)"><img id="idio" src="img/header/bandera_08.png"></a>
            </li>
            
      </ul>
  </div>
  <div id="header-bloque2" class="bloque-100 bg-color1">
    <h2 id="header-logo" class="flex">
      <a href="https://www.gessicon.com"><img src="img/header/logo.png" alt="Promociones Apihogares S.l"></a>
    </h2>
    <div id="header-bloquemenu" class="flex-column flex-justify-between flex-align-end">
        
            <div id="header-bloquetfno">
                <a href="tel:638 062 858">
                    <img src="img/tel.png" alt="Teléfono 638 062 858">
                    <span id="border">638 062 858</span>
                </a>
                <div id="texto-telefono">
                    
                </div>
            </div>
            
      <nav class="header-menu" seccionPostHog="Menu">
        <ul>
        <li class="menuPrincipalCabecera enviarPostHog " nombreEventoPostHog="Home"><a href="index.php" >Home</a></li><li class="menuPrincipalCabecera enviarPostHog " nombreEventoPostHog="For sale"><a href="for-sale/" >For sale</a></li><li class="menuPrincipalCabecera enviarPostHog " nombreEventoPostHog="Rental"><a href="rental/" >Rental</a></li><li class="menuPrincipalCabecera enviarPostHog " nombreEventoPostHog="Promotions"><a href="promotions/" >Promotions</a></li><li class="menuPrincipalCabecera enviarPostHog " nombreEventoPostHog="Company"><a href="seccion/company/company/en/" >Company</a></li><li class="menuPrincipalCabecera enviarPostHog  enlaceAcontacto " nombreEventoPostHog="Contact us"><a href="#Contact us" >Contact us</a></li>
        </ul>
      </nav>
    </div>
  </div>
    <div id="cabecera-bloque-buscador" class="d-none cabecera-bloque-buscador-horizontal noDestacado">
    <div id="cabecera-buscador" seccionPostHog="Search" class="d-none buscadorRapido flex-align-center">
        <div id="inmotipos" class="buscadorTipos custom-select-html enviarPostHog" nombreEventoPostHog="Property Type" original-txt="Property Type"
             data-txt="Property Type">
            <ul class="cajaGrupoTipos cajaGrupoTiposZonas">
        <li>
            <div class="grupoTipoZona">
                <input type="checkbox" class="marcarTodas">
                <span>All</span>
            </div>
        </li>
                    <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="6299,7599" >
                    <span><u> Rustic house</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="6299" >
                                <span>Village house</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="7599" >
                                <span>House with land</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="7499,199,299,399,21199,499,5499,6499" >
                    <span><u> House/Chalet</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="7499" >
                                <span>Bungalow Ground Floor</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="199" >
                                <span>Terraced house</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="299" >
                                <span>Bungalow</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="399" >
                                <span>House</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="21199" >
                                <span>Duplex House</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="499" >
                                <span>Single family house</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="5499" >
                                <span>Bungalow Top Floor</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="6499" >
                                <span>Luxury Villa</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="1699" >
                    <span><u> Building</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1699" >
                                <span>Building</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="2399,2599" >
                    <span><u> Garage </u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="2399" >
                                <span>Garage</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="2599" >
                                <span>Parking</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="1299" >
                    <span><u> Premises or Warehouse</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1299" >
                                <span>Business Premise</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="1199,1399" >
                    <span><u> Office</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1199" >
                                <span>Office</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1399" >
                                <span>Office</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="3399,3499,2999" >
                    <span><u> Apartment</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="3399" >
                                <span>Flat</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="3499" >
                                <span>Ground floor apartment</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="2999" >
                                <span>Duplex</span>
                            </div>
                        </li>
                                        </ul>
            </li>
            
    </ul>
        </div>
        <div class="flex-column componentes-v3">
            <label class="custom-select enviarPostHog" nombreEventoPostHog="Areas">
                <iv-buscador-areas-webs
                        url="https://apiweb.inmovilla.com/apiweb/config/8569_185.57.173.244_1/areas.json"
                        minlength="3"
                        multiple
                        value=""
                        onchange="$('iv-buscador-areas-webs').val(this.value)"
                        placeholder="Enter the area you are looking for..."
                        placeholderbuscador="Enter the area you are looking for..."
                        textoerror="An error occurred"
                        textosinresultados="No results"
                        avisoresultadoslimitados="Showing more relevant results, enter a more detailed search"
                        idioma="2"
                ></iv-buscador-areas-webs>
            </label>
        </div>

    <div class="bloque-input slider-buscador-precio enviarPostHog" nombreEventoPostHog="Price from">
        <input id="precioDesdeRapido" type="number" placeholder="Price from" class="fuerzaBusqueda inputBuscador inputBuscadorDesde" claseSincroniza="inputBuscadorDesde" value="">
    </div>
    <div class="bloque-input slider-buscador-precio enviarPostHog" nombreEventoPostHog="Price up to">
        <input id="precioHastaRapido" type="number" placeholder="Price to" class="fuerzaBusqueda inputBuscador inputBuscadorHasta" claseSincroniza="inputBuscadorHasta" value="">
    </div>
    <div class="bloque-input slider-buscador-ref enviarPostHog" nombreEventoPostHog="Reference">
        <input id="refRapido" type="text" placeholder="Ref" class="bg-color fuerzaBusqueda inputBuscador inputBuscadorRef" claseSincroniza="inputBuscadorRef"
               value="">
    </div>
    
    <div class="buttons">
        <button class="avanzado enviarPostHog" nombreEventoPostHog="Advanced">Advanced</button>
        <button class="buscarRapido enviarPostHog" nombreEventoPostHog="Search for" onclick="busquedaBuscadorRapido($(this))">Search</button>
    </div>
</div>
</div><link rel='stylesheet' href='css/componentes/buscadorcabecera-1.css?x=20260506150310' type='text/css'>
</header>
<!-- slider-1 / Slider Principal y Buscador -->

    <section id="modulo-slider-1" class="bloque-modulo flex-column relative">

    <div class="slider-1">

            <div class="slider-imagen" id="img1">
                <span id="slider-textoEstrella" posslider=""></span>
            </div>
            <div class="slider-botonAnterior" onClick="SliderCabecera(PosSlider-3);"></div>
            <div class="slider-botonSiguiente" onClick="SliderCabecera(PosSlider+3);"></div>

    </div>

    
        <h1 id="slider-slogan-vertical">Encontramos la casa de tus sueños</h1>
    



        <div id="slider-bloque-buscador" class="slider-bloque-buscador-1 noDestacado">
    
        <div id="slider-buscador" seccionPostHog="Search" class="buscadorRapido flex-align-top " >
            <div id="inmotipos" class="buscadorTipos custom-select-html enviarPostHog" nombreEventoPostHog="Property Type" original-txt="Property Type" data-txt="Property Type">
                <ul class="cajaGrupoTipos cajaGrupoTiposZonas">
        <li>
            <div class="grupoTipoZona">
                <input type="checkbox" class="marcarTodas">
                <span>All</span>
            </div>
        </li>
                    <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="6299,7599" >
                    <span><u> Rustic house</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="6299" >
                                <span>Village house</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="7599" >
                                <span>House with land</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="7499,199,299,399,21199,499,5499,6499" >
                    <span><u> House/Chalet</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="7499" >
                                <span>Bungalow Ground Floor</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="199" >
                                <span>Terraced house</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="299" >
                                <span>Bungalow</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="399" >
                                <span>House</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="21199" >
                                <span>Duplex House</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="499" >
                                <span>Single family house</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="5499" >
                                <span>Bungalow Top Floor</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="6499" >
                                <span>Luxury Villa</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="1699" >
                    <span><u> Building</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1699" >
                                <span>Building</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="2399,2599" >
                    <span><u> Garage </u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="2399" >
                                <span>Garage</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="2599" >
                                <span>Parking</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="1299" >
                    <span><u> Premises or Warehouse</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1299" >
                                <span>Business Premise</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="1199,1399" >
                    <span><u> Office</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1199" >
                                <span>Office</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1399" >
                                <span>Office</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="3399,3499,2999" >
                    <span><u> Apartment</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="3399" >
                                <span>Flat</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="3499" >
                                <span>Ground floor apartment</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="2999" >
                                <span>Duplex</span>
                            </div>
                        </li>
                                        </ul>
            </li>
            
    </ul>
            </div>
            <div class="flex-column componentes-v3">
                <label class="custom-select enviarPostHog" nombreEventoPostHog="Areas">
                    <iv-buscador-areas-webs
                            url="https://apiweb.inmovilla.com/apiweb/config/8569_185.57.173.244_1/areas.json"
                            minlength="3"
                            multiple
                            value=""
                            onchange="$('iv-buscador-areas-webs').val(this.value)"
                            placeholder="Enter the area you are looking for..."
                            placeholderbuscador="Enter the area you are looking for..."
                            textoerror="An error occurred"
                            textosinresultados="No results"
                            avisoresultadoslimitados="Showing more relevant results, enter a more detailed search"
                            idioma="2"
                    ></iv-buscador-areas-webs>
                </label>
            </div>
            <div class="bloque-input slider-buscador-precio enviarPostHog" nombreEventoPostHog="Price from">
                <input id="precioDesdeRapido" type="number" placeholder="Price from" class="fuerzaBusqueda inputBuscador inputBuscadorDesde" claseSincroniza="inputBuscadorDesde" value="">
            </div>
            <div class="bloque-input slider-buscador-precio enviarPostHog" nombreEventoPostHog="Price up to">
                <input id="precioHastaRapido" type="number" placeholder="Price to" class="fuerzaBusqueda inputBuscador inputBuscadorHasta" claseSincroniza="inputBuscadorHasta" value="">
            </div>
            <div class="bloque-input slider-buscador-ref enviarPostHog" nombreEventoPostHog="Reference">
                <input id="refRapido" type="text" placeholder="Ref" class="bg-color fuerzaBusqueda inputBuscador inputBuscadorRef" claseSincroniza="inputBuscadorRef" value="">
            </div>
            

            <div class="buttons">
                <button class="avanzado enviarPostHog" nombreEventoPostHog="Advanced">Advanced</button>
                <button class="buscarRapido enviarPostHog" nombreEventoPostHog="Search for" onclick="busquedaBuscadorRapido($(this))">Search</button>
            </div>
    </div>
</div><link rel='stylesheet' href='css/componentes/buscador-1.css?x=20260506150310' type='text/css'>

<section id="slider-bloque-estrella" seccionPostHog="Properties list">
    <div id="slider-estrella-felchas">
        <a href="#" class="flecha2-previous"></a>
        <a href="#" class="flecha2-next"></a>
    </div>
    <article class="imagenesComoBackground fotopropiedad propiedad fotosAlVuelo  enviarPostHog" nombreEventoPostHog="View property list" style="background-image: url(img/nofotos.png);" cargaFoto="https://fotos15.apinmo.com/8569/12341515/13-1s.jpg" indice="1" tipo="destacadosestrella" onclick="window.location.href='ficha/flat/orihuela/zona-centro/8569/12341515/en/'">
        <a href="#" class="flechaprev"></a>
        <a href="#" class="flechanext"></a>

        <div id="slider-estrella-tituloprecio">
            <h1 class="titulo1">Flat Orihuela</h1>
            <span class="precio1">87.999 €</span>
        </div>
        <div id="slider-estrella-masdatos">
            <ul>
                <li class="bloque-icono-name-valor1">
                    <div>
                        <i class="fa fa-tag fa-2x"></i>
                    </div>
                    <div>
                        <span class="ref">002520</span>
                    </div>
                </li>

                
                <li class="bloque-icono-name-valor1">
                    <div>
                        <i class="fa fa-bed fa-2x"></i>
                    </div>
                    <div>
                        <span class="habitaciones">2</span>
                    </div>
                </li>
                

                
                <li class="bloque-icono-name-valor1">
                    <div>
                        <i class="fa fa-shower fa-2x"></i>
                    </div>
                    <div>
                        <span class="banyos">1</span>
                    </div>
                </li>
                

                
                <li class="bloque-icono-name-valor1">
                    <div>
                        <i class="fa fa-superscript fa-2x"></i>
                    </div>
                    <div>
                        <span class="superficie">101 mts</span>
                    </div>
                </li>
                

            </ul>
        </div>
    </article>
</section>
<link rel='stylesheet' href='css/componentes/destacadoEstrella-2.css?x=20260506150310' type='text/css'>
    <div class="bloque-shadow"></div>
  
</section>
<section id="modulo-buscAvanzado-1" class="bloque-modulo flex-column buscadorAvanzado" style="display: none;">
  <header id="buscAvanzado-cabecera" class="bloque-100 flex-column">
    <div class="tituloCabecera">
      <h2>Advanced search</h2>
      <span class="ocultar">Hide</span>
    </div>
  </header>
  <section id="buscAvanzado-buscador" seccionPostHog="Search">
    <div class="bloque bloque1">
      <div class="flex bloqueCheckbox">
        <div>
          <input type="checkbox" id="chkventa" class="custom-checkbox" value="1" >
          <label for="chkventa" class="enviarPostHog" nombreEventoPostHog="For sale">For sale</label>
        </div>
        <div>
          <input type="checkbox" id="chkalquiler" class="custom-checkbox" value="1" >
          <label for="chkalquiler" class="enviarPostHog" nombreEventoPostHog="For rent">Rental</label>
        </div>
        <div>
          <input type="checkbox" id="opcioncompra" class="custom-checkbox" value="1" >
          <label for="opcioncompra" class="enviarPostHog" nombreEventoPostHog="Option To Buy">Option To Buy</label>
        </div>
        <div>
          <input type="checkbox" id="chkalquilervacacional" class="custom-checkbox" value="1" >
          <label for="chkalquilervacacional" class="enviarPostHog" nombreEventoPostHog="Short term rentals">Short term rentals</label>
        </div>
        <div>
          <input type="checkbox" id="chktraspaso" class="custom-checkbox" value="1" >
          <label for="chktraspaso" class="enviarPostHog" nombreEventoPostHog="To Assign">Transfer</label>
        </div>
      </div>
      <div class="bloqueBuscarAvanzado">
        <div>
          <input id="limref2" class="fuerzaBusquedaAvanzado inputBuscador inputBuscadorRef enviarPostHog" nombreEventoPostHog="Reference" claseSincroniza="inputBuscadorRef" type="text" placeholder="Reference"></input>
        </div>
        <div>
          <button class="buscarAvanzado enviarPostHog" nombreEventoPostHog="Search for" onclick="busquedaBuscadorAvanzado($(this));">Search</button>
        </div>
      </div>
    </div>
    <div class="bloqueSelects bloque">
        <div class="bloque-select">
          <div id="inmotipos" class="buscadorTipos custom-select-html enviarPostHog" nombreEventoPostHog="Property Type" original-txt="Property Type" data-txt="Property Type">
              <ul class="cajaGrupoTipos cajaGrupoTiposZonas">
        <li>
            <div class="grupoTipoZona">
                <input type="checkbox" class="marcarTodas">
                <span>All</span>
            </div>
        </li>
                    <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="6299,7599" >
                    <span><u> Rustic house</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="6299" >
                                <span>Village house</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="7599" >
                                <span>House with land</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="7499,199,299,399,21199,499,5499,6499" >
                    <span><u> House/Chalet</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="7499" >
                                <span>Bungalow Ground Floor</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="199" >
                                <span>Terraced house</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="299" >
                                <span>Bungalow</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="399" >
                                <span>House</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="21199" >
                                <span>Duplex House</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="499" >
                                <span>Single family house</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="5499" >
                                <span>Bungalow Top Floor</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="6499" >
                                <span>Luxury Villa</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="1699" >
                    <span><u> Building</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1699" >
                                <span>Building</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="2399,2599" >
                    <span><u> Garage </u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="2399" >
                                <span>Garage</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="2599" >
                                <span>Parking</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="1299" >
                    <span><u> Premises or Warehouse</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1299" >
                                <span>Business Premise</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="1199,1399" >
                    <span><u> Office</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1199" >
                                <span>Office</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1399" >
                                <span>Office</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="3399,3499,2999" >
                    <span><u> Apartment</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="3399" >
                                <span>Flat</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="3499" >
                                <span>Ground floor apartment</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="2999" >
                                <span>Duplex</span>
                            </div>
                        </li>
                                        </ul>
            </li>
            
    </ul>
          </div>
        </div>
        <div class="bloque-select componentes-v3">
            <label class="custom-select enviarPostHog" nombreEventoPostHog="Areas">
                <iv-buscador-areas-webs
                        url="https://apiweb.inmovilla.com/apiweb/config/8569_185.57.173.244_1/areas.json"
                        minlength="3"
                        multiple
                        value=""
                        onchange="$('iv-buscador-areas-webs').val(this.value)"
                        placeholder="Enter the area you are looking for..."
                        placeholderbuscador="Enter the area you are looking for..."
                        textoerror="An error occurred"
                        textosinresultados="No results"
                        avisoresultadoslimitados="Showing more relevant results, enter a more detailed search"
                        idioma="2"
                ></iv-buscador-areas-webs>
            </label>
        </div>
        <div class="bloque-select">
          <label for="limhab" class="custom-select enviarPostHog" nombreEventoPostHog="Bedrooms">
            <select id="limhab">
              <option selected disabled>Bedrooms</option>
              <option value="1" >1</option>
              <option value="2" >2</option>
              <option value="3" >3</option>
              <option value="4" >+4</option>
            </select>
          </label>
        </div>
        <div class="bloque-select">
            <label for="limbanos" class="custom-select enviarPostHog" nombreEventoPostHog="Bathrooms">
                <select id="limbanos">
                    <option selected disabled>Bathrooms</option>
                    <option value="1" >1</option>
                    <option value="2" >2</option>
                    <option value="3" >3</option>
                    <option value="4" >+4</option>
                </select>
            </label>
        </div>
    </div>
      <div class="bloqueSelects bloque">
          <div class="bloque-input">
              <input id="metros" class="fuerzaBusquedaAvanzado enviarPostHog" nombreEventoPostHog="Surface" onkeypress="return solonumeros(event);" type="string" placeholder="Surface from" value=""> <b>m2</b>
          </div>
          <div class="bloque-input">
               <input id="metros2" class="fuerzaBusquedaAvanzado enviarPostHog" nombreEventoPostHog="Surface"  onkeypress="return solonumeros(event);" type="string" placeholder="Surface up to" value=""> <b>m2</b>
          </div>
          <div class="bloque-input">
              <input id="preciodesdeAvanzado" class="fuerzaBusquedaAvanzado inputBuscador inputBuscadorDesde enviarPostHog" nombreEventoPostHog="Price from" claseSincroniza="inputBuscadorDesde" type="number" placeholder="Price from" value=""> <b>€</b>
          </div>
          <div class="bloque-input">
              <input id="preciohastaAvanzado" class="fuerzaBusquedaAvanzado inputBuscador inputBuscadorHasta enviarPostHog" nombreEventoPostHog="Price up to" claseSincroniza="inputBuscadorHasta" type="number" placeholder="Price to" value=""> <b>€</b>
          </div>
      </div>
      <div class="bloque bloqueCheckbox">
      <div class=" enviarPostHog" nombreEventoPostHog="Pool">
        <input type="checkbox" id="piscina" class="custom-checkbox" value="1" >
        <label for="piscina">Pool</label>
      </div>
      <div class="enviarPostHog" nombreEventoPostHog="Parking">
        <input type="checkbox" id="parking" class="custom-checkbox" value="1" >
        <label for="parking">Parking</label>
      </div>
      <div class="enviarPostHog" nombreEventoPostHog="Lift">
        <input type="checkbox" id="ascensor" class="custom-checkbox" value="1" >
        <label for="ascensor">Lift</label>
      </div>
      <div class="enviarPostHog" nombreEventoPostHog="Terrace">
        <input type="checkbox" id="terraza" class="custom-checkbox" value="1" >
        <label for="terraza">Terrace</label>
      </div>
      <div class="enviarPostHog" nombreEventoPostHog="Furnished">
        <input type="checkbox" id="muebles" class="custom-checkbox" value="1" >
        <label for="muebles">Furnished</label>
      </div>
      <div class="enviarPostHog" nombreEventoPostHog="Urbanization">
        <input type="checkbox" id="urbanizacion" class="custom-checkbox" value="1" >
        <label for="urbanizacion">Urbanizacion</label>
      </div>
      <div class="enviarPostHog" nombreEventoPostHog="New Construction">
        <input type="checkbox" id="obranueva" class="custom-checkbox" value="1" >
        <label for="obranueva">New Build</label>
      </div>
      <div class="enviarPostHog" nombreEventoPostHog="View to sea">
        <input type="checkbox" id="vistasalmar" class="custom-checkbox" value="1" >
        <label for="vistasalmar">View to sea</label>
      </div>
    </div>
  </section>
</section><link rel='stylesheet' href='css/componentes/buscadoravanzado-1.css?x=20260506150310' type='text/css'><!-- alertas-1 / Comodin --><section id="modulo-alertas-1">
<div class="tituloAlerta">
    <h1>Alerts</h1>
</div>
<form id="alertas" target="oculto"  name="alertas" action="alertas.php" method="post" >
    <div class="blockquote">
        <span class="quote">“</span>
        <p>New alert</p>
    </div>
    <input type="hidden" id="idioma" value="2"/>
    <input type="hidden" id="weborigen" name="weborigen" value="https://www.gessicon.com">

    <div class="bloqueAlertaContenedores">
        <div class="bloqueAlertasContenedor" >
            <span class="tituloBloqueAlertas">Type of property</span>

            <div id="tipos.resultados" class="bloqueAlertasDatos tiposAlerta" style="height: 200px;overflow: auto;">
                <div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"1 value="6399"><span>Agricultural house</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"2 value="2799"><span>Apartment</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"3 value="4699"><span>Attic</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"4 value="7299"><span>Barn</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"5 value="5299"><span>Basement</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"6 value="2199"><span>Boat mooring</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"7 value="1699"><span>Building</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"8 value="3899"><span>Building Site</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"9 value="299"><span>Bungalow</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"10 value="7499"><span>Bungalow Ground Floor</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"11 value="5499"><span>Bungalow Top Floor</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"12 value="4499"><span>Business</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"13 value="1299"><span>Business Premise</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"14 value="7099"><span>Cabin</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"15 value="7999"><span>Cafeteria</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"16 value="6799"><span>Camping</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"17 value="5699"><span>Castle</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"18 value="5799"><span>Cave house</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"19 value="2299"><span>Cellar</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"20 value="11299"><span>Cinegetic Farm</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"21 value="4599"><span>Country House</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"22 value="6099"><span>Country manor</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"23 value="8299"><span>Discotheque</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"24 value="2999"><span>Duplex</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"25 value="21199"><span>Duplex House</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"26 value="4399"><span>Duplex Penthouse</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"27 value="1799"><span>Factory</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"28 value="11099"><span>Farm</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"29 value="11899"><span>Farm with orchard</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"30 value="599"><span>Farmhouse</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"31 value="899"><span>Farmhouse</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"32 value="20299"><span>Farmhouse</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"33 value="3399"><span>Flat</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"34 value="10199"><span>Fuel station</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"35 value="2399"><span>Garage</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"36 value="10399"><span>Golf course</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"37 value="7399"><span>Greenhouse</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"38 value="3499"><span>Ground floor apartment</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"39 value="9599"><span>Holiday resort</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"40 value="1499"><span>Hostel</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"41 value="1899"><span>Hostel</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"42 value="1999"><span>Hotel</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"43 value="20399"><span>Hountign ground</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"44 value="399"><span>House</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"45 value="7599"><span>House with land</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"46 value="9499"><span>Housing above warehouse</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"47 value="10499"><span>Housing over shop</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"48 value="7699"><span>Industrial building</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"49 value="3999"><span>Industrial Land</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"50 value="2099"><span>Industrial Unit</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"51 value="5399"><span>Kiosk</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"52 value="11199"><span>Livestock Farm</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"53 value="3299"><span>Loft</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"54 value="11799"><span>Logistic storage</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"55 value="6499"><span>Luxury Villa</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"56 value="20099"><span>Mansion</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"57 value="21299"><span>Mansion</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"58 value="20199"><span>Mediterranean country house</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"59 value="4899"><span>Mezzanine</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"60 value="10299"><span>Mezzanine</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"61 value="9199"><span>Motorcycle parking</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"62 value="3799"><span>Mountain</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"63 value="20899"><span>Multi-family plot</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"64 value="9799"><span>Niche</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"65 value="1199"><span>Office</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"66 value="1399"><span>Office</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"67 value="11499"><span>Oil mill</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"68 value="8699"><span>Olive grove</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"69 value="8899"><span>Orchard</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"70 value="20999"><span>Over attic</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"71 value="21399"><span>Palace</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"72 value="2599"><span>Parking</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"73 value="6699"><span>Pazo House</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"74 value="2899"><span>Penthouse</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"75 value="10099"><span>Picnic</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"76 value="5099"><span>Plot of land</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"77 value="7799"><span>Pub</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"78 value="9899"><span>Pub</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"79 value="5199"><span>Quad House</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"80 value="699"><span>Ranch</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"81 value="11399"><span>Recreational property</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"82 value="20699"><span>Residence</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"83 value="7899"><span>Restaurant</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"84 value="20499"><span>Riad</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"85 value="3199"><span>Room</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"86 value="11599"><span>Rural hotel</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"87 value="11699"><span>Rural house</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"88 value="4099"><span>Rural Land</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"89 value="10999"><span>Rustic Land</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"90 value="3699"><span>Rustic property</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"91 value="4799"><span>Semi Attic</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"92 value="10799"><span>Semi basement</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"93 value="999"><span>Semi-detached house</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"94 value="11999"><span>Shopping center</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"95 value="499"><span>Single family house</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"96 value="9699"><span>Single floor</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"97 value="6199"><span>Solar house</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"98 value="7199"><span>Stable</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"99 value="6899"><span>Stone house</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"100 value="2699"><span>Storage room</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"101 value="3099"><span>Studio</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"102 value="199"><span>Terraced house</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"103 value="1099"><span>Tower</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"104 value="3599"><span>Triplex</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"105 value="799"><span>Unique property</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"106 value="8799"><span>Unseeded land</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"107 value="4199"><span>Urban Plot of land</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"108 value="20599"><span>Urban property</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"109 value="9099"><span>Urbanizable land</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"110 value="4999"><span>Villa</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"111 value="6299"><span>Village house</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"112 value="6599"><span>Village house</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"113 value="8999"><span>Vineyard</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"114 value="1599"><span>Warehouse</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"115 value="9999"><span>Windmill</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"116 value="2499"><span>Winery</span></div><div class="bloqueAlertasCheckbox"><input type="checkbox" id="checkbox"117 value="5999"><span>Wooden House</span></div>
            </div>
        </div>
        <div class="bloqueAlertasContenedor" >
            <span class="tituloBloqueAlertas">Search by Area</span>

            <div class="flex-column componentes-v3">
                <label class="custom-select enviarPostHog" nombreEventoPostHog="Areas">
                    <iv-buscador-areas-webs
                            url="https://apiweb.inmovilla.com/apiweb/config/8569_185.57.173.244_1/areas.json"
                            minlength="3"
                            multiple
                            placeholder="Enter the area you are looking for..."
                            placeholderbuscador="Enter the area you are looking for..."
                            textoerror="An error occurred"
                            textosinresultados="No results"
                            avisoresultadoslimitados="Showing more relevant results, enter a more detailed search"
                            idioma="2"
                    ></iv-buscador-areas-webs>
                </label>
            </div>
        </div>

        <div class="bloqueAlertasContenedor">
        <span class="tituloBloqueAlertas">Data</span>
            <div class="bloqueAlertasInput">
                <span>Price from</span>
                <input type="number" min="0" id="preciodesde" name="preciodesde">
            </div>
            <div class="bloqueAlertasInput">
                <span>Price to</span>
                <input type="number" min="0" id="preciohasta" name="preciohasta">
            </div>


            <div class="bloqueAlertasSELECT">
            <span>Bedrooms</span>
                <label for="tipohab" class="custom-select">
                    <select name="habitaciones" id="tipohab">
                        <option value="-1">-------</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">+4</option>

                    </select>

            </div>
        </div>


        <div class="bloqueAlertasContenedor">
            <span class="tituloBloqueAlertas">Contact Details</span>
            <div class="bloqueAlertasInput">
                <span>Name *</span>
                <input type="text" id="nombreAlertas" name="nombre">
            </div>
            <div class="bloqueAlertasInput">
                <span>Email *</span>
                <input type="text" id="mailAlertas" name="mail">
            </div>
            <div class="bloqueAlertasInput">
                <span>Telephone *</span>
                <input type="text" id="telefonoAlertas" name="telefono">
            </div>

        </div>
    </div>
    <div class="bloqueAlertasCheckbox" id="legalaviso">
        <div class="bloque-checkbox">
            <input type="checkbox" id="textolegal" name="textolegal" class="custom-checkbox">
            <label for="textolegal"></label>
        </div>
        <span id="spanPrivacidadAlertas">
            When you press the button “SEND” you confirm you’ve read, understood and accepted the conditions of our Privacy Policy shown in this LINK
        </span>
    </div>

    <div class="bloqueAlertasButton">
        <button type="button"  id="enviar_alerta" class="enviar_alerta enviarPostHog" nombreEventoPostHog="Create alert">Send Query</button>
        <div class="resultadoAlerta"></div>
    </div>

</form>

</section><!-- suscribete-1 / Suscr\u00edbete -->






    <section id="modulo-suscribete-1" style="color: var(--color1);" cargaFoto="https://media.apinmo.com/galerias/imagenes/imagen2_*.jpg" imgResponsive="true" class="modulos-suscribete fotosAlVuelo unset">


    <div class="titulo">
        <h1 id="titulo-suscribete-1">Subscribe</h1>
        Subscribe to our mailing list and you will be first to receive new properties
    </div>
    <div class="cajas">
        <input id="emailSuscripcion" class="emailSuscripcion" type="text" placeholder="E-mail @">
        <button class="botonEnviar accionEnviar">Send</button>
        <div class="resultadoSuscribete"></div>
        <div class="opciones">
            <p><input id="checkPolitica" type="checkbox"> <label id="txtPoliticaSuscribete">Accept Privacy Policy</label></p>
            <p><input id="checkNewsletter" type="checkbox"> <label>Accept to receive advertisement</label></p>
        </div>
    </div>
</section>
<!-- pie-1 / Pie -->

<footer id="modulo-pie-1" class="bloque-modulo modulo-pie">
    <div id="pie-fila1">
        <div id="pie-subfila1">
            <div id="pie-menu" seccionPostHog="Footer">
                <menu><li class="enviarPostHog" nombreEventoPostHog="Link"><a href="index.php" >Home</a></li><li class="enviarPostHog" nombreEventoPostHog="Link"><a href="for-sale/" >For sale</a></li><li class="enviarPostHog" nombreEventoPostHog="Link"><a href="rental/" >Rental</a></li><li class="enviarPostHog" nombreEventoPostHog="Link"><a href="promotions/" >Promotions</a></li><li class="enviarPostHog" nombreEventoPostHog="Link"><a href="seccion.php?sec=company&amp;nombre=company" >Company</a></li><li class="enviarPostHog" nombreEventoPostHog="Link"><a href="alertas.php" >Alerts</a></li><li class="enviarPostHog" nombreEventoPostHog="Link"><a href='./publica-tu-inmueble/'>List your property</a></li><li class="enviarPostHog" nombreEventoPostHog="Link"><a href="#" onclick="event.preventDefault();modalNuestra('mytextoprivacidadFooter','Privacy policy');">Privacy policy</a></li><li class="enviarPostHog" nombreEventoPostHog="Link"><a href="#" onclick="event.preventDefault();modalNuestra('mytextolegal','Legal advice');">Legal advice</a></li><li class="enviarPostHog" nombreEventoPostHog="Link"><a href="#" onclick='event.preventDefault(); modalPoliticaCookies(politicacookies, textoaviso, aceptar_todas,rechazar,gestionarcookies, textocookies, aceptar_selec, cerrar);'>Cookies policy</a></li></menu>
            </div>
            <div class="pie-agencia" seccionPostHog="Footer">


                <div class="pie-datosagenciaBloque1">
                    <div class="pie-datosagencia">
                        <ul>
                            <li class="titulo">Promociones Apihogares S.l</li>
                            
                            <li><a href="mailto:apihogares@gmail.com">apihogares@gmail.com</a></li>
                            <li><a href="https://www.gessicon.com">https://www.gessicon.com</a></li>
                                <li>
                                    <a href="tel:638 062 858">638 062 858</a>
                                    <br><span id="textotel">
                                        
                                    </span>
                                     <br> 
                                    <a href="tel:638 062 858">638 062 858</a>
                                    <br><span id="textotel">
                                        
                                    </span>
                                </li>
                            <li>Extremadura, bajo 3 Orihuela 03300 (Alicante)</li>
                        </ul>
                    </div>
                    <div class="pie-datosagenciaLogo">
                        <img src="img/header/logo.png" alt="Logo Promociones Apihogares S.l">
                    </div>
                </div>
                
                    <button type="button" id=mostrarMapa_0" class="botonMostarMapa" onclick="mostrar_ocultar_mapa(0);">Map</button>

                    
                        <div id="mapaOficina_0" class="pie-datosagenciaBloque2">
                    
                        <iframe class="pie-iframemapa srcAlVuelo enviarPostHog" nombreEventoPostHog="Map" loading="lazy" frameborder="0" marginwidth="0" marginheight="0" rutaSrc="https://procesos.apinmo.com/externo/googleplano.php?individual=si&coordenadas=38.07831253,-0.94617752"></iframe>
                    </div>
                


            


            </div>
            <div id="pie-contacto" seccionPostHog="Contact">
                <form class="contacto">
                    <fieldset>
                        <legend>Contact us</legend>
                        <dl>
                            <dt>
                                <input type="text" id="pie-nombre" placeholder="Name (*)">
                            </dt>
                        </dl>
                        <dl>
                            <dt>
                                <input type="text" id="pie-email" placeholder="Email (*)">
                            </dt>
                        </dl>
                        <dl>
                            <dt>
                                <input type="text" id="pie-telefono" placeholder="Telephone">
                            </dt>
                        </dl>
                        
                        <dl>
                            <dt>
                                <textarea id="pie-descripcion" placeholder="Description (*)"></textarea>
                            </dt>
                        </dl>
                        <dl>
                            <dd>
                                <div class="bloque-checkbox">
                                    <input type="checkbox" id="textolegal3" class="custom-checkbox">
                                    <label for="textolegal3"></label>
                                </div>
                                <span class="textolegal" id="eltextolegal3">When you press the button “SEND” you confirm you’ve read, understood and accepted the conditions of our Privacy Policy shown in this LINK</span>
                            </dd>
                        </dl>
                        <dl>
                            <dt>
                                <span class="resultadoInfo"></span>
                                <button type="button" class="botonEnviar enviaForm enviarPostHog" nombreEventoPostHog="Send contact">Send</button>
                            </dt>
                        </dl>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
    <aside id="pie-filaSocial">
        <menu lang-data="Follow us">
  <span id="titulo-pie-pagina">Follow us</span>
            <li>
              <a target="_blank" rel="noopener noreferrer" href="/rss"><img src="img/social/rss2.png" alt="RSS" style="height: 40px;opacity: 0.8;"></a>
          </li>
      </menu>
    </aside>
</footer>



<div id="modulo-disenyadoinmovilla-1" class="bloque-modulo">
  <span>Designed by <a href="http://www.facebook.com/crminmovilla" rel="noreferrer" target="_blank">CRM Inmovilla</a></span>
</div>
    </div>
    <script src="js/lib/jquery-3.5.1.min.js"></script>
    <script src="js/lib/jquery-ui.min.js"></script>
    <script src='https://www.google.com/recaptcha/api.js?render=6LeFvHcUAAAAADkYzbLtZuO5lRdgl6gpLYovrRwl'></script>
    <script>
    var numagencia = 8569;
    var inmonombre = 'Promociones Apihogares S.l';
    var urlBase = `https://www.gessicon.com`;
    var listados = {};
    var hastagPaginacion = '#modulo-paginacion';
    var hastagPaginacionMapa = '#modulo-paginacionmapa';
    var desactivarNotificacionPush = false;
    var esMovil = 0;
    var unsolocontacto = '1';
    var soyIframe = false;
    var soyWebPortuguesa = false;
    var actual = 'alertas.php';
    var esListado = false;
    var idio = '2';
    var idio_txt = 'en';
    var urlAreas = 'https://apiweb.inmovilla.com/apiweb/config/8569_185.57.173.244_1/areas.json';
</script>    <script src="js/EnviarPostHog.js?x=20260506150310"></script>
    <script src="js/funciones.js?x=20260506150310"></script>
    <script src="buscadorareas/componentes-v3-externo.js?x=20260506150310"></script>
    <!-- posthog -->
    <script>
        /*
        !function(t,e){var o,n,p,r;e.__SV||(window.posthog=e,e._i=[],e.init=function(i,s,a){function g(t,e){var o=e.split(".");2==o.length&&(t=t[o[0]],e=o[1]),t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}}(p=t.createElement("script")).type="text/javascript",p.async=!0,p.src=s.api_host+"/static/array.js",(r=t.getElementsByTagName("script")[0]).parentNode.insertBefore(p,r);var u=e;for(void 0!==a?u=e[a]=[]:a="posthog",u.people=u.people||[],u.toString=function(t){var e="posthog";return"posthog"!==a&&(e+="."+a),t||(e+=" (stub)"),e},u.people.toString=function(){return u.toString(1)+".people (stub)"},o="capture identify alias people.set people.set_once set_config register register_once unregister opt_out_capturing has_opted_out_capturing opt_in_capturing reset isFeatureEnabled onFeatureFlags getFeatureFlag getFeatureFlagPayload reloadFeatureFlags group updateEarlyAccessFeatureEnrollment getEarlyAccessFeatures getActiveMatchingSurveys getSurveys onSessionId".split(" "),n=0;n<o.length;n++)g(u,o[n]);e._i.push([i,s,a])},e.__SV=1)}(document,window.posthog||[]);
        posthog.init('phc_gMjYRPEacx4ZPimRXWQhrGueXINnBrAoLwxAoJloief',{api_host:'https://posthog.inmovilla.com'})

        let EnviarPostHogObj = new EnviarPostHog();
         */
    </script>
    <script src="js/modulos/comun/comun-buscadores.js?x=20260506150310"></script>


<script>
    var provinciaSeleccionadaPorDefecto = false;
</script>
<script src="js/modulos/comun/buscador.js?x=20260506150310"></script>


<script>
    var mostrarBuscadorAvanzado = false;
        var provinciaSeleccionadaPorDefecto = false;
    </script>
<script src="js/modulos/comun/buscadorAvanzado.js?x=20260506150310"></script>

<script>
    var header,browser,browserModuloPadre,headerBrowser,sticky,stickyBrowser,idiomas,telefono,logo,section,buscadorCabecera;
    var opCabecera = 1;

    $(document).ready(function () {

        if(!parseInt(esMovil) || window.innerWidth > 600) {
            //alert(esMovil);
            header = document.getElementById("modulo-cabecera-1");
            browser = document.querySelector('.buscadorRapido:not(#cabecera-buscador)');
            browserModuloPadre = $(browser).closest('.bloque-modulo');
            headerBrowser = document.querySelector('#cabecera-bloque-buscador');
            sticky = header.offsetTop + 41;
            if (browser != null)
                stickyBrowser = browser.offsetTop + browserModuloPadre[0].offsetTop - 15;
            else
                stickyBrowser = false;
            idiomas = document.querySelector('#header-bloqueidiomas');
            telefono = document.querySelector('#header-bloquetfno');
            logo = document.querySelector('#header-logo');
            section = document.querySelector('#supercontenedor');
            buscadorCabecera = document.querySelector('#cabecera-buscador');

            if ($(window).scrollTop()) {
                setSticky();
            }
            window.onscroll = function () {
                setSticky()
            };

        } else {

            if (opCabecera == 0) {
                sliimage = document.querySelector('.slider-1');
                sliimage.style.display = 'none';
                mbavanzado = document.querySelector('#buscAvanzado-buscador');
                mbavanzado.style.marginTop = "20px";
            }
        }

    });


    function setSticky() {
        if (window.innerWidth < 960) {
            section.style.marginTop = '0';
            return false;
        }
        if (window.pageYOffset > sticky) {
            header.classList.add("sticky");
            idiomas.style.display = 'none';
            telefono.style.display = '';
            if(window.pageYOffset > stickyBrowser || stickyBrowser === false)
                headerBrowser.style.display = 'block';
            else
                headerBrowser.style.display = 'none';

            $(logo).fadeIn()
                .css({position:'absolute',top:-70})
                .animate({top:-200}, 222, function() {
                });
            section.style.marginTop = '140px';
            if (buscadorCabecera) {
                if (document.querySelector('#slider-bloque-buscador.slider-bloque-buscador-1')){
                    if (window.pageYOffset > (document.querySelector('section[id *= "modulo-slider-"]').offsetHeight - header.offsetHeight)){
                        buscadorCabecera.classList.remove('d-none');
                    }else{
                        buscadorCabecera.classList.add('d-none')
                    }
                }else{
                    buscadorCabecera.classList.remove('d-none');
                }
            }
        } else {
            header.classList.remove("sticky");
            idiomas.style.display = 'flex';
            telefono.style.display = 'flex';
            $(logo).stop(true);
            $(logo).css("top", "");
            $(logo).css("position", "");
            section.style.marginTop = '0';
            if (buscadorCabecera) {
                buscadorCabecera.classList.add('d-none')
            }
        }
    }

    //Sustituimos el parámetro del idioma por el que nos llegue
    function idioma(nuevoidio, event=false) {

        const button = event.which || event.button;
        //Si el botón es 2 significa que se ha pulsado la rueda del ratón

        const input = window.location.toString();
        const comprobar = new RegExp("/" + nuevoidio + "\\/?$")

        const comprobaridioma = comprobar.test(input);
        if(comprobaridioma == true){
            return;
        }
        const regex = /\/[A-Za-z]{2}\/?$/g;
        const result = regex.test(input);

        if(result == true){
            const output = input.replace(regex, `/${nuevoidio}/`);
            if(button == 2){
                newurl = window.location.href.toString().replace(regex, `/${nuevoidio}/`);
                window.open(newurl,'_blank');
            } else {
                window.location.replace(output);
            }

        }
        else if (input.includes("idio=")) {
            let url = new URL(window.location.href);
            let params = new URLSearchParams((url.search));
            let number = params.get("idio");
            params.set("idio", idiomanumero(nuevoidio));
            if(button == 2){
                console.log(number)
                newurl = window.location.href.toString().replace("idio="+number,"idio="+idiomanumero(nuevoidio))
                window.open(newurl,'_blank');
            } else {
                window.location.replace(url.origin + url.pathname + '?' + params);
            }

        }
        else if(input.includes("/noticia/")){
            if(button == 2){
                newurl = window.location.href.toString().concat("/" + nuevoidio )
                window.open(newurl,'_blank');
            } else{
                window.location.replace(input.concat("/" + nuevoidio ));
            }

        }
        else if(input.includes(".php")){

            if(button == 2){
                newurl = window.location.toString().concat("?idio=" + idiomanumero(nuevoidio))
                window.open(newurl,'_blank');
            } else{
                let inicioParametros = window.location.href.includes('?') ? '&' : '?';
                let nuevaUrl = `${input}${inicioParametros}idio=${idiomanumero(nuevoidio)}`;
                window.location.replace(nuevaUrl);
            }

        }
        else if(input.includes("/promocion/") || input.includes("/empreendimentos/")){
            var path = input.split("/")
            if (path[path.length-2] == 8){
                path[path.length-2] = 'pt';
            }

            var newurl = ""

            path[path.length-2] = idiomanumero(nuevoidio)

            path.forEach((element) =>  newurl += element+"/");

            newurl = newurl.slice(0,-1)

            if(button == 2){
                window.open(newurl,'_blank');
            } else{
                window.location.href = newurl;
            }

        }
        else {
            if(button == 2){
                newurl = window.location.href.toString().concat("" + nuevoidio )
                window.open(newurl,'_blank');
            } else{
                if ((input.includes("plantilla_prev=") || input.includes("agente=")) && !input.includes("idio=")) {
                    window.location.replace(input.concat("&idio=" + idiomanumero(nuevoidio)));
                }else{
                    window.location.replace(input.concat("" + nuevoidio ));
                }
            }

        }
    }
    //Mapeo de idiomas para comprobar su número
    function idiomanumero(nuevoidio) {
        switch(nuevoidio) {
            case "es":
                return 1;
            case "ca":
                return 12;
            case "eu":
                return 16;
            case "en":
                return 2;
            case "de":
                return 3;
            case "fr":
                return 4;
            case "it":
                return 15;
            case "no":
                return 6;
            case "fi":
                return 10;
            case "sv":
                return 9;
            case "ru":
                return 7;
            case "nl":
                return 5;
            case "zh":
                return 11;
            case "pl":
                return 17;
            case "pt":
                return 8;
            case "lt":
                return 22;
            case "da":
                return 19;
            case "gl":
                return 18;
            case "uk":
                return 24;
            case "bg":
                return 25;
        }
    }

</script>
<script src="js/modulos/cabecera/cabecera.js?x=20260506150310"></script>
<script>
    listados.destacadosestrella = [{"posicion":1,"elementos":1,"total":1},{"cod_ofer":12341515,"keyacci":1,"banyos":1,"ref":"002520","nodisponible":0,"precioinmo":87999,"preciotraspaso":0,"key_loca":41199,"key_zona":3355899,"key_tipo":3399,"m_parcela":0,"balcon":1,"m_cons":101,"m_uties":80,"conservacion":50,"calefacentral":0,"airecentral":0,"plaza_gara":0,"terraza":0,"ascensor":0,"montacargas":0,"muebles":0,"calefaccion":1,"aire_con":1,"primera_line":0,"piscina_com":0,"piscina_prop":0,"habitaciones":0,"total_hab":2,"sumaseos":1,"repercusion":871.27722772277,"nbtipo":"Flat","nbconservacion":"Refurbished","exclu":0,"parking":0,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":25,"eninternet":1,"zonaauxiliar":"","urbanizacion":0,"destacado":2,"habdobles":2,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.95066438137715,"latitud":38.083417983154,"mls":0,"numfotos":18,"fotoletra":13,"keypromo":0,"fechacambio":"2025-02-27 02:18:28","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":89900,"aseos":0,"tipomensual":"MES","srvfotos":15,"soysrv":15,"ciudad":"Orihuela","zona":"Zona Centro","keyprov":4,"foto":"https:\/\/fotos15.apinmo.com\/8569\/12341515\/13-1.jpg","tituloauto":"Flat Orihuela","tituloautoSliderdestacado":"Flat - Orihuela (Zona Centro) ","precioauto":"87.999 \u20ac","superficieauto":"101 mts","banyosauto":1,"fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/12341515\/13-1s.jpg","urlfichaauto":"ficha\/flat\/orihuela\/zona-centro\/8569\/12341515\/en\/"}];
    var destacadosestrellaActual = 1;

    var imagesCab = ["img/slider/1_*.jpg","","","img/slider/2_*.jpg","","","img/slider/3_*.jpg","","","img/slider/4_*.jpg","",""];</script>

<script src="js/modulos/slider/slider.js?x=20260506150310"></script>



<script>

    $(document).ready(function(){
        $(".buttonDesplegarComent").on("click", function(){
            $("#form-comentarios").show();
        });
        $("#spanPrivacidadAlertas").click(function () {
            modalNuestra('mytextoprivacidadAlerta',POLITICA_PRIVACIDAD);
        });
            //politica de privacidad;

        //enviar alerta
        $('#enviar_alerta').on('click', function(){
            var ok=true;
            var i=0;
            var ciudades="";
            var tipos="";

            //comprobamos  alguna ciudad
            i=0;
            //comprobamos  algun tipo
            $('.tiposAlerta input[type=checkbox]:checked').each(function() {
                i++;
                tipos+=this.value+",x,";
            });
            if(ok && i<1){
                alerta($('#errortipo').val());
                ok=false;
            }
            tipos=tipos.replace(/,+$/,'');

            if(ok && $("#telefonoAlertas").val()==""){
                alerta($('#errortelefono').val());
                ok=false;
            }
            if(ok && $("#nombreAlertas").val()==""){
                alerta($('#errornombre').val());
                ok=false;
            }
            if(ok && !validarEmail($("#mailAlertas").val())){
                alerta($('#erroremail').val());
                ok=false;
            }
            if(ok && $('#textolegal').prop('checked')==false){
                alerta($('#errorpolitica').val());
                ok=false;
            }

            // comprobamos que haya marcado algún tipo que require de habitaciones

            // Tipos que NO necesitan habitaciones
            var tmptipos=new Array (19,1199,1299,1399,1499,1599,1699,1799,2099,2199,2299,2399,2599,2699,3099,3299,3699,3799,3899,3999,4099,4199,4499,4699,4899,5099,6799,7199,7299,7399,7799,7899,7999,8099,8199,8299,8599,8699,8799,8899,8999,9099,9199); //tipos que NO necesitan habitaciones
            var tipos2= [];
            $('.tiposAlerta input[type=checkbox]:checked').each(function() {tipos2.push(this.value);});

            var NecesitaHabitacion = false;
            for (var i = 0; i < tipos2.length; i++) {
                if (!tmptipos.includes(parseInt(tipos2[i]))) {
                    NecesitaHabitacion = true;
                    break;
                }
            }

            let areas = $('#alertas iv-buscador-areas-webs').val();
            if(areas.length  < 3) {
                alerta($('#errorarea').val());
                ok=false;
            }

            if(ok && $("#tipohab").val()=="-1" && NecesitaHabitacion){
                alerta("* "+$('#errorhab').val());
                ok=false;
            }
            if(ok && $("#preciodesde").val()==""){
                alerta($('#errorpreciodesde').val());
                ok=false;
            }
            if(ok && $("#preciohasta").val()==""){
                alerta($('#errorpreciohasta').val());
                ok=false;
            }
            if(ok && parseInt($("#preciohasta").val())>parseInt($("#preciohasta").val()) ){
                alerta("El precio desde debe ser menor que el precio hasta");
                ok=false;
            }
            if(ok ){

                tipos.replace("undefined",0);
                var desde = $("#preciodesde").val();
                var hasta = $("#preciohasta").val();
                var habitaciones = ($("#tipohab").val()=="-1")? 0 : $("#tipohab").val();
                var nombre = $("#nombreAlertas").val();
                var email = $("#mailAlertas").val();
                var telefono = $("#telefonoAlertas").val();
                var idio = $("#idioma").val();
                var weborigen = $("#weborigen").val();
                $("button.enviar_alerta").prop("disabled", true);
                function enviandoAlerta(){
                    $("#modulo-alertas-1 button.enviar_alerta").addClass("enviando");
                };
                grecaptcha.ready(function() {
                    grecaptcha.execute('6LeFvHcUAAAAADkYzbLtZuO5lRdgl6gpLYovrRwl', {action: 'alertas'}).then(function(token) {
                        $.post( "modulos/__ajx/envios/enviosFormularios.php", {beforeSend: enviandoAlerta, token: token, desde: desde, hasta: hasta, habitaciones: habitaciones, nombre: nombre, telefono: telefono, email: email, areas: areas, tipos:tipos, idio: idio, weborigen: weborigen}, function( data ) {
                            $("#modulo-alerta-1 .resultadoAlerta").removeClass('ok ko');
                            if(data.resultado==true){

                                $("#modulo-alertas-1 .resultadoAlerta").addClass('ok');
                                $("#modulo-alertas-1 .resultadoAlerta").text($("#alertacreada").val());
                            }else{

                                $("#modulo-alertas-1 .resultadoAlerta").addClass('ko');
                                $("#modulo-alertas-1 .resultadoAlerta").text($("#erroralerta").val());
                            }
                            $("button.enviar_alerta").prop("disabled", false);
                            $("button.enviar_alerta").removeClass("enviando");
                            $("#modulo-alertas-1 .enviar_alerta").slideUp();
                            $("#modulo-alertas-1 .resultadoAlerta").slideDown();
                            setTimeout(function(){
                                $("#modulo-alertas-1 .resultadoAlerta").slideUp();
                                $("#modulo-alertas-1 .enviar_alerta").slideDown();
                                $("button.enviar_alerta").prop("disabled", false);
                            }, 4000);
                        },"json");
                    });
                });
            }
        });//fin funcion

    });//fin ready

</script>

<script>
    var EMAIL_INCORRECTO = 'Email is not valid.';
    var ACEPTAR_PRIVACIDAD = 'You must accept the Privacy Policy and Terms of Use.';
    var ACEPTAR_NEWSLETTERS = 'You must accept to receive newsletters';
    var POLITICA_PRIVACIDAD = 'Privacy Policy';
</script>

<script src="js/modulos/suscribete/suscribete.js?x=20260506150310"></script>
<script>
    var ACEPTAR_PRIVACIDAD = 'You must accept the Privacy Policy and Terms of Use.';
    var POLITICA_PRIVACIDAD = 'Privacy Policy';
    var ERROR_TLF = 'You must enter a valid phone number';
    var ERROR_EML = 'Wrong email address';
    var ERROR_NOM = 'Please fill in your name';
    var ERROR_CONSULTA = 'You must type your question';
    var TLF_OBLIGATORIO = '';
    var TEXTO_COOKIE_FIJO = '0';
</script>

<script src="js/modulos/pie/pie.js?x=20260506150310"></script>
<script src="js/suscribirsePush.js?x=20260506150310"></script>

<aside id="plugin-llamamos">
    <div>
        <i class="fas fa-comment fa-2x"></i>
        <span id="texto">QUESTION?</span>
    </div>
    <span id="tellamamos" class="plugin-llamamos-oculto">We'll call you back</span>
</aside>

<div id="plugin-llamamos-modal">
    <div id="plugin-llamamos-texto">
        Send this form with your name and phone number and we will contact you as soon as possible.    </div>
    <form id="plugin-llamamos-form">
        <label for="plugin-llamamos-nombre">Name:</label>
        <input type="text" id="plugin-llamamos-nombre" name="plugin-llamamos-nombre">
        <label for="plugin-llamamos-telefono">Telephone:</label>
        <input type="tel" id="plugin-llamamos-telefono" name="plugin-llamamos-telefono">
        <label for="plugin-llamamos-comentario">Questions, comments, contact schedule...</label>
        <textarea id="plugin-llamamos-comentario" name="plugin-llamamos-comentario"></textarea>

        <span class="textolegal" id="plugin-llamamos-textolegal">
            <div class="flex">
                <div class="bloque-checkbox">
                    <input type="checkbox" id="textolegal61" class="custom-checkbox">
                    <label for="textolegal61"></label>
                </div>
                <span class="textolegal" id="eltextolegal61">When you press the button “SEND” you confirm you’ve read, understood and accepted the conditions of our Privacy Policy shown in this LINK</span>
            </div>
        </span>
        <span class="resultadoInfo"></span>
        <button type="button" id="plugin-llamamos-enviar">
            Send        </button>
    </form>
</div><script>

    $(document).ready(function() {

        $("#plugin-llamamos").click(function () {
            modalNuestra('plugin-llamamos-modal', 'We\'ll call you back');

            $("#plugin-llamamos-textolegal #eltextolegal61").click(function () {
                modalNuestra('mytextoprivacidadFooter', POLITICA_PRIVACIDAD);
            });


            $("#plugin-llamamos-enviar").click(function () {

                var nombre = $("#plugin-llamamos-form #plugin-llamamos-nombre").val();
                if(nombre==""){
                    alerta("Introduce tu nombre");
                    return false;
                }
                var telefono = $("#plugin-llamamos-form #plugin-llamamos-telefono").val();
                if(telefono.length<9 || isNaN(telefono) ){
                    alerta("Introduce tu teléfono");
                    return false;
                }
                var comentario = $("#plugin-llamamos-form #plugin-llamamos-comentario").val();
                if(comentario==""){
                    alerta("Introduce tu comentario, duda u horario de contacto");
                    return false;
                }

                if(!document.getElementById('textolegal61').checked) {
                    alerta(ACEPTAR_PRIVACIDAD);
                    return false;
                }

                function enviandoTeLlamamos() {
                    $("#plugin-llamamos-form .resultadoInfo").text('');
                    $("#plugin-llamamos-form .resultadoInfo").removeClass('ok ko');
                    $("#plugin-llamamos-form .resultadoInfo").addClass("enviando");
                    $("#plugin-llamamos-form .resultadoInfo").fadeIn(50);
                };

                grecaptcha.ready(function () {
                    grecaptcha.execute('6LeFvHcUAAAAADkYzbLtZuO5lRdgl6gpLYovrRwl', {
                        action: 'llamamos'
                    }).then(function (token) {
                        $.post("modulos/__ajx/envios/enviosFormularios.php", {
                            beforeSend: enviandoTeLlamamos,
                            token: token,
                            nombre: nombre,
                            telefono: telefono,
                            comentario: comentario
                        }, function (data) {
                            $("#plugin-llamamos-form .resultadoInfo").removeClass('ok ko enviando');
                            if (data.resultado == false) {
                                $("#plugin-llamamos-form .resultadoInfo").addClass('ko');
                                $("#plugin-llamamos-form .resultadoInfo").text(data.mensaje);
                            }
                            else {
                                $("#plugin-llamamos-form .resultadoInfo").addClass('ok');
                                $("#plugin-llamamos-form .resultadoInfo").text(data.mensaje);
                            }

                            $("#plugin-llamamos-form .resultadoInfo").fadeIn();
                            setTimeout(function () {
                                $("#plugin-llamamos-form .resultadoInfo").fadeOut();
                            }, 4000);
                        }, "json");
                    });
                });
            });
        });
        var controlador=0;
        $(window).scroll(function() {
            if ($(document).height()-100 <= (($(window).height() + $(window).scrollTop()))) {
                if(controlador==0) {
                    $("#plugin-llamamos").fadeOut('fast');
                    controlador = 1;
                }
            }
            else {
                if(controlador==1) {
                    $("#plugin-llamamos").fadeIn('fast');
                    controlador=0;
                }

            }

        });


    });




</script><aside id="plugin-whatsapp" class="sombreado enviarPostHog" nombreEventoPostHog="Whatsapp" seccionPostHog="Contact">
        <i class="fab fa-whatsapp fa-2x"></i>
</aside>

<aside id="plugin-whatsapp-conversacion" clasS="sombreado">
    <div class="plugin-whatsapp-titulo">
        <span>WhatsApp</span>
        <span class="circle">X</span>
    </div>
    <div class="plugin-whatsapp-mensajes">
                <div>Hi!<span class="hora">18:22</span></div>
        <div>Click here to send us your questions through Whatsapp<span class="hora">18:22</span></div>
    </div>
    <div class="plugin-whatsapp-pie">
            <div class="emoji">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" id="smiley" x="3147" y="3209"><path fill-rule="evenodd" clip-rule="evenodd" d="M9.153 11.603c.795 0 1.44-.88 1.44-1.962s-.645-1.96-1.44-1.96c-.795 0-1.44.88-1.44 1.96s.645 1.965 1.44 1.965zM5.95 12.965c-.027-.307-.132 5.218 6.062 5.55 6.066-.25 6.066-5.55 6.066-5.55-6.078 1.416-12.13 0-12.13 0zm11.362 1.108s-.67 1.96-5.05 1.96c-3.506 0-5.39-1.165-5.608-1.96 0 0 5.912 1.055 10.658 0zM11.804 1.01C5.61 1.01.978 6.034.978 12.23s4.826 10.76 11.02 10.76S23.02 18.424 23.02 12.23c0-6.197-5.02-11.22-11.216-11.22zM12 21.355c-5.273 0-9.38-3.886-9.38-9.16 0-5.272 3.94-9.547 9.214-9.547a9.548 9.548 0 0 1 9.548 9.548c0 5.272-4.11 9.16-9.382 9.16zm3.108-9.75c.795 0 1.44-.88 1.44-1.963s-.645-1.96-1.44-1.96c-.795 0-1.44.878-1.44 1.96s.645 1.963 1.44 1.963z" fill="#7d8489"></path></svg>
            </div>
            <input id="mensajeWhatsapp" class="input-msg" name="input" placeholder="Write your message" autocomplete="off">
            <div class="photo">
                <i class="fas fa-camera"></i>
            </div>
            <button class="send">
                <div class="circle" id="envioWhatsapp">
                    <i class="fab fa-telegram-plane"></i>
                </div>
            </button>
    </div>

</aside>
<script>

    $(document).ready(function() {

        $("#plugin-whatsapp").click(function () {
            $("#plugin-whatsapp-conversacion").css("bottom","10px");
            //whatsapp://send?abid=username&text=Hello%2C%20World!
        });

        $("#envioWhatsapp").click(function () {
            var inmotelefono="34669871698";
            if($("#mensajeWhatsapp").val()!="") {
                if(actual == 'fichapropiedad.php')
                    var elMensaje = '"Ask from the web about reference ' + listados.fichapropiedad[1].ref + '": ' + $("#mensajeWhatsapp").val();
                else
                    var elMensaje = '"Ask from the web": ' + $("#mensajeWhatsapp").val();

                window.open("https://api.whatsapp.com/send?phone=" + inmotelefono + "&text=" + elMensaje, "", "_blank");
            }else
                alert("You can't send a blank message.");
        });



    });



    $(document).on('click', function (e) {
        if (($(e.target).closest("#plugin-whatsapp-conversacion").length === 0 && $(e.target).closest("#plugin-whatsapp").length === 0) || $(e.target).closest(".plugin-whatsapp-titulo .circle").length > 0) {
            $("#plugin-whatsapp-conversacion").css("bottom","-280px");
        }
    });


</script>    <script>
        $(document).ready(function(){
            if(esMovil == '1')
                var posicionScroll = $("#modulo-alertas-1").offset().top;
            else
                var posicionScroll = $("#modulo-alertas-1").offset().top - $('.modulo-cabecera').height();
            $([document.documentElement, document.body]).animate({
                scrollTop: posicionScroll
            }, 300);
        });
        </script>
<div class="modalesOcultas">
  <div id="mytextolegal">
      </div>

  <div id="mytextoprivacidadAlerta">
      <div class="rpgdPrivacid" style="margin-bottom: 20px;">
          <p><b>Responsable:</b> XXXXX</p>
          <p><b>Finalidad:</b> To send information about real estate that match the requirements of the client presented by filling this form.</p>
    <p><b>Legitimación:</b> To implement pre-contract measures to the clients request (budget request or information about our professional services).</p>
    <p><b>Destinatarios:</b> This data will arrive at the office and there is no expected data transfer if not for legal obligation.</p>
    <p><b>Derechos:</b> You may use your right to access, modify, suppress, oppose, transfer or withdraw your consent on your personal data through the email XXXXXX@XXXXXXX.es</p>
  </div>
    </div>

  <div id="mytextoprivacidadPublica">
      <div class="rpgdPrivacid" style="margin-bottom: 20px;">
          <p><b>Responsable:</b> XXXXX</p>
          <p><b>Finalidad:</b> To send information about your property to the real estate agency so it can evaluate if it will offer your property to its clients to try to sell or rent it.</p>
    <p><b>Legitimación:</b> The legitimacy is based on the consent you gave us when clicking the button “I accept the data protection policy”.</p>
    <p><b>Destinatarios:</b> The client’s data won’t be transferred to anyone, if not for legal obligation. The real estate’s data might be delivered to collaborating real estate agencies or published on web pages and real estate portals.</p>
    <p><b>Derechos:</b> You may use your right to access, modify, suppress, oppose, transfer or withdraw your consent on your personal data through the email XXXXXX@XXXXXXX.es</p>
  </div>
    </div>

  <div id="mytextoprivacidadFooter">
      <div class="rpgdPrivacid" style="margin-bottom: 20px;">
          <p><b>Responsable:</b> XXXXX</p>
          <p><b>Finalidad:</b> To handle information requests through the website, aiming to offer real estate professional services and to give information about what’s requested.</p>
    <p><b>Legitimación:</b> The legitimacy is based on the consent you gave us when clicking the button “I accept the data protection policy”.</p>
    <p><b>Destinatarios:</b> Your data won’t be transferred to anyone, if not for legal obligation.</p>
    <p><b>Derechos:</b> You may use your right to access, modify, suppress, oppose, transfer or withdraw your consent on your personal data through the email XXXXXX@XXXXXXX.es</p>
  </div>
    </div>

  <div id="mytextoprivacidadInfoProp">
      <div class="rpgdPrivacid" style="margin-bottom: 20px;">
          <p><b>Responsable:</b> XXXXX</p>
          <p><b>Finalidad:</b> To handle information requests through the website, aiming to offer real estate professional services and to give information about what’s requested.</p>
    <p><b>Legitimación:</b> The legitimacy is based on the consent you gave us when clicking the button “I accept the data protection policy”.</p>
    <p><b>Destinatarios:</b> Your data won’t be transferred to anyone, if not for legal obligation.</p>
    <p><b>Derechos:</b> You may use your right to access, modify, suppress, oppose, transfer or withdraw your consent on your personal data through the email XXXXXX@XXXXXXX.es</p>
  </div>
    </div>

  <div id="mytextocookies">
      </div>
</div>



    <script>
        var textocookies = `<link rel=\"stylesheet\" href=\"css/estiloCookies.css\" type=\"text/css\">
<div class=\"grid-container\">
    <div>
        <H4><strong>DEFINITION OF COOKIES</strong></H4>
        <br/>

        <p>Cookies are identifiers that we send to your computer\'s hard drive through your Web browser so that our systems can recognize your browser and offer you certain services. In general, these technologies can serve very different purposes, for example, to recognize you as a user, obtain information about your browsing habits, or customize the way the content is displayed. This page uses different types of cookies. Some cookies are placed by third-party services that appear on our pages. Cookies can be:</p>

        <h3>Preference cookies</h3>
        <p>Preference cookies allow the website to remember information that changes the way the page behaves or the way it looks, such as your preferred language or the region in which you are located.</p>

        <h3>Statistics Cookies</h3>
        <p>Statistical cookies help web page owners understand how visitors interact with web pages by collecting and providing information anonymously. To disable Google Analytics cookies, you can install the Google Analytics opt-out for browsers add-on that will allow you not to send statistical information. It is available at the following link: https://tools.google.com/dlpage/gaoptout?hl=es</p>

        <h3>Marketing cookies</h3>
        <p>Marketing cookies are used to track visitors on web pages. The intention is to display ads that are relevant and attractive to the individual user, and therefore more valuable to publishers and third-party advertisers.</p>

        <p> </p>
        <H4><strong>HOW TO DISABLE COOKIES IN THE MAIN BROWSERS:</strong></H4>
        <br/>
        <p>It is normally possible to stop accepting browser Cookies, or stop accepting Cookies from a particular Service.</p>
        <p>All modern browsers allow you to change the cookie settings. These settings are usually found in the \'options\' or \'Preferences\' of your browser menu. You can also configure your browser or your email manager.</p>
        <p>The following provides guidance to the User on the steps to access the cookie configuration menu and, where appropriate, private browsing in each of the main browsers:</p>
        <p>Internet Explorer: Tools -> Internet Options -> Privacy -> Configuration. For more information, you can consult Microsoft support or browser Help.</p>
        <p>Firefox: Tools -> Options -> Privacy -> History -> Custom Settings. For more information, you can consult Mozilla support or browser Help.</p>
        <p>Chrome: Settings -> Show advanced options -> Privacy -> Content settings. For more information, you can consult Google support or browser Help.</p>
        <p>Safari: Preferences -> Security. For more information, you can consult Apple support or browser Help.</p>
        <p>What happens if Cookies are disabled?</p>
        <p>Some functionalities of the Services will be disabled.</p>

        <br/>


    </div>
    <div>


        <h3>Cookies used:</h3>
        <p>Next, we show you the cookies that this webpage uses:</p>

        <table border=\"0px\" cellpadding=\"0px\" cellspacing=\"0px\" style=\"width:100%\">
            <tbody>
            <tr>
                <td style=\"height:13px; width:89px\">
                    <p><strong>Name</strong></p>
                </td>
                <td style=\"height:13px; width:47px\">
                    <p><strong>Type</strong></p>
                </td>
                <td style=\"height:13px; width:246px\">
                    <p><strong>Description/Purpose</strong></p>
                </td>
                <td style=\"height:13px; width:132px\">
                    <p><strong>Duration</strong></p>
                </td>
                <td style=\"height:13px; width:85px\">
                    <p><strong>Owner</strong></p>
                </td>
                <td style=\"height:13px; width:85px\">
                    <p><strong>Accept</strong></p>
                </td>
            </tr>
            <tr>
                <td style=\"height:77px; width:89px\">
                    <p><strong>cookies_accepted,<br />
                        cookies_accepted_vdf,<br />
                        cookies_accepted_add_1,
                        cookies_accepted_metric,
                        cookies_accepted_google</strong></p>
                </td>
                <td style=\"height:77px; width:47px\">
                    <p>Technique</p>
                </td>
                <td style=\"height:77px; width:246px\">
                    <p>Enabling/disabling the cookie information bar and the selected cookies.</p>
                </td>
                <td style=\"height:77px; width:132px\">
                    <p>1 years from start, browser session.</p>
                </td>
                <td style=\"height:77px; width:85px\">
                    <p>Inmovilla</p>
                </td>
                <td style=\"height:77px; width:85px\"><input checked=\"checked\" disabled=\"disabled\" id=\"cookies_accepted_ca\" type=\"checkbox\" /> <span style=\"color: grey\">Cookie required</span></td>
            </tr>
            <tr>
                <td style=\"height:30px; width:89px\">
                    <p><strong>PHPSESSID</strong></p>
                </td>
                <td style=\"height:30px; width:47px\">
                    <p>Technique</p>
                </td>
                <td style=\"height:30px; width:246px\">
                    <p>Login information, for quick start page loading</p>
                </td>
                <td style=\"height:30px; width:132px\">
                    <p>Session</p>
                </td>
                <td style=\"height:30px; width:85px\">
                    <p>Inmovilla</p>
                </td>
                <td style=\"height:77px; width:85px\"><input checked=\"checked\" disabled=\"disabled\" id=\"cookies_accepted_phpsid\" type=\"checkbox\" /> <span style=\"color: grey\">Cookie required</span></td>
            </tr>
            <tr>
                <td style=\"height:30px; width:89px\">
                    <p><strong>vistas,<br />
                        favoritas,<br />
                        descartadas</strong></p>
                </td>
                <td style=\"height:30px; width:47px\">
                    <p>Preference cookies</p>
                </td>
                <td style=\"height:30px; width:246px\">
                    <p>This cookie is used to save the viewed, discarded or favorite properties.</p>
                </td>
                <td style=\"height:30px; width:132px\">
                    <p>Session</p>
                </td>
                <td style=\"height:30px; width:85px\">
                    <p>Inmovilla</p>
                </td>
                <td style=\"height:77px; width:85px\"><input id=\"cookies_accepted_vdf\" type=\"checkbox\" /></td>
            </tr>
            </tbody>
        </table>
        &nbsp;

        <h3><u>Third party cookies:</u></h3>
        &nbsp;

        <table border=\"0px\" cellpadding=\"0px\" cellspacing=\"0px\" style=\"width:100%\">
            <tbody>
            <tr>
                <td style=\"height:13px; width:89px\">
                    <p><strong>Name</strong></p>
                </td>
                <td style=\"height:13px; width:47px\">
                    <p><strong>Type</strong></p>
                </td>
                <td style=\"height:13px; width:246px\">
                    <p><strong>Descrption/Purpose</strong></p>
                </td>
                <td style=\"height:13px; width:132px\">
                    <p><strong>Duration</strong></p>
                </td>
                <td style=\"height:13px; width:85px\">
                    <p><strong>Owner</strong></p>
                </td>
                <td style=\"height:13px; width:85px\">
                    <p><strong>Accept</strong></p>
                </td>
            </tr>
            <tr>
                <td style=\"height:30px; width:89px\">
                    <p><strong>__cfduid</strong></p>
                </td>
                <td style=\"height:30px; width:47px\">
                    <p>Technique</p>
                </td>
                <td style=\"height:30px; width:246px\">
                    <p>It is established by the CloudFlare service to identify trusted web traffic. It does not correspond to any user id in the web application, nor does it save any personally identifiable data.</p>
                </td>
                <td style=\"height:30px; width:132px\">
                    <p>1 years from login</p>
                </td>
                <td style=\"height:30px; width:85px\">
                    <p>CloudFlare</p>
                </td>
                <td rowspan=\"2\" style=\"height:77px; width:85px\"><input id=\"cookies_accepted_add_1\" type=\"checkbox\" /></td>
            </tr>
            <tr>
                <td style=\"height:30px; width:89px\">
                    <p><strong>uvc</strong></p>
                </td>
                <td style=\"height:30px; width:47px\">
                    <p>Marketing</p>
                </td>
                <td style=\"height:30px; width:246px\">
                    <p>See policy: https://www.addtoany.com/buttons/faq/#gdpr and https://www.addtoany.com/privacy</p>
                </td>
                <td style=\"height:30px; width:132px\">
                    <p>1 day</p>
                </td>
                <td style=\"height:30px; width:85px\">
                    <p>Addtoany.com</p>
                </td>
                <!--td style=\"height:77px; width:85px\">
                            <input type=\"checkbox\" id=\"cookies_accepted_add_2\" checked=\"checked\"/> <span></span>
                        </td-->
            </tr>
            <!-- -->
            <tr>
                <td style=\"height:30px; width:89px\">
                    <p><strong>ANID, NID</strong></p>
                </td>
                <td style=\"height:30px; width:47px\">
                    <p>Marketing</p>
                </td>
                <td style=\"height:30px; width:246px\">
                    <p>For the count, by Google, of the number of users that use the maps.</p>
                </td>
                <td style=\"height:30px; width:132px\">
                    <p>6 Months</p>
                </td>
                <td style=\"height:30px; width:85px\">
                    <p>google maps</p>
                </td>
                <td style=\"height:77px; width:85px\"><input checked=\"checked\" disabled=\"disabled\" id=\"cookies_accepted_google1\" type=\"checkbox\" /> <span style=\"color: grey\">Cookie required</span></td>
            </tr>
            <tr>
                <td style=\"height:30px; width:89px\">
                    <p><strong>CONSENT</strong></p>
                </td>
                <td style=\"height:30px; width:47px\">
                    <p>Marketing</p>
                </td>
                <td style=\"height:30px; width:246px\">
                    <p>Technical cookie to control the acceptance of cookies.</p>
                </td>
                <td style=\"height:30px; width:132px\">
                    <p>Permanent</p>
                </td>
                <td style=\"height:30px; width:85px\">
                    <p>google.com</p>
                </td>
                <td style=\"height:77px; width:85px\"><input checked=\"checked\" disabled=\"disabled\" id=\"cookies_accepted_google2\" type=\"checkbox\" /> <span style=\"color: grey\">CCookie required</span></td>
            </tr>
            <tr>
                <td style=\"height:30px; width:89px\">
                    <p><strong>DV</strong></p>
                </td>
                <td style=\"height:30px; width:47px\">
                    <p>Msrketing</p>
                </td>
                <td style=\"height:30px; width:246px\">
                    <p>It is used by Google to provide services and extract anonymous information about browsing.</p>
                </td>
                <td style=\"height:30px; width:132px\">
                    <p>24 hours</p>
                </td>
                <td style=\"height:30px; width:85px\">
                    <p>google.com</p>
                </td>
                <td style=\"height:77px; width:85px\"><input checked=\"checked\" disabled=\"disabled\" id=\"cookies_accepted_google3\" type=\"checkbox\" /> <span style=\"color: grey\">Cookie required</span></td>
            </tr>
            <tr>
                <td style=\"height:30px; width:89px\">
                    <p><strong>1P_JAR</strong></p>
                </td>
                <td style=\"height:30px; width:47px\">
                    <p>Marketing</p>
                </td>
                <td style=\"height:30px; width:246px\">
                    <p>To personalize the ads according to the user\'s interests.</p>
                </td>
                <td style=\"height:30px; width:132px\">
                    <p>1 month</p>
                </td>
                <td style=\"height:30px; width:85px\">
                    <p>google.com</p>
                </td>
                <td style=\"height:77px; width:85px\"><input checked=\"checked\" disabled=\"disabled\" id=\"cookies_accepted_google4\" type=\"checkbox\" /> <span style=\"color: grey\">Cookie required</span></td>
            </tr>
            </tbody>
        </table>
    </div>
</div>`;
        var aceptar_todas = `Accept all`;
        var rechazar = `Reject`;
        var aceptar_selec = `Accept selected`;
        var cerrar = `Close`;
        var gestionarcookies = `Manage Cookies`;
        var textoaviso = `This site uses cookies.`;
        var politicacookies = `Cookies policy`;
    </script>
                    <script>
                    function textoBoton() {
                        if (document.getElementById('aceptarCookies_boton').innerHTML == aceptar_todas)
                            return aceptar_selec;

                        if (document.getElementById('aceptarCookies_boton').innerHTML == aceptar_selec)
                            return aceptar_todas;

                        if (document.getElementById('botonrechazar_aviso_entrada').innerHTML == rechazar)
                            return aceptar_selec;
                    }
                    function textoBottonGestionar() {
                        if (document.getElementById('cookieShowMoreInfo').innerHTML == gestionarcookies)
                            return cerrar;

                        if (document.getElementById('cookieShowMoreInfo').innerHTML == cerrar)
                            return gestionarcookies;
                    }
                </script>
                <div id='aviso-cookies'>
                    This site uses cookies.<br/>
                    <a id="aceptarCookies_boton" onclick='cookieHide()'>Accept all</a>
                    <a id="cookieShowMoreInfo" href='#' onclick='cookieShowMoreInfo(event,textocookies,textoBoton(),textoBottonGestionar())'>Manage Cookies</a>
                    <a id="rechazarCookies_boton" onclick='cookieHideRechazar()'>Reject</a>
                    <div id="mas-detalles-cookies"></div>
                </div>
              </body>
</html>
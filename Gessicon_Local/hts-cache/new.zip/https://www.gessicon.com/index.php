
<!doctype html>
<html lang="en">
<head>

    
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <base href="https://www.gessicon.com">
    <link href="favicon.png" rel="shortcut icon" type="image/x-icon"/>

    <!-- metas -->
            <title>Pisos en Orihuela | Inmobiliarias Orihuela | Promociones ...</title>
        <meta name="title" content="Pisos en Orihuela , Inmobiliarias Orihuela , Promociones ..." />
        <meta name="description" content="Promociones Apihogares S.l con multitud de propiedades, pisos , chalet , casas, villas en todas las zonas y localidades, incluyendo toda la provincia de Alic..." />
        <meta name="robots" content="all" />        <meta name="keywords" content="Promociones Apihogares S.l, inmobiliaria, real estate, promociones , obra nueva, promotores, inmobilien, Alicante, pisos, casas, campo, chalet , property, villa, venta , spain , inmobiliarias, real state, costa , coast ,apartamento" />
        <meta name="author" content="www.inmovilla.com, inmovilla dise&ntilde;o web" />

                <meta property="og:title" content="Pisos en Orihuela , Inmobiliarias Orihuela , Promociones Apihogares S.l"/>
        <meta property="og:description" content="Promociones Apihogares S.l con multitud de propiedades, pisos , chalet , casas, villas en todas las zonas y localidades, incluyendo toda la provincia de Alicante"/>
        <meta property="og:url" content="https://www.gessicon.com/index.php"/>
        <meta property="og:type" content="website"/>
        <meta property="fb:admins" content="494641230470"/>
        <meta property="fb:app_id" content="426208334088115"/>
        <meta property="og:image"  content="https://www.gessicon.com/img/header/logo.png"/>
        
        
        <link rel="canonical" href="https://www.gessicon.com/en" />

    
    <style type="text/css">
        :root {
          --background1: #ffffff;
  --background1-78: #ffffff;
  --color1: #0051e6;
  --color1-78: #0051e6;
  --background2: #f0610e;
  --background2-78: #f0610e;
  --color2: #0519f2;
  --color2-78: #0519f2;
  --background3: #be00ed;
  --background3-78: #be00ed;
  --color3: #ffffff;
  --color3-78: #ffffff;

            --colorTextos: #fff;
            --colorTextos2: #333;
        }
                .fotopropiedad::after,
        .visorficha .visorficha-miniaturas li::after {
            display: block;
            opacity: 0.7;
        }
    </style>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Courgette|Muli|Comfortaa|Stardos+Stencil:700" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">
    <link rel="stylesheet" href="css/reset.css?x=20260506150310" type="text/css">
    <link rel="stylesheet" href="css/fuentes.css?x=20260506150310" type="text/css">
    <link rel="stylesheet" href="css/estiloCookies.css?x=20260506150310" type="text/css">
    <link rel="stylesheet" href="css/estilo.css?x=20260506150310" type="text/css">
    <link rel="stylesheet" href="buscadorareas/style.css?x=20260506150310" type="text/css">
    <link rel="stylesheet" href="buscadorareas/componentes-v3-externo.css?x=20260506150310" type="text/css">
    <link rel="stylesheet" href="css/modulo-disenyadoinmovilla-1.css?x=20260506150310" type="text/css">
    <link rel="stylesheet" href="css/estiloCookies.css?x=20260506150310" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.0/css/all.css">
        <link rel="stylesheet" href="css/modulo-cabecera-1.css?x=20260506150310" type="text/css">
                <link rel="stylesheet" href="css/modulo-slider-1.css?x=20260506150310" type="text/css">
                <link rel="stylesheet" href="css/modulo-destacados-1.css?x=20260506150310" type="text/css">
        
            <link rel="stylesheet" href="css/modulo-paginacionmapa-1.css?x=20260506150310" type="text/css">        <link rel="stylesheet" href="css/modulo-paginacion-1.css?x=20260506150310" type="text/css">
                <link rel="stylesheet" href="css/modulo-mapapropiedades-1.css?x=20260506150310" type="text/css">
                <link rel="stylesheet" href="css/modulo-valoramostupiso-1.css?x=20260506150310" type="text/css">
                <link rel="stylesheet" href="css/modulo-equipo-1.css?x=20260506150310" type="text/css">
                <link rel="stylesheet" href="css/modulo-suscribete-1.css?x=20260506150310" type="text/css">
                <link rel="stylesheet" href="css/modulo-ultimasentradas-1.css?x=20260506150310" type="text/css">
                <link rel="stylesheet" href="css/modulo-pie-1.css?x=20260506150310" type="text/css">
                <link rel="stylesheet" href="css/plugin-llamamos-1.css?x=20260506150310" type="text/css">
                <link rel="stylesheet" href="css/plugin-whatsapp-1.css?x=20260506150310" type="text/css">
        
    <script>
        //var tienemetricool = 0;
        var tienegooglanalitics = 0;
    </script>


</head>


<body>




<input type="hidden" id="errornombre" value="Please fill in your name">
<input type="hidden" id="erroremail" value="Wrong email address">
<input type="hidden" id="erroremailotelefono" value="You must provide email or phone number">
<input type="hidden" id="erroredebesseleccionarciudad" value="To search with the map you must select a city">
<input type="hidden" id="errortelefono" value="You must enter a valid phone number">
<input type="hidden" id="errorpolitica" value="You must accept the privacy policy">
<input type="hidden" id="errorconsulta" value="Please write your query">
<input type="hidden" id="consultaenviada" value="Consult sended">
<input type="hidden" id="errortipo" value="You have to select a type of property">
<input type="hidden" id="errorarea" value="You must select an area">
<input type="hidden" id="errorpreciodesde" value="You must enter price from">
<input type="hidden" id="errorpreciohasta" value="You must enter price to">
<input type="hidden" id="errorhab" value="You must point out the bedrooms">
<input type="hidden" id="erroralerta" value="The alert has not been able to create">
<input type="hidden" id="alertacreada" value="The warning has been given high property shortly receive your email">
<input type="hidden" id="propiedadfavorita" value="Property added to favorites">
<input type="hidden" id="propiedadeliminadafavorita" value="Property removed from Favorites">
<input type="hidden" id="propiedaddescartada" value="Property discarded">
<input type="hidden" id="propiedadeliminadadescartada" value="Property removed from Discarded">
<input type="hidden" id="proponerprecio" value="Write your price proposal and comments">
<input type="hidden" id="errorcomentarionoticia" value="Failed to send your comment">
<input type="hidden" id="comentarionoticiacreado" value="Comment sent successfully">
<input type="hidden" id="comentarionoticiarevision" value="Your comment was successfully sent. It will soon be reviewed and published.">
<input type="hidden" id="aceptar_modal" value="Accept">



    <div id="supercontenedor" class="flex-column bloque-100">
<!-- cabecera-1 / Cabecera y Pestañas -->
<header id="modulo-cabecera-1" class="bloque-modulo modulo-cabecera flex-column">
  <div id="header-bloqueidiomas" class="bloque-100 flex-justify-end">
      <ul class="flex-justify-end">
        
            <li>
                <a onmousedown="idioma('es',event)"><img id="idio" src="img/header/bandera_01.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('ca', event)" ><img id="idio" src="img/header/bandera_12.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('eu',event)"><img id="idio" src="img/header/bandera_16.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('en',event)"><img id="idio" src="img/header/bandera_02.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('de',event)"><img id="idio" src="img/header/bandera_03.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('fr',event)"><img id="idio" src="img/header/bandera_04.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('it',event)"><img id="idio" src="img/header/bandera_15.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('no',event)"><img id="idio" src="img/header/bandera_06.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('fi',event)"><img id="idio" src="img/header/bandera_10.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('sv',event)"><img id="idio" src="img/header/bandera_09.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('ru',event)"><img id="idio"src="img/header/bandera_07.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('nl',event)"><img id="idio" src="img/header/bandera_05.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('zh',event)"><img id="idio" src="img/header/bandera_11.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('pl',event)"><img id="idio"src="img/header/bandera_17.png"></a>
            </li>
          
            <li>
                <a onmousedown="idioma('pt',event)"><img id="idio" src="img/header/bandera_08.png"></a>
            </li>
            
      </ul>
  </div>
  <div id="header-bloque2" class="bloque-100 bg-color1">
    <h2 id="header-logo" class="flex">
      <a href="https://www.gessicon.com"><img src="img/header/logo.png" alt="Promociones Apihogares S.l"></a>
    </h2>
    <div id="header-bloquemenu" class="flex-column flex-justify-between flex-align-end">
        
            <div id="header-bloquetfno">
                <a href="tel:638 062 858">
                    <img src="img/tel.png" alt="Teléfono 638 062 858">
                    <span id="border">638 062 858</span>
                </a>
                <div id="texto-telefono">
                    
                </div>
            </div>
            
      <nav class="header-menu" seccionPostHog="Menu">
        <ul>
        <li class="menuPrincipalCabecera enviarPostHog  activa " nombreEventoPostHog="Home"><a href="index.php" >Home</a></li><li class="menuPrincipalCabecera enviarPostHog " nombreEventoPostHog="For sale"><a href="for-sale/" >For sale</a></li><li class="menuPrincipalCabecera enviarPostHog " nombreEventoPostHog="Rental"><a href="rental/" >Rental</a></li><li class="menuPrincipalCabecera enviarPostHog " nombreEventoPostHog="Promotions"><a href="promotions/" >Promotions</a></li><li class="menuPrincipalCabecera enviarPostHog " nombreEventoPostHog="Company"><a href="seccion/company/company/en/" >Company</a></li><li class="menuPrincipalCabecera enviarPostHog  enlaceAcontacto " nombreEventoPostHog="Contact us"><a href="#Contact us" >Contact us</a></li>
        </ul>
      </nav>
    </div>
  </div>
    <div id="cabecera-bloque-buscador" class="d-none cabecera-bloque-buscador-horizontal noDestacado">
    <div id="cabecera-buscador" seccionPostHog="Search" class="d-none buscadorRapido flex-align-center">
        <div id="inmotipos" class="buscadorTipos custom-select-html enviarPostHog" nombreEventoPostHog="Property Type" original-txt="Property Type"
             data-txt="Property Type">
            <ul class="cajaGrupoTipos cajaGrupoTiposZonas">
        <li>
            <div class="grupoTipoZona">
                <input type="checkbox" class="marcarTodas">
                <span>All</span>
            </div>
        </li>
                    <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="6299,7599" >
                    <span><u> Rustic house</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="6299" >
                                <span>Village house</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="7599" >
                                <span>House with land</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="7499,199,299,399,21199,499,5499,6499" >
                    <span><u> House/Chalet</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="7499" >
                                <span>Bungalow Ground Floor</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="199" >
                                <span>Terraced house</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="299" >
                                <span>Bungalow</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="399" >
                                <span>House</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="21199" >
                                <span>Duplex House</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="499" >
                                <span>Single family house</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="5499" >
                                <span>Bungalow Top Floor</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="6499" >
                                <span>Luxury Villa</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="1699" >
                    <span><u> Building</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1699" >
                                <span>Building</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="2399,2599" >
                    <span><u> Garage </u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="2399" >
                                <span>Garage</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="2599" >
                                <span>Parking</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="1299" >
                    <span><u> Premises or Warehouse</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1299" >
                                <span>Business Premise</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="1199,1399" >
                    <span><u> Office</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1199" >
                                <span>Office</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1399" >
                                <span>Office</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="3399,3499,2999" >
                    <span><u> Apartment</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="3399" >
                                <span>Flat</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="3499" >
                                <span>Ground floor apartment</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="2999" >
                                <span>Duplex</span>
                            </div>
                        </li>
                                        </ul>
            </li>
            
    </ul>
        </div>
        <div class="flex-column componentes-v3">
            <label class="custom-select enviarPostHog" nombreEventoPostHog="Areas">
                <iv-buscador-areas-webs
                        url="https://apiweb.inmovilla.com/apiweb/config/8569_185.57.173.244_1/areas.json"
                        minlength="3"
                        multiple
                        value=""
                        onchange="$('iv-buscador-areas-webs').val(this.value)"
                        placeholder="Enter the area you are looking for..."
                        placeholderbuscador="Enter the area you are looking for..."
                        textoerror="An error occurred"
                        textosinresultados="No results"
                        avisoresultadoslimitados="Showing more relevant results, enter a more detailed search"
                        idioma="2"
                ></iv-buscador-areas-webs>
            </label>
        </div>

    <div class="bloque-input slider-buscador-precio enviarPostHog" nombreEventoPostHog="Price from">
        <input id="precioDesdeRapido" type="number" placeholder="Price from" class="fuerzaBusqueda inputBuscador inputBuscadorDesde" claseSincroniza="inputBuscadorDesde" value="">
    </div>
    <div class="bloque-input slider-buscador-precio enviarPostHog" nombreEventoPostHog="Price up to">
        <input id="precioHastaRapido" type="number" placeholder="Price to" class="fuerzaBusqueda inputBuscador inputBuscadorHasta" claseSincroniza="inputBuscadorHasta" value="">
    </div>
    <div class="bloque-input slider-buscador-ref enviarPostHog" nombreEventoPostHog="Reference">
        <input id="refRapido" type="text" placeholder="Ref" class="bg-color fuerzaBusqueda inputBuscador inputBuscadorRef" claseSincroniza="inputBuscadorRef"
               value="">
    </div>
    
        <div class="bloque-checkbox enviarPostHog" nombreEventoPostHog="See map">
            <input type="checkbox" id="verMapaRapidoCabecera"  class="buscadorVerMapa custom-checkbox">
            <label for="verMapaRapidoCabecera">See Map</label>
        </div>
    
    <div class="buttons">
        <button class="avanzado enviarPostHog" nombreEventoPostHog="Advanced">Advanced</button>
        <button class="buscarRapido enviarPostHog" nombreEventoPostHog="Search for" onclick="busquedaBuscadorRapido($(this))">Search</button>
    </div>
</div>
</div><link rel='stylesheet' href='css/componentes/buscadorcabecera-1.css?x=20260506150310' type='text/css'>
</header>
<!-- slider-1 / Slider Principal y Buscador -->

    <section id="modulo-slider-1" class="bloque-modulo flex-column relative">

    <div class="slider-1">

            <div class="slider-imagen" id="img1">
                <span id="slider-textoEstrella" posslider=""></span>
            </div>
            <div class="slider-botonAnterior" onClick="SliderCabecera(PosSlider-3);"></div>
            <div class="slider-botonSiguiente" onClick="SliderCabecera(PosSlider+3);"></div>

    </div>

    
        <h1 id="slider-slogan-vertical">Encontramos la casa de tus sueños</h1>
    



        <div id="slider-bloque-buscador" class="slider-bloque-buscador-1 noDestacado">
    
        <div id="slider-buscador" seccionPostHog="Search" class="buscadorRapido flex-align-top " >
            <div id="inmotipos" class="buscadorTipos custom-select-html enviarPostHog" nombreEventoPostHog="Property Type" original-txt="Property Type" data-txt="Property Type">
                <ul class="cajaGrupoTipos cajaGrupoTiposZonas">
        <li>
            <div class="grupoTipoZona">
                <input type="checkbox" class="marcarTodas">
                <span>All</span>
            </div>
        </li>
                    <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="6299,7599" >
                    <span><u> Rustic house</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="6299" >
                                <span>Village house</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="7599" >
                                <span>House with land</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="7499,199,299,399,21199,499,5499,6499" >
                    <span><u> House/Chalet</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="7499" >
                                <span>Bungalow Ground Floor</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="199" >
                                <span>Terraced house</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="299" >
                                <span>Bungalow</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="399" >
                                <span>House</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="21199" >
                                <span>Duplex House</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="499" >
                                <span>Single family house</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="5499" >
                                <span>Bungalow Top Floor</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="6499" >
                                <span>Luxury Villa</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="1699" >
                    <span><u> Building</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1699" >
                                <span>Building</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="2399,2599" >
                    <span><u> Garage </u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="2399" >
                                <span>Garage</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="2599" >
                                <span>Parking</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="1299" >
                    <span><u> Premises or Warehouse</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1299" >
                                <span>Business Premise</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="1199,1399" >
                    <span><u> Office</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1199" >
                                <span>Office</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1399" >
                                <span>Office</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="3399,3499,2999" >
                    <span><u> Apartment</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="3399" >
                                <span>Flat</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="3499" >
                                <span>Ground floor apartment</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="2999" >
                                <span>Duplex</span>
                            </div>
                        </li>
                                        </ul>
            </li>
            
    </ul>
            </div>
            <div class="flex-column componentes-v3">
                <label class="custom-select enviarPostHog" nombreEventoPostHog="Areas">
                    <iv-buscador-areas-webs
                            url="https://apiweb.inmovilla.com/apiweb/config/8569_185.57.173.244_1/areas.json"
                            minlength="3"
                            multiple
                            value=""
                            onchange="$('iv-buscador-areas-webs').val(this.value)"
                            placeholder="Enter the area you are looking for..."
                            placeholderbuscador="Enter the area you are looking for..."
                            textoerror="An error occurred"
                            textosinresultados="No results"
                            avisoresultadoslimitados="Showing more relevant results, enter a more detailed search"
                            idioma="2"
                    ></iv-buscador-areas-webs>
                </label>
            </div>
            <div class="bloque-input slider-buscador-precio enviarPostHog" nombreEventoPostHog="Price from">
                <input id="precioDesdeRapido" type="number" placeholder="Price from" class="fuerzaBusqueda inputBuscador inputBuscadorDesde" claseSincroniza="inputBuscadorDesde" value="">
            </div>
            <div class="bloque-input slider-buscador-precio enviarPostHog" nombreEventoPostHog="Price up to">
                <input id="precioHastaRapido" type="number" placeholder="Price to" class="fuerzaBusqueda inputBuscador inputBuscadorHasta" claseSincroniza="inputBuscadorHasta" value="">
            </div>
            <div class="bloque-input slider-buscador-ref enviarPostHog" nombreEventoPostHog="Reference">
                <input id="refRapido" type="text" placeholder="Ref" class="bg-color fuerzaBusqueda inputBuscador inputBuscadorRef" claseSincroniza="inputBuscadorRef" value="">
            </div>
            
                <div class="bloque-checkbox enviarPostHog" nombreEventoPostHog="See map">
                    <input type="checkbox" id="verMapaRapido"  class="buscadorVerMapa custom-checkbox">
                    <label for="verMapaRapido">See Map</label>
                </div>
            

            <div class="buttons">
                <button class="avanzado enviarPostHog" nombreEventoPostHog="Advanced">Advanced</button>
                <button class="buscarRapido enviarPostHog" nombreEventoPostHog="Search for" onclick="busquedaBuscadorRapido($(this))">Search</button>
            </div>
    </div>
</div><link rel='stylesheet' href='css/componentes/buscador-1.css?x=20260506150310' type='text/css'>

<section id="slider-bloque-estrella" seccionPostHog="Properties list">
    <div id="slider-estrella-felchas">
        <a href="#" class="flecha2-previous"></a>
        <a href="#" class="flecha2-next"></a>
    </div>
    <article class="imagenesComoBackground fotopropiedad propiedad fotosAlVuelo  enviarPostHog" nombreEventoPostHog="View property list" style="background-image: url(img/nofotos.png);" cargaFoto="https://fotos15.apinmo.com/8569/12341515/13-1s.jpg" indice="1" tipo="destacadosestrella" onclick="window.location.href='ficha/flat/orihuela/zona-centro/8569/12341515/en/'">
        <a href="#" class="flechaprev"></a>
        <a href="#" class="flechanext"></a>

        <div id="slider-estrella-tituloprecio">
            <h1 class="titulo1">Flat Orihuela</h1>
            <span class="precio1">87.999 €</span>
        </div>
        <div id="slider-estrella-masdatos">
            <ul>
                <li class="bloque-icono-name-valor1">
                    <div>
                        <i class="fa fa-tag fa-2x"></i>
                    </div>
                    <div>
                        <span class="ref">002520</span>
                    </div>
                </li>

                
                <li class="bloque-icono-name-valor1">
                    <div>
                        <i class="fa fa-bed fa-2x"></i>
                    </div>
                    <div>
                        <span class="habitaciones">2</span>
                    </div>
                </li>
                

                
                <li class="bloque-icono-name-valor1">
                    <div>
                        <i class="fa fa-shower fa-2x"></i>
                    </div>
                    <div>
                        <span class="banyos">1</span>
                    </div>
                </li>
                

                
                <li class="bloque-icono-name-valor1">
                    <div>
                        <i class="fa fa-superscript fa-2x"></i>
                    </div>
                    <div>
                        <span class="superficie">101 mts</span>
                    </div>
                </li>
                

            </ul>
        </div>
    </article>
</section>
<link rel='stylesheet' href='css/componentes/destacadoEstrella-2.css?x=20260506150310' type='text/css'>
    <div class="bloque-shadow"></div>
  
</section>
<section id="modulo-buscAvanzado-1" class="bloque-modulo flex-column buscadorAvanzado" style="display: none;">
  <header id="buscAvanzado-cabecera" class="bloque-100 flex-column">
    <div class="tituloCabecera">
      <h2>Advanced search</h2>
      <span class="ocultar">Hide</span>
    </div>
  </header>
  <section id="buscAvanzado-buscador" seccionPostHog="Search">
    <div class="bloque bloque1">
      <div class="flex bloqueCheckbox">
        <div>
          <input type="checkbox" id="chkventa" class="custom-checkbox" value="1" >
          <label for="chkventa" class="enviarPostHog" nombreEventoPostHog="For sale">For sale</label>
        </div>
        <div>
          <input type="checkbox" id="chkalquiler" class="custom-checkbox" value="1" >
          <label for="chkalquiler" class="enviarPostHog" nombreEventoPostHog="For rent">Rental</label>
        </div>
        <div>
          <input type="checkbox" id="opcioncompra" class="custom-checkbox" value="1" >
          <label for="opcioncompra" class="enviarPostHog" nombreEventoPostHog="Option To Buy">Option To Buy</label>
        </div>
        <div>
          <input type="checkbox" id="chkalquilervacacional" class="custom-checkbox" value="1" >
          <label for="chkalquilervacacional" class="enviarPostHog" nombreEventoPostHog="Short term rentals">Short term rentals</label>
        </div>
        <div>
          <input type="checkbox" id="chktraspaso" class="custom-checkbox" value="1" >
          <label for="chktraspaso" class="enviarPostHog" nombreEventoPostHog="To Assign">Transfer</label>
        </div>
      </div>
      <div class="bloqueBuscarAvanzado">
        <div>
          <input id="limref2" class="fuerzaBusquedaAvanzado inputBuscador inputBuscadorRef enviarPostHog" nombreEventoPostHog="Reference" claseSincroniza="inputBuscadorRef" type="text" placeholder="Reference"></input>
        </div>
        <div>
          <button class="buscarAvanzado enviarPostHog" nombreEventoPostHog="Search for" onclick="busquedaBuscadorAvanzado($(this));">Search</button>
        </div>
      </div>
    </div>
    <div class="bloqueSelects bloque">
        <div class="bloque-select">
          <div id="inmotipos" class="buscadorTipos custom-select-html enviarPostHog" nombreEventoPostHog="Property Type" original-txt="Property Type" data-txt="Property Type">
              <ul class="cajaGrupoTipos cajaGrupoTiposZonas">
        <li>
            <div class="grupoTipoZona">
                <input type="checkbox" class="marcarTodas">
                <span>All</span>
            </div>
        </li>
                    <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="6299,7599" >
                    <span><u> Rustic house</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="6299" >
                                <span>Village house</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="7599" >
                                <span>House with land</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="7499,199,299,399,21199,499,5499,6499" >
                    <span><u> House/Chalet</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="7499" >
                                <span>Bungalow Ground Floor</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="199" >
                                <span>Terraced house</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="299" >
                                <span>Bungalow</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="399" >
                                <span>House</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="21199" >
                                <span>Duplex House</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="499" >
                                <span>Single family house</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="5499" >
                                <span>Bungalow Top Floor</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="6499" >
                                <span>Luxury Villa</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="1699" >
                    <span><u> Building</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1699" >
                                <span>Building</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="2399,2599" >
                    <span><u> Garage </u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="2399" >
                                <span>Garage</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="2599" >
                                <span>Parking</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="1299" >
                    <span><u> Premises or Warehouse</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1299" >
                                <span>Business Premise</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="1199,1399" >
                    <span><u> Office</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1199" >
                                <span>Office</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="1399" >
                                <span>Office</span>
                            </div>
                        </li>
                                        </ul>
            </li>
                        <li>
                <div class="grupoTipoZona">
                    <input type="checkbox" class="marcarGrupoTiposZonas" value="3399,3499,2999" >
                    <span><u> Apartment</u></span>
                </div>
                <ul style="">
                                            <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="3399" >
                                <span>Flat</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="3499" >
                                <span>Ground floor apartment</span>
                            </div>
                        </li>
                                                <li>
                            <div class="grupoTipoZona">
                                <input type="checkbox" class="marcarTipoZona" value="2999" >
                                <span>Duplex</span>
                            </div>
                        </li>
                                        </ul>
            </li>
            
    </ul>
          </div>
        </div>
        <div class="bloque-select componentes-v3">
            <label class="custom-select enviarPostHog" nombreEventoPostHog="Areas">
                <iv-buscador-areas-webs
                        url="https://apiweb.inmovilla.com/apiweb/config/8569_185.57.173.244_1/areas.json"
                        minlength="3"
                        multiple
                        value=""
                        onchange="$('iv-buscador-areas-webs').val(this.value)"
                        placeholder="Enter the area you are looking for..."
                        placeholderbuscador="Enter the area you are looking for..."
                        textoerror="An error occurred"
                        textosinresultados="No results"
                        avisoresultadoslimitados="Showing more relevant results, enter a more detailed search"
                        idioma="2"
                ></iv-buscador-areas-webs>
            </label>
        </div>
        <div class="bloque-select">
          <label for="limhab" class="custom-select enviarPostHog" nombreEventoPostHog="Bedrooms">
            <select id="limhab">
              <option selected disabled>Bedrooms</option>
              <option value="1" >1</option>
              <option value="2" >2</option>
              <option value="3" >3</option>
              <option value="4" >+4</option>
            </select>
          </label>
        </div>
        <div class="bloque-select">
            <label for="limbanos" class="custom-select enviarPostHog" nombreEventoPostHog="Bathrooms">
                <select id="limbanos">
                    <option selected disabled>Bathrooms</option>
                    <option value="1" >1</option>
                    <option value="2" >2</option>
                    <option value="3" >3</option>
                    <option value="4" >+4</option>
                </select>
            </label>
        </div>
    </div>
      <div class="bloqueSelects bloque">
          <div class="bloque-input">
              <input id="metros" class="fuerzaBusquedaAvanzado enviarPostHog" nombreEventoPostHog="Surface" onkeypress="return solonumeros(event);" type="string" placeholder="Surface from" value=""> <b>m2</b>
          </div>
          <div class="bloque-input">
               <input id="metros2" class="fuerzaBusquedaAvanzado enviarPostHog" nombreEventoPostHog="Surface"  onkeypress="return solonumeros(event);" type="string" placeholder="Surface up to" value=""> <b>m2</b>
          </div>
          <div class="bloque-input">
              <input id="preciodesdeAvanzado" class="fuerzaBusquedaAvanzado inputBuscador inputBuscadorDesde enviarPostHog" nombreEventoPostHog="Price from" claseSincroniza="inputBuscadorDesde" type="number" placeholder="Price from" value=""> <b>€</b>
          </div>
          <div class="bloque-input">
              <input id="preciohastaAvanzado" class="fuerzaBusquedaAvanzado inputBuscador inputBuscadorHasta enviarPostHog" nombreEventoPostHog="Price up to" claseSincroniza="inputBuscadorHasta" type="number" placeholder="Price to" value=""> <b>€</b>
          </div>
      </div>
      <div class="bloque bloqueCheckbox">
      <div class=" enviarPostHog" nombreEventoPostHog="Pool">
        <input type="checkbox" id="piscina" class="custom-checkbox" value="1" >
        <label for="piscina">Pool</label>
      </div>
      <div class="enviarPostHog" nombreEventoPostHog="Parking">
        <input type="checkbox" id="parking" class="custom-checkbox" value="1" >
        <label for="parking">Parking</label>
      </div>
      <div class="enviarPostHog" nombreEventoPostHog="Lift">
        <input type="checkbox" id="ascensor" class="custom-checkbox" value="1" >
        <label for="ascensor">Lift</label>
      </div>
      <div class="enviarPostHog" nombreEventoPostHog="Terrace">
        <input type="checkbox" id="terraza" class="custom-checkbox" value="1" >
        <label for="terraza">Terrace</label>
      </div>
      <div class="enviarPostHog" nombreEventoPostHog="Furnished">
        <input type="checkbox" id="muebles" class="custom-checkbox" value="1" >
        <label for="muebles">Furnished</label>
      </div>
      <div class="enviarPostHog" nombreEventoPostHog="Urbanization">
        <input type="checkbox" id="urbanizacion" class="custom-checkbox" value="1" >
        <label for="urbanizacion">Urbanizacion</label>
      </div>
      <div class="enviarPostHog" nombreEventoPostHog="New Construction">
        <input type="checkbox" id="obranueva" class="custom-checkbox" value="1" >
        <label for="obranueva">New Build</label>
      </div>
      <div class="enviarPostHog" nombreEventoPostHog="View to sea">
        <input type="checkbox" id="vistasalmar" class="custom-checkbox" value="1" >
        <label for="vistasalmar">View to sea</label>
      </div>
    </div>
  </section>
</section><link rel='stylesheet' href='css/componentes/buscadoravanzado-1.css?x=20260506150310' type='text/css'><!-- destacados-1 / Propiedades destacadas -->
<section id="modulo-destacados-1-2" class="bloque-modulo modulos-destacados modulos-destacados-1">
  <div id="destacados-flechas">
    <a href="#" id="destacados-prev" class="destacados-flecha"></a>
    <a href="#" id="destacados-next" class="destacados-flecha"></a>
  </div>
  <div id="destacados-contenedor">
    <h1 id="titulo-destacados-1">Recommended</h1>
    <section id="destacados-carrusel" class="destacados-carrusel" seccionPostHog="Properties list">
      
        <article class="propiedad" indice="1" tipo="destacados">
          <div class="destacados-ficha-bloque1 imagenesComoBackground fotopropiedad  fotosAlVuelo enviarPostHog" nombreEventoPostHog="View property list"
               style="background-image: url(img/nofotos.png);" cargaFoto="https://fotos15.apinmo.com/8569/12341101/4-1s.jpg" onclick="window.location.href='ficha/bungalow-ground-floor/orihuela/molins-campaneta-san-bartolome/8569/12341101/en/'">
            <a href="#" class="flechaprev"></a>
            <a href="#" class="flechanext"></a>
            <span class="precio1">89.900 €</span>
          </div>
          <div class="destacados-ficha-bloque2">
            <div class="destacados-masdatos">
              <ul>
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="fa fa-info fa-2x"></i>
                    <span>Reference</span>
                  </div>
                  <div>
                    <span>002111</span>
                  </div>
                </li>

                
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="habitacion"></i>
                    <span>Bedrooms</span>
                  </div>
                  <div>
                    <span>2</span>
                  </div>
                </li>
                

                
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="bano"></i>
                    <span>Bathrooms</span>
                  </div>
                  <div>
                    <span>1</span>
                  </div>
                </li>
                

                
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="superficieico"></i>
                    <span>Surface</span>
                  </div>
                  <div>
                    <span>65 m2</span>
                  </div>
                </li>
                

              </ul>
            </div>
            <h1 class="destacados-titulo">Bungalow Ground Floor - Orihuela (Molins-Campaneta-San Bartolomé) </h1>
          </div>
        </article>
        
        <article class="propiedad" indice="2" tipo="destacados">
          <div class="destacados-ficha-bloque1 imagenesComoBackground fotopropiedad  fotosAlVuelo enviarPostHog" nombreEventoPostHog="View property list"
               style="background-image: url(img/nofotos.png);" cargaFoto="https://fotos15.apinmo.com/8569/12340691/9-1s.jpg" onclick="window.location.href='ficha/flat/redovan/ayuntamiento/8569/12340691/en/'">
            <a href="#" class="flechaprev"></a>
            <a href="#" class="flechanext"></a>
            <span class="precio1">94.999 €</span>
          </div>
          <div class="destacados-ficha-bloque2">
            <div class="destacados-masdatos">
              <ul>
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="fa fa-info fa-2x"></i>
                    <span>Reference</span>
                  </div>
                  <div>
                    <span>001251</span>
                  </div>
                </li>

                
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="habitacion"></i>
                    <span>Bedrooms</span>
                  </div>
                  <div>
                    <span>3</span>
                  </div>
                </li>
                

                
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="bano"></i>
                    <span>Bathrooms</span>
                  </div>
                  <div>
                    <span>1</span>
                  </div>
                </li>
                

                
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="superficieico"></i>
                    <span>Surface</span>
                  </div>
                  <div>
                    <span>94.99 m2</span>
                  </div>
                </li>
                

              </ul>
            </div>
            <h1 class="destacados-titulo">Flat - Redovan (Ayuntamiento) </h1>
          </div>
        </article>
        
        <article class="propiedad" indice="3" tipo="destacados">
          <div class="destacados-ficha-bloque1 imagenesComoBackground fotopropiedad  fotosAlVuelo enviarPostHog" nombreEventoPostHog="View property list"
               style="background-image: url(img/nofotos.png);" cargaFoto="https://fotos15.apinmo.com/8569/21208505/45-1s.jpg" onclick="window.location.href='ficha/bungalow/redovan/comunidad-valenciana/8569/21208505/en/'">
            <a href="#" class="flechaprev"></a>
            <a href="#" class="flechanext"></a>
            <span class="precio1">159.999 €</span>
          </div>
          <div class="destacados-ficha-bloque2">
            <div class="destacados-masdatos">
              <ul>
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="fa fa-info fa-2x"></i>
                    <span>Reference</span>
                  </div>
                  <div>
                    <span>5958659</span>
                  </div>
                </li>

                
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="habitacion"></i>
                    <span>Bedrooms</span>
                  </div>
                  <div>
                    <span>3</span>
                  </div>
                </li>
                

                
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="bano"></i>
                    <span>Bathrooms</span>
                  </div>
                  <div>
                    <span>3</span>
                  </div>
                </li>
                

                
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="superficieico"></i>
                    <span>Surface</span>
                  </div>
                  <div>
                    <span>130 m2</span>
                  </div>
                </li>
                

              </ul>
            </div>
            <h1 class="destacados-titulo">Bungalow - Redovan (Comunidad valenciana) </h1>
          </div>
        </article>
        
        <article class="propiedad" indice="4" tipo="destacados">
          <div class="destacados-ficha-bloque1 imagenesComoBackground fotopropiedad  fotosAlVuelo enviarPostHog" nombreEventoPostHog="View property list"
               style="background-image: url(img/nofotos.png);" cargaFoto="https://fotos15.apinmo.com/8569/28837866/71-1s.jpg" onclick="window.location.href='ficha/flat/orihuela/zona-centro/8569/28837866/en/'">
            <a href="#" class="flechaprev"></a>
            <a href="#" class="flechanext"></a>
            <span class="precio1">168.000 €</span>
          </div>
          <div class="destacados-ficha-bloque2">
            <div class="destacados-masdatos">
              <ul>
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="fa fa-info fa-2x"></i>
                    <span>Reference</span>
                  </div>
                  <div>
                    <span>001212125</span>
                  </div>
                </li>

                
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="habitacion"></i>
                    <span>Bedrooms</span>
                  </div>
                  <div>
                    <span>3</span>
                  </div>
                </li>
                

                
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="bano"></i>
                    <span>Bathrooms</span>
                  </div>
                  <div>
                    <span>2</span>
                  </div>
                </li>
                

                
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="superficieico"></i>
                    <span>Surface</span>
                  </div>
                  <div>
                    <span>214 m2</span>
                  </div>
                </li>
                

              </ul>
            </div>
            <h1 class="destacados-titulo">Flat - Orihuela (Zona Centro) </h1>
          </div>
        </article>
        
        <article class="propiedad" indice="5" tipo="destacados">
          <div class="destacados-ficha-bloque1 imagenesComoBackground fotopropiedad  fotosAlVuelo enviarPostHog" nombreEventoPostHog="View property list"
               style="background-image: url(img/nofotos.png);" cargaFoto="https://fotos15.apinmo.com/8569/15970004/11-1s.jpg" onclick="window.location.href='ficha/flat/orihuela/zona-centro/8569/15970004/en/'">
            <a href="#" class="flechaprev"></a>
            <a href="#" class="flechanext"></a>
            <span class="precio1">169.000 €</span>
          </div>
          <div class="destacados-ficha-bloque2">
            <div class="destacados-masdatos">
              <ul>
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="fa fa-info fa-2x"></i>
                    <span>Reference</span>
                  </div>
                  <div>
                    <span>13256988</span>
                  </div>
                </li>

                
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="habitacion"></i>
                    <span>Bedrooms</span>
                  </div>
                  <div>
                    <span>3</span>
                  </div>
                </li>
                

                
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="bano"></i>
                    <span>Bathrooms</span>
                  </div>
                  <div>
                    <span>2</span>
                  </div>
                </li>
                

                
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="superficieico"></i>
                    <span>Surface</span>
                  </div>
                  <div>
                    <span>104.99 m2</span>
                  </div>
                </li>
                

              </ul>
            </div>
            <h1 class="destacados-titulo">Flat - Orihuela (Zona Centro) </h1>
          </div>
        </article>
        
        <article class="propiedad" indice="6" tipo="destacados">
          <div class="destacados-ficha-bloque1 imagenesComoBackground fotopropiedad  fotosAlVuelo enviarPostHog" nombreEventoPostHog="View property list"
               style="background-image: url(img/nofotos.png);" cargaFoto="https://fotos15.apinmo.com/8569/23534390/46-1s.jpg" onclick="window.location.href='ficha/house-type-duplex/orihuela/los-andenes/8569/23534390/en/'">
            <a href="#" class="flechaprev"></a>
            <a href="#" class="flechanext"></a>
            <span class="precio1">259.900 €</span>
          </div>
          <div class="destacados-ficha-bloque2">
            <div class="destacados-masdatos">
              <ul>
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="fa fa-info fa-2x"></i>
                    <span>Reference</span>
                  </div>
                  <div>
                    <span>5265326352</span>
                  </div>
                </li>

                
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="habitacion"></i>
                    <span>Bedrooms</span>
                  </div>
                  <div>
                    <span>4</span>
                  </div>
                </li>
                

                
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="bano"></i>
                    <span>Bathrooms</span>
                  </div>
                  <div>
                    <span>3</span>
                  </div>
                </li>
                

                
                <li class="bloque-icono-name-valor1">
                  <div>
                    <i class="superficieico"></i>
                    <span>Surface</span>
                  </div>
                  <div>
                    <span>180 m2</span>
                  </div>
                </li>
                

              </ul>
            </div>
            <h1 class="destacados-titulo">House Type Duplex - Orihuela (Los Andenes) </h1>
          </div>
        </article>
        
    </section>
  </div>

  <div id="destacados-paginacion">

  </div>

</section>
<!-- paginacion-1 / Propiedades y resultados --><!-- paginacion-1 / Propiedades y resultados -->
<link rel='stylesheet' href='css/componentes/paginacion-1.css' type='text/css'>
<section id="modulo-paginacion" class="bloque-modulo modulo-paginacion modulo-paginacion-1" seccionPostHog="Properties list">
  
    <header id="paginacion-cabecera" class="bloque-100">
        <div id="paginacion-titulo">
            <h1>Properties</h1>
            <div id="paginacion-titulo-sections" class="flex flex-align-end flex-justify-between gap-20">
                <span>Pag 1/6 - Total 67 Properties</span>
                
                    <menu>
                        
                            <li seccionPostHog="Properties alert">
                                <a class=" enviarPostHog" nombreEventoPostHog="View alerts" href="./alertas/">Alerts</a>
                            </li>
                        
                            <li>
                                <a href="./publica-tu-inmueble/">List your property</a>
                            </li>
                        
                    </menu>
                
            </div>
        </div>
    </header>

  <section
    id="paginacion-botonesFiltros"
    lang-data="Filter by:"
  >
      <div>
          <span id="titulo-filtrar-1">Filter by:</span>
          <div class="paginacion-ordenar">
              <label for="paginacion-ordenarprops" class="custom-select">
                  <select id="paginacion-ordenarprops">
                      <option selected="" disabled="">Arrange</option>

                      <option value="1" >Highest selling price</option>
                      <option value="2" >Lowest selling price</option>
                      <option value="3" >Highest rental price</option>
                      <option value="4" >Lowest rental price</option>
                      <option value="5" >Most Recent</option>
                      <option value="6" >Oldest</option>
                  </select>
              </label>
          </div>
      </div>
      <a href="index.php?vistas=1#modulo-paginacion" class="vistas"
         lang-data="Views"
          >
          <div>
              <i class="fas fa-eye"></i>
              <span>Views</span>
          </div>
      </a>
      <a href="index.php?descartadas=1#modulo-paginacion" class="descartadas"
         lang-data="Discarded"
          >
          <div>
              <i class="fas fa-minus-circle"></i>
              Discarded
          </div>
      </a>
      <a href="index.php?favoritas=1#modulo-paginacion" class="favoritas"
         lang-data="Favorites"
          >
          <div>
              <i class="fas fa-star"></i>
              Favorites
          </div>
      </a>
  </section>

  <section id="paginacion-contenido">
    <article class="paginacion-ficha propiedad" indice="1" tipo="paginacion">
  
  
  
    <div class="paginacion-ficha-bloque1 imagenesComoBackground fotopropiedad  fotosAlVuelo"
         style="background-image: url(img/nofotos.png);" cargaFoto="https://fotos15.apinmo.com/8569/12341498/2-1s.jpg">
        <span class="paginacion-ficha-tituloprecio">For sale 12.000 €</span> 
        
            <a href="#" class="flechaprev"></a>
            <a href="#" class="flechanext"></a>
        

        

        <a href="ficha/garage/orihuela/zona-centro/8569/12341498/en/" class="irAfichaPropiedad enviarPostHog" nombreEventoPostHog="View property list">&nbsp;</a>

        
            <div class="paginacion-contacto">

                <div class="paginacion-contacto-foto fotosAlVuelo" style="background-image: url(img/nofotoagente.jpg);" cargaFoto="img/nofotoagente.jpg"></div>

                <div class="paginacion-contacto-datos">
                    <div class="paginacion-contacto-cuadrodatos">
                        <div class="paginacion-contacto-datosnombre"><i class="fa fa-user" style="font-size: 15px;margin-right: 5px;"></i>GESSICON </div>
                        <div class="paginacion-contacto-telefono"><i class="fa fa-phone" style="font-size: 15px;margin-right: 5px;"></i>+34 669 871 698</div>
                    </div>
                </div>
            </div>
        
    </div>

    <div class="paginacion-ficha-bloque2">
         <div class="paginacion-ficha-masdatos">
            <ul>
                <li class="bloque-icono-name-valor1">
                    <div>
                        <i class="fa fa-info fa-2x"></i>
                        <span>Reference</span>
                    </div>
                    <div>
                        <span>002507</span>
                    </div>
                </li>
                

                
                    <li class="bloque-icono-name-valor1">
                        <div>
                            <i class="superficieico"></i>
                            <span>Surface</span>
                        </div>
                        <div>
                            <span>16 m2</span>
                        </div>
                    </li>
                

            </ul>
        </div>
        
        <div class="paginacion-ficha-datos">
            <h1 class="titulo">Garage - Orihuela (Zona Centro) , Built Surface 16m<sup>2</sup>, Lift.</h1>
            <div class="paginacion-ficha-pie">
                <hr>
                <a href="ficha/garage/orihuela/zona-centro/8569/12341498/en/" class="paginacion-ficha-masinfo enviarPostHog" nombreEventoPostHog="View property list">+ INFO</a>
                
            </div>
        </div>
    </div>
</article><article class="paginacion-ficha propiedad" indice="2" tipo="paginacion">
  
  
  
    <div class="paginacion-ficha-bloque1 imagenesComoBackground fotopropiedad  fotosAlVuelo"
         style="background-image: url(img/nofotos.png);" cargaFoto="https://fotos15.apinmo.com/8569/21848847/4-1s.jpg">
        <span class="paginacion-ficha-tituloprecio">For sale 16.500 €</span> 
        
            <a href="#" class="flechaprev"></a>
            <a href="#" class="flechanext"></a>
        

        

        <a href="ficha/parking/orihuela/zona-centro/8569/21848847/en/" class="irAfichaPropiedad enviarPostHog" nombreEventoPostHog="View property list">&nbsp;</a>

        
            <div class="paginacion-contacto">

                <div class="paginacion-contacto-foto fotosAlVuelo" style="background-image: url(img/nofotoagente.jpg);" cargaFoto="img/nofotoagente.jpg"></div>

                <div class="paginacion-contacto-datos">
                    <div class="paginacion-contacto-cuadrodatos">
                        <div class="paginacion-contacto-datosnombre"><i class="fa fa-user" style="font-size: 15px;margin-right: 5px;"></i>oficina </div>
                        <div class="paginacion-contacto-telefono"><i class="fa fa-phone" style="font-size: 15px;margin-right: 5px;"></i>+34 669 871 698</div>
                    </div>
                </div>
            </div>
        
    </div>

    <div class="paginacion-ficha-bloque2">
         <div class="paginacion-ficha-masdatos">
            <ul>
                <li class="bloque-icono-name-valor1">
                    <div>
                        <i class="fa fa-info fa-2x"></i>
                        <span>Reference</span>
                    </div>
                    <div>
                        <span>85696595</span>
                    </div>
                </li>
                
                        <li class="bloque-icono-name-valor1">
                            <div>
                                <i class="habitacion"></i>
                                <span>Bedrooms</span>
                            </div>
                            <div>
                                <span>3</span>
                            </div>
                        </li>
                     
                         <li class="bloque-icono-name-valor1">
                             <div>
                                 <i class="bano"></i>
                                 <span>Bathrooms</span>
                             </div>
                             <div>
                                 <span>2</span>
                             </div>
                         </li>
                  

                
                    <li class="bloque-icono-name-valor1">
                        <div>
                            <i class="superficieico"></i>
                            <span>Surface</span>
                        </div>
                        <div>
                            <span>328 m2</span>
                        </div>
                    </li>
                

            </ul>
        </div>
        
        <div class="paginacion-ficha-datos">
            <h1 class="titulo">Parking - Orihuela (Zona Centro) , Built Surface 328m<sup>2</sup>, 3 Bedrooms, 2 Bathrooms, Lift.</h1>
            <div class="paginacion-ficha-pie">
                <hr>
                <a href="ficha/parking/orihuela/zona-centro/8569/21848847/en/" class="paginacion-ficha-masinfo enviarPostHog" nombreEventoPostHog="View property list">+ INFO</a>
                
            </div>
        </div>
    </div>
</article><article class="paginacion-ficha propiedad" indice="3" tipo="paginacion">
  
  
  
    <div class="paginacion-ficha-bloque1 imagenesComoBackground fotopropiedad  fotosAlVuelo"
         style="background-image: url(img/nofotos.png);" cargaFoto="https://fotos15.apinmo.com/8569/27575322/3-1s.jpg">
        <span class="paginacion-ficha-tituloprecio">For sale 18.500 €</span> 
        
            <a href="#" class="flechaprev"></a>
            <a href="#" class="flechanext"></a>
        

        

        <a href="ficha/garage/orihuela/barrio-de-la-ocarasa/8569/27575322/en/" class="irAfichaPropiedad enviarPostHog" nombreEventoPostHog="View property list">&nbsp;</a>

        
            <div class="paginacion-contacto">

                <div class="paginacion-contacto-foto fotosAlVuelo" style="background-image: url(img/nofotoagente.jpg);" cargaFoto="img/nofotoagente.jpg"></div>

                <div class="paginacion-contacto-datos">
                    <div class="paginacion-contacto-cuadrodatos">
                        <div class="paginacion-contacto-datosnombre"><i class="fa fa-user" style="font-size: 15px;margin-right: 5px;"></i>GESSICON </div>
                        <div class="paginacion-contacto-telefono"><i class="fa fa-phone" style="font-size: 15px;margin-right: 5px;"></i>+34 669 871 698</div>
                    </div>
                </div>
            </div>
        
    </div>

    <div class="paginacion-ficha-bloque2">
         <div class="paginacion-ficha-masdatos">
            <ul>
                <li class="bloque-icono-name-valor1">
                    <div>
                        <i class="fa fa-info fa-2x"></i>
                        <span>Reference</span>
                    </div>
                    <div>
                        <span>00202602</span>
                    </div>
                </li>
                

                
                    <li class="bloque-icono-name-valor1">
                        <div>
                            <i class="superficieico"></i>
                            <span>Surface</span>
                        </div>
                        <div>
                            <span>20 m2</span>
                        </div>
                    </li>
                

            </ul>
        </div>
        
        <div class="paginacion-ficha-datos">
            <h1 class="titulo">Garage - Orihuela (Barrio de la Ocarasa) , Built Surface 20m<sup>2</sup>.</h1>
            <div class="paginacion-ficha-pie">
                <hr>
                <a href="ficha/garage/orihuela/barrio-de-la-ocarasa/8569/27575322/en/" class="paginacion-ficha-masinfo enviarPostHog" nombreEventoPostHog="View property list">+ INFO</a>
                
                    <div class="paginacion-ficha-preciorebajado">
                        <span class="paginacion-ficha-preciorebajadoTriangulo"></span>
                        <span class="paginacion-ficha-precioanterior">18.900 €</span> <span
                            class="paginacion-ficha-precioporcentaje">- 2&#37;</span>
                    </div>
                    
            </div>
        </div>
    </div>
</article><article class="paginacion-ficha propiedad" indice="4" tipo="paginacion">
  
  
  
    <div class="paginacion-ficha-bloque1 imagenesComoBackground fotopropiedad  fotosAlVuelo"
         style="background-image: url(img/nofotos.png);" cargaFoto="https://fotos15.apinmo.com/8569/27609111/7-1s.jpg">
        <span class="paginacion-ficha-tituloprecio">35.000 € - 714 €/month</span> 
        
            <a href="#" class="flechaprev"></a>
            <a href="#" class="flechanext"></a>
        

        

        <a href="ficha/business-premise/orihuela/zona-centro/8569/27609111/en/" class="irAfichaPropiedad enviarPostHog" nombreEventoPostHog="View property list">&nbsp;</a>

        
            <div class="paginacion-contacto">

                <div class="paginacion-contacto-foto fotosAlVuelo" style="background-image: url(img/nofotoagente.jpg);" cargaFoto="img/nofotoagente.jpg"></div>

                <div class="paginacion-contacto-datos">
                    <div class="paginacion-contacto-cuadrodatos">
                        <div class="paginacion-contacto-datosnombre"><i class="fa fa-user" style="font-size: 15px;margin-right: 5px;"></i>GESSICON </div>
                        <div class="paginacion-contacto-telefono"><i class="fa fa-phone" style="font-size: 15px;margin-right: 5px;"></i>+34 669 871 698</div>
                    </div>
                </div>
            </div>
        
    </div>

    <div class="paginacion-ficha-bloque2">
         <div class="paginacion-ficha-masdatos">
            <ul>
                <li class="bloque-icono-name-valor1">
                    <div>
                        <i class="fa fa-info fa-2x"></i>
                        <span>Reference</span>
                    </div>
                    <div>
                        <span>003528</span>
                    </div>
                </li>
                
                         <li class="bloque-icono-name-valor1">
                             <div>
                                 <i class="bano"></i>
                                 <span>Bathrooms</span>
                             </div>
                             <div>
                                 <span>2</span>
                             </div>
                         </li>
                  

                
                    <li class="bloque-icono-name-valor1">
                        <div>
                            <i class="superficieico"></i>
                            <span>Surface</span>
                        </div>
                        <div>
                            <span>140 m2</span>
                        </div>
                    </li>
                

            </ul>
        </div>
        
        <div class="paginacion-ficha-datos">
            <h1 class="titulo">Business Premise - Orihuela (Zona Centro) , Built Surface 140m<sup>2</sup>, 2 Toilets.</h1>
            <div class="paginacion-ficha-pie">
                <hr>
                <a href="ficha/business-premise/orihuela/zona-centro/8569/27609111/en/" class="paginacion-ficha-masinfo enviarPostHog" nombreEventoPostHog="View property list">+ INFO</a>
                
                    <div class="paginacion-ficha-preciorebajado">
                        <span class="paginacion-ficha-preciorebajadoTriangulo"></span>
                        <span class="paginacion-ficha-precioanterior">44.000 €</span> <span
                            class="paginacion-ficha-precioporcentaje">- 20&#37;</span>
                    </div>
                    
            </div>
        </div>
    </div>
</article><article class="paginacion-ficha propiedad" indice="5" tipo="paginacion">
  
  
  
    <div class="paginacion-ficha-bloque1 imagenesComoBackground fotopropiedad  fotosAlVuelo"
         style="background-image: url(img/nofotos.png);" cargaFoto="https://fotos15.apinmo.com/8569/12340765/14-1s.jpg">
        <span class="paginacion-ficha-tituloprecio">For sale 76.999 €</span> 
        
            <a href="#" class="flechaprev"></a>
            <a href="#" class="flechanext"></a>
        

        

        <a href="ficha/village-house/jacarilla/jacarilla/8569/12340765/en/" class="irAfichaPropiedad enviarPostHog" nombreEventoPostHog="View property list">&nbsp;</a>

        
            <div class="paginacion-contacto">

                <div class="paginacion-contacto-foto fotosAlVuelo" style="background-image: url(img/nofotoagente.jpg);" cargaFoto="img/nofotoagente.jpg"></div>

                <div class="paginacion-contacto-datos">
                    <div class="paginacion-contacto-cuadrodatos">
                        <div class="paginacion-contacto-datosnombre"><i class="fa fa-user" style="font-size: 15px;margin-right: 5px;"></i>JESSICA JESSICA</div>
                        <div class="paginacion-contacto-telefono"><i class="fa fa-phone" style="font-size: 15px;margin-right: 5px;"></i></div>
                    </div>
                </div>
            </div>
        
    </div>

    <div class="paginacion-ficha-bloque2">
         <div class="paginacion-ficha-masdatos">
            <ul>
                <li class="bloque-icono-name-valor1">
                    <div>
                        <i class="fa fa-info fa-2x"></i>
                        <span>Reference</span>
                    </div>
                    <div>
                        <span>001417</span>
                    </div>
                </li>
                
                        <li class="bloque-icono-name-valor1">
                            <div>
                                <i class="habitacion"></i>
                                <span>Bedrooms</span>
                            </div>
                            <div>
                                <span>3</span>
                            </div>
                        </li>
                     
                         <li class="bloque-icono-name-valor1">
                             <div>
                                 <i class="bano"></i>
                                 <span>Bathrooms</span>
                             </div>
                             <div>
                                 <span>2</span>
                             </div>
                         </li>
                  

                
                    <li class="bloque-icono-name-valor1">
                        <div>
                            <i class="superficieico"></i>
                            <span>Surface</span>
                        </div>
                        <div>
                            <span>210 m2</span>
                        </div>
                    </li>
                

            </ul>
        </div>
        
        <div class="paginacion-ficha-datos">
            <h1 class="titulo">Village house - Jacarilla , Built Surface 210m<sup>2</sup>, 3 Bedrooms, 1 Bathrooms.</h1>
            <div class="paginacion-ficha-pie">
                <hr>
                <a href="ficha/village-house/jacarilla/jacarilla/8569/12340765/en/" class="paginacion-ficha-masinfo enviarPostHog" nombreEventoPostHog="View property list">+ INFO</a>
                
                    <div class="paginacion-ficha-preciorebajado">
                        <span class="paginacion-ficha-preciorebajadoTriangulo"></span>
                        <span class="paginacion-ficha-precioanterior">80.000 €</span> <span
                            class="paginacion-ficha-precioporcentaje">- 4&#37;</span>
                    </div>
                    
            </div>
        </div>
    </div>
</article><article class="paginacion-ficha propiedad" indice="6" tipo="paginacion">
  
  
  
    <div class="paginacion-ficha-bloque1 imagenesComoBackground fotopropiedad  fotosAlVuelo"
         style="background-image: url(img/nofotos.png);" cargaFoto="https://fotos15.apinmo.com/8569/26770541/11-1s.jpg">
        <span class="paginacion-ficha-tituloprecio">For sale 77.999 €</span> 
        
            <a href="#" class="flechaprev"></a>
            <a href="#" class="flechanext"></a>
        

        

        <a href="ficha/house/orihuela/hurchillo/8569/26770541/en/" class="irAfichaPropiedad enviarPostHog" nombreEventoPostHog="View property list">&nbsp;</a>

        
            <div class="paginacion-contacto">

                <div class="paginacion-contacto-foto fotosAlVuelo" style="background-image: url(img/nofotoagente.jpg);" cargaFoto="img/nofotoagente.jpg"></div>

                <div class="paginacion-contacto-datos">
                    <div class="paginacion-contacto-cuadrodatos">
                        <div class="paginacion-contacto-datosnombre"><i class="fa fa-user" style="font-size: 15px;margin-right: 5px;"></i>oficina </div>
                        <div class="paginacion-contacto-telefono"><i class="fa fa-phone" style="font-size: 15px;margin-right: 5px;"></i>+34 669 871 698</div>
                    </div>
                </div>
            </div>
        
    </div>

    <div class="paginacion-ficha-bloque2">
         <div class="paginacion-ficha-masdatos">
            <ul>
                <li class="bloque-icono-name-valor1">
                    <div>
                        <i class="fa fa-info fa-2x"></i>
                        <span>Reference</span>
                    </div>
                    <div>
                        <span>009999765</span>
                    </div>
                </li>
                
                        <li class="bloque-icono-name-valor1">
                            <div>
                                <i class="habitacion"></i>
                                <span>Bedrooms</span>
                            </div>
                            <div>
                                <span>3</span>
                            </div>
                        </li>
                     
                         <li class="bloque-icono-name-valor1">
                             <div>
                                 <i class="bano"></i>
                                 <span>Bathrooms</span>
                             </div>
                             <div>
                                 <span>3</span>
                             </div>
                         </li>
                  

                
                    <li class="bloque-icono-name-valor1">
                        <div>
                            <i class="superficieico"></i>
                            <span>Surface</span>
                        </div>
                        <div>
                            <span>283 m2</span>
                        </div>
                    </li>
                

            </ul>
        </div>
        
        <div class="paginacion-ficha-datos">
            <h1 class="titulo">House - Orihuela (Hurchillo) , Built Surface 283m<sup>2</sup>, 3 Bedrooms, 2 Bathrooms.</h1>
            <div class="paginacion-ficha-pie">
                <hr>
                <a href="ficha/house/orihuela/hurchillo/8569/26770541/en/" class="paginacion-ficha-masinfo enviarPostHog" nombreEventoPostHog="View property list">+ INFO</a>
                
                    <div class="paginacion-ficha-preciorebajado">
                        <span class="paginacion-ficha-preciorebajadoTriangulo"></span>
                        <span class="paginacion-ficha-precioanterior">85.000 €</span> <span
                            class="paginacion-ficha-precioporcentaje">- 8&#37;</span>
                    </div>
                    
            </div>
        </div>
    </div>
</article><article class="paginacion-ficha propiedad" indice="7" tipo="paginacion">
  
  
  
    <div class="paginacion-ficha-bloque1 imagenesComoBackground fotopropiedad  fotosAlVuelo"
         style="background-image: url(img/nofotos.png);" cargaFoto="https://fotos15.apinmo.com/8569/12341515/13-1s.jpg">
        <span class="paginacion-ficha-tituloprecio">For sale 87.999 €</span> 
        
            <a href="#" class="flechaprev"></a>
            <a href="#" class="flechanext"></a>
        

        

        <a href="ficha/flat/orihuela/zona-centro/8569/12341515/en/" class="irAfichaPropiedad enviarPostHog" nombreEventoPostHog="View property list">&nbsp;</a>

        
            <div class="paginacion-contacto">

                <div class="paginacion-contacto-foto fotosAlVuelo" style="background-image: url(img/nofotoagente.jpg);" cargaFoto="img/nofotoagente.jpg"></div>

                <div class="paginacion-contacto-datos">
                    <div class="paginacion-contacto-cuadrodatos">
                        <div class="paginacion-contacto-datosnombre"><i class="fa fa-user" style="font-size: 15px;margin-right: 5px;"></i>GESSICON </div>
                        <div class="paginacion-contacto-telefono"><i class="fa fa-phone" style="font-size: 15px;margin-right: 5px;"></i>+34 669 871 698</div>
                    </div>
                </div>
            </div>
        
    </div>

    <div class="paginacion-ficha-bloque2">
         <div class="paginacion-ficha-masdatos">
            <ul>
                <li class="bloque-icono-name-valor1">
                    <div>
                        <i class="fa fa-info fa-2x"></i>
                        <span>Reference</span>
                    </div>
                    <div>
                        <span>002520</span>
                    </div>
                </li>
                
                        <li class="bloque-icono-name-valor1">
                            <div>
                                <i class="habitacion"></i>
                                <span>Bedrooms</span>
                            </div>
                            <div>
                                <span>2</span>
                            </div>
                        </li>
                     
                         <li class="bloque-icono-name-valor1">
                             <div>
                                 <i class="bano"></i>
                                 <span>Bathrooms</span>
                             </div>
                             <div>
                                 <span>1</span>
                             </div>
                         </li>
                  

                
                    <li class="bloque-icono-name-valor1">
                        <div>
                            <i class="superficieico"></i>
                            <span>Surface</span>
                        </div>
                        <div>
                            <span>101 m2</span>
                        </div>
                    </li>
                

            </ul>
        </div>
        
        <div class="paginacion-ficha-datos">
            <h1 class="titulo">Flat - Orihuela (Zona Centro) , Built Surface 101m<sup>2</sup>, 2 Bedrooms, 1 Bathrooms.</h1>
            <div class="paginacion-ficha-pie">
                <hr>
                <a href="ficha/flat/orihuela/zona-centro/8569/12341515/en/" class="paginacion-ficha-masinfo enviarPostHog" nombreEventoPostHog="View property list">+ INFO</a>
                
                    <div class="paginacion-ficha-preciorebajado">
                        <span class="paginacion-ficha-preciorebajadoTriangulo"></span>
                        <span class="paginacion-ficha-precioanterior">89.900 €</span> <span
                            class="paginacion-ficha-precioporcentaje">- 2&#37;</span>
                    </div>
                    
            </div>
        </div>
    </div>
</article><article class="paginacion-ficha propiedad" indice="8" tipo="paginacion">
  
  
  
    <div class="paginacion-ficha-bloque1 imagenesComoBackground fotopropiedad  fotosAlVuelo"
         style="background-image: url(img/nofotos.png);" cargaFoto="https://fotos15.apinmo.com/8569/27761236/11-1s.jpg">
        <span class="paginacion-ficha-tituloprecio">For sale 87.999 €</span> 
        
            <a href="#" class="flechaprev"></a>
            <a href="#" class="flechanext"></a>
        

        

        <a href="ficha/ground-floor-apartment/orihuela/la-murada-los-vicentes/8569/27761236/en/" class="irAfichaPropiedad enviarPostHog" nombreEventoPostHog="View property list">&nbsp;</a>

        
            <div class="paginacion-contacto">

                <div class="paginacion-contacto-foto fotosAlVuelo" style="background-image: url(img/nofotoagente.jpg);" cargaFoto="img/nofotoagente.jpg"></div>

                <div class="paginacion-contacto-datos">
                    <div class="paginacion-contacto-cuadrodatos">
                        <div class="paginacion-contacto-datosnombre"><i class="fa fa-user" style="font-size: 15px;margin-right: 5px;"></i>oficina </div>
                        <div class="paginacion-contacto-telefono"><i class="fa fa-phone" style="font-size: 15px;margin-right: 5px;"></i>+34 669 871 698</div>
                    </div>
                </div>
            </div>
        
    </div>

    <div class="paginacion-ficha-bloque2">
         <div class="paginacion-ficha-masdatos">
            <ul>
                <li class="bloque-icono-name-valor1">
                    <div>
                        <i class="fa fa-info fa-2x"></i>
                        <span>Reference</span>
                    </div>
                    <div>
                        <span>850000002</span>
                    </div>
                </li>
                
                        <li class="bloque-icono-name-valor1">
                            <div>
                                <i class="habitacion"></i>
                                <span>Bedrooms</span>
                            </div>
                            <div>
                                <span>3</span>
                            </div>
                        </li>
                     
                         <li class="bloque-icono-name-valor1">
                             <div>
                                 <i class="bano"></i>
                                 <span>Bathrooms</span>
                             </div>
                             <div>
                                 <span>2</span>
                             </div>
                         </li>
                  

                
                    <li class="bloque-icono-name-valor1">
                        <div>
                            <i class="superficieico"></i>
                            <span>Surface</span>
                        </div>
                        <div>
                            <span>85 m2</span>
                        </div>
                    </li>
                

            </ul>
        </div>
        
        <div class="paginacion-ficha-datos">
            <h1 class="titulo">Ground floor apartment - Orihuela (La Murada-Los Vicentes) , Built Surface 85m<sup>2</sup>, 3 Bedrooms, 2 Bathrooms.</h1>
            <div class="paginacion-ficha-pie">
                <hr>
                <a href="ficha/ground-floor-apartment/orihuela/la-murada-los-vicentes/8569/27761236/en/" class="paginacion-ficha-masinfo enviarPostHog" nombreEventoPostHog="View property list">+ INFO</a>
                
                    <div class="paginacion-ficha-preciorebajado">
                        <span class="paginacion-ficha-preciorebajadoTriangulo"></span>
                        <span class="paginacion-ficha-precioanterior">99.000 €</span> <span
                            class="paginacion-ficha-precioporcentaje">- 11&#37;</span>
                    </div>
                    
            </div>
        </div>
    </div>
</article><article class="paginacion-ficha propiedad" indice="9" tipo="paginacion">
  
  
  
    <div class="paginacion-ficha-bloque1 imagenesComoBackground fotopropiedad  fotosAlVuelo"
         style="background-image: url(img/nofotos.png);" cargaFoto="https://fotos15.apinmo.com/8569/12341101/4-1s.jpg">
        <span class="paginacion-ficha-tituloprecio">For sale 89.900 €</span> 
        
            <a href="#" class="flechaprev"></a>
            <a href="#" class="flechanext"></a>
        

        

        <a href="ficha/bungalow-ground-floor/orihuela/molins-campaneta-san-bartolome/8569/12341101/en/" class="irAfichaPropiedad enviarPostHog" nombreEventoPostHog="View property list">&nbsp;</a>

        
            <div class="paginacion-contacto">

                <div class="paginacion-contacto-foto fotosAlVuelo" style="background-image: url(img/nofotoagente.jpg);" cargaFoto="img/nofotoagente.jpg"></div>

                <div class="paginacion-contacto-datos">
                    <div class="paginacion-contacto-cuadrodatos">
                        <div class="paginacion-contacto-datosnombre"><i class="fa fa-user" style="font-size: 15px;margin-right: 5px;"></i>GESSICON </div>
                        <div class="paginacion-contacto-telefono"><i class="fa fa-phone" style="font-size: 15px;margin-right: 5px;"></i>+34 669 871 698</div>
                    </div>
                </div>
            </div>
        
    </div>

    <div class="paginacion-ficha-bloque2">
         <div class="paginacion-ficha-masdatos">
            <ul>
                <li class="bloque-icono-name-valor1">
                    <div>
                        <i class="fa fa-info fa-2x"></i>
                        <span>Reference</span>
                    </div>
                    <div>
                        <span>002111</span>
                    </div>
                </li>
                
                        <li class="bloque-icono-name-valor1">
                            <div>
                                <i class="habitacion"></i>
                                <span>Bedrooms</span>
                            </div>
                            <div>
                                <span>2</span>
                            </div>
                        </li>
                     
                         <li class="bloque-icono-name-valor1">
                             <div>
                                 <i class="bano"></i>
                                 <span>Bathrooms</span>
                             </div>
                             <div>
                                 <span>1</span>
                             </div>
                         </li>
                  

                
                    <li class="bloque-icono-name-valor1">
                        <div>
                            <i class="superficieico"></i>
                            <span>Surface</span>
                        </div>
                        <div>
                            <span>65 m2</span>
                        </div>
                    </li>
                

            </ul>
        </div>
        
        <div class="paginacion-ficha-datos">
            <h1 class="titulo">Bungalow Ground Floor - Orihuela (Molins-Campaneta-San Bartolomé) , Built Surface 65m<sup>2</sup>, 2 Bedrooms, 1 Bathrooms,...</h1>
            <div class="paginacion-ficha-pie">
                <hr>
                <a href="ficha/bungalow-ground-floor/orihuela/molins-campaneta-san-bartolome/8569/12341101/en/" class="paginacion-ficha-masinfo enviarPostHog" nombreEventoPostHog="View property list">+ INFO</a>
                
                    <div class="paginacion-ficha-preciorebajado">
                        <span class="paginacion-ficha-preciorebajadoTriangulo"></span>
                        <span class="paginacion-ficha-precioanterior">95.000 €</span> <span
                            class="paginacion-ficha-precioporcentaje">- 5&#37;</span>
                    </div>
                    
            </div>
        </div>
    </div>
</article><article class="paginacion-ficha propiedad" indice="10" tipo="paginacion">
  
  
  
    <div class="paginacion-ficha-bloque1 imagenesComoBackground fotopropiedad  fotosAlVuelo"
         style="background-image: url(img/nofotos.png);" cargaFoto="https://fotos15.apinmo.com/8569/12340691/9-1s.jpg">
        <span class="paginacion-ficha-tituloprecio">For sale 94.999 €</span> 
        
            <a href="#" class="flechaprev"></a>
            <a href="#" class="flechanext"></a>
        

        

        <a href="ficha/flat/redovan/ayuntamiento/8569/12340691/en/" class="irAfichaPropiedad enviarPostHog" nombreEventoPostHog="View property list">&nbsp;</a>

        
            <div class="paginacion-contacto">

                <div class="paginacion-contacto-foto fotosAlVuelo" style="background-image: url(img/nofotoagente.jpg);" cargaFoto="img/nofotoagente.jpg"></div>

                <div class="paginacion-contacto-datos">
                    <div class="paginacion-contacto-cuadrodatos">
                        <div class="paginacion-contacto-datosnombre"><i class="fa fa-user" style="font-size: 15px;margin-right: 5px;"></i>mary </div>
                        <div class="paginacion-contacto-telefono"><i class="fa fa-phone" style="font-size: 15px;margin-right: 5px;"></i></div>
                    </div>
                </div>
            </div>
        
    </div>

    <div class="paginacion-ficha-bloque2">
         <div class="paginacion-ficha-masdatos">
            <ul>
                <li class="bloque-icono-name-valor1">
                    <div>
                        <i class="fa fa-info fa-2x"></i>
                        <span>Reference</span>
                    </div>
                    <div>
                        <span>001251</span>
                    </div>
                </li>
                
                        <li class="bloque-icono-name-valor1">
                            <div>
                                <i class="habitacion"></i>
                                <span>Bedrooms</span>
                            </div>
                            <div>
                                <span>3</span>
                            </div>
                        </li>
                     
                         <li class="bloque-icono-name-valor1">
                             <div>
                                 <i class="bano"></i>
                                 <span>Bathrooms</span>
                             </div>
                             <div>
                                 <span>1</span>
                             </div>
                         </li>
                  

                
                    <li class="bloque-icono-name-valor1">
                        <div>
                            <i class="superficieico"></i>
                            <span>Surface</span>
                        </div>
                        <div>
                            <span>94.99 m2</span>
                        </div>
                    </li>
                

            </ul>
        </div>
        
        <div class="paginacion-ficha-datos">
            <h1 class="titulo">Flat - Redovan (Ayuntamiento) , Built Surface 94.99m<sup>2</sup>, 3 Bedrooms, 1 Bathrooms, Lift.</h1>
            <div class="paginacion-ficha-pie">
                <hr>
                <a href="ficha/flat/redovan/ayuntamiento/8569/12340691/en/" class="paginacion-ficha-masinfo enviarPostHog" nombreEventoPostHog="View property list">+ INFO</a>
                
                    <div class="paginacion-ficha-preciorebajado">
                        <span class="paginacion-ficha-preciorebajadoTriangulo"></span>
                        <span class="paginacion-ficha-precioanterior">98.000 €</span> <span
                            class="paginacion-ficha-precioporcentaje">- 3&#37;</span>
                    </div>
                    
            </div>
        </div>
    </div>
</article><article class="paginacion-ficha propiedad" indice="11" tipo="paginacion">
  
  
  
    <div class="paginacion-ficha-bloque1 imagenesComoBackground fotopropiedad  fotosAlVuelo"
         style="background-image: url(img/nofotos.png);" cargaFoto="https://fotos15.apinmo.com/8569/12342018/5-1s.jpg">
        <span class="paginacion-ficha-tituloprecio">For sale 94.999 €</span> 
        
            <a href="#" class="flechaprev"></a>
            <a href="#" class="flechanext"></a>
        

        

        <a href="ficha/office/orihuela/zona-centro/8569/12342018/en/" class="irAfichaPropiedad enviarPostHog" nombreEventoPostHog="View property list">&nbsp;</a>

        
            <div class="paginacion-contacto">

                <div class="paginacion-contacto-foto fotosAlVuelo" style="background-image: url(img/nofotoagente.jpg);" cargaFoto="img/nofotoagente.jpg"></div>

                <div class="paginacion-contacto-datos">
                    <div class="paginacion-contacto-cuadrodatos">
                        <div class="paginacion-contacto-datosnombre"><i class="fa fa-user" style="font-size: 15px;margin-right: 5px;"></i>GESSICON </div>
                        <div class="paginacion-contacto-telefono"><i class="fa fa-phone" style="font-size: 15px;margin-right: 5px;"></i>+34 669 871 698</div>
                    </div>
                </div>
            </div>
        
    </div>

    <div class="paginacion-ficha-bloque2">
         <div class="paginacion-ficha-masdatos">
            <ul>
                <li class="bloque-icono-name-valor1">
                    <div>
                        <i class="fa fa-info fa-2x"></i>
                        <span>Reference</span>
                    </div>
                    <div>
                        <span>002355</span>
                    </div>
                </li>
                
                        <li class="bloque-icono-name-valor1">
                            <div>
                                <i class="habitacion"></i>
                                <span>Bedrooms</span>
                            </div>
                            <div>
                                <span>1</span>
                            </div>
                        </li>
                     
                         <li class="bloque-icono-name-valor1">
                             <div>
                                 <i class="bano"></i>
                                 <span>Bathrooms</span>
                             </div>
                             <div>
                                 <span>1</span>
                             </div>
                         </li>
                  

                
                    <li class="bloque-icono-name-valor1">
                        <div>
                            <i class="superficieico"></i>
                            <span>Surface</span>
                        </div>
                        <div>
                            <span>140 m2</span>
                        </div>
                    </li>
                

            </ul>
        </div>
        
        <div class="paginacion-ficha-datos">
            <h1 class="titulo">Office - Orihuela (Zona Centro) , Built Surface 140m<sup>2</sup>, 1 Room, Lift.</h1>
            <div class="paginacion-ficha-pie">
                <hr>
                <a href="ficha/office/orihuela/zona-centro/8569/12342018/en/" class="paginacion-ficha-masinfo enviarPostHog" nombreEventoPostHog="View property list">+ INFO</a>
                
                    <div class="paginacion-ficha-preciorebajado">
                        <span class="paginacion-ficha-preciorebajadoTriangulo"></span>
                        <span class="paginacion-ficha-precioanterior">99.999 €</span> <span
                            class="paginacion-ficha-precioporcentaje">- 5&#37;</span>
                    </div>
                    
            </div>
        </div>
    </div>
</article><article class="paginacion-ficha propiedad" indice="12" tipo="paginacion">
  
  
  
    <div class="paginacion-ficha-bloque1 imagenesComoBackground fotopropiedad  fotosAlVuelo"
         style="background-image: url(img/nofotos.png);" cargaFoto="https://fotos15.apinmo.com/8569/12341144/10-1s.jpg">
        <span class="paginacion-ficha-tituloprecio">For sale 99.000 €</span> 
        
            <a href="#" class="flechaprev"></a>
            <a href="#" class="flechanext"></a>
        

        

        <a href="ficha/terraced-house/orihuela/la-matanza/8569/12341144/en/" class="irAfichaPropiedad enviarPostHog" nombreEventoPostHog="View property list">&nbsp;</a>

        
            <div class="paginacion-contacto">

                <div class="paginacion-contacto-foto fotosAlVuelo" style="background-image: url(img/nofotoagente.jpg);" cargaFoto="img/nofotoagente.jpg"></div>

                <div class="paginacion-contacto-datos">
                    <div class="paginacion-contacto-cuadrodatos">
                        <div class="paginacion-contacto-datosnombre"><i class="fa fa-user" style="font-size: 15px;margin-right: 5px;"></i>GESSICON </div>
                        <div class="paginacion-contacto-telefono"><i class="fa fa-phone" style="font-size: 15px;margin-right: 5px;"></i>+34 669 871 698</div>
                    </div>
                </div>
            </div>
        
    </div>

    <div class="paginacion-ficha-bloque2">
         <div class="paginacion-ficha-masdatos">
            <ul>
                <li class="bloque-icono-name-valor1">
                    <div>
                        <i class="fa fa-info fa-2x"></i>
                        <span>Reference</span>
                    </div>
                    <div>
                        <span>002147</span>
                    </div>
                </li>
                
                        <li class="bloque-icono-name-valor1">
                            <div>
                                <i class="habitacion"></i>
                                <span>Bedrooms</span>
                            </div>
                            <div>
                                <span>3</span>
                            </div>
                        </li>
                     
                         <li class="bloque-icono-name-valor1">
                             <div>
                                 <i class="bano"></i>
                                 <span>Bathrooms</span>
                             </div>
                             <div>
                                 <span>1</span>
                             </div>
                         </li>
                  

                
                    <li class="bloque-icono-name-valor1">
                        <div>
                            <i class="superficieico"></i>
                            <span>Surface</span>
                        </div>
                        <div>
                            <span>90 m2</span>
                        </div>
                    </li>
                

            </ul>
        </div>
        
        <div class="paginacion-ficha-datos">
            <h1 class="titulo">Terraced house - Orihuela (La Matanza) , Built Surface 90m<sup>2</sup>, Plot Surface 300m<sup>2</sup>, 3 Bedrooms, 1 Bathrooms.</h1>
            <div class="paginacion-ficha-pie">
                <hr>
                <a href="ficha/terraced-house/orihuela/la-matanza/8569/12341144/en/" class="paginacion-ficha-masinfo enviarPostHog" nombreEventoPostHog="View property list">+ INFO</a>
                
            </div>
        </div>
    </div>
</article>
  </section>
  <footer id="paginacion-pie" class="paginador">
    <div id="paginacion-controlesIzq" class="enviarPostHog" nombreEventoPostHog="Change page">
        <a href="#" class="irAPrimeraPagina"><img src="img/primero.svg"></a>
        <a href="#" class="irAPaginaAnterior"><img src="img/anterior.svg" ></a>
    </div>
    <ul id="paginacion-numPaginas" class="paginador-numpaginas enviarPostHog" nombreEventoPostHog="Change page">
    
        <li><a  class="activa"  href="#">1</a></li>
        
        <li><a  href="#">2</a></li>
        
        <li><a  href="#">3</a></li>
        
        <li><a  href="#">4</a></li>
        
        <li><a  href="#">5</a></li>
        
        <li><a  href="#">6</a></li>
        
    </ul>
    <div id="paginacion-controlesDer" class="enviarPostHog" nombreEventoPostHog="Change page">
        <a href="#" class="irAPaginaSiguiente"><img src="img/siguiente.svg" alt=""></a>
        <a href="#" class="irAUltimaPagina"><img src="img/ultimo.svg" alt=""></a>
    </div>
    <div id="paginacion-controlesOpciones" class="paginador-controlesOpciones">
        <label for="paginacion-numElmenetosPagina" class="custom-select">
            <select id="paginacion-numElmenetosPagina" class="numElementosPorPagina" cambiaPaginacion('index.php?&idio=2&res=');>
                <option disabled selected>Properties</option>
                <option value="12" >12 Properties</option>
                <option value="24" >24 Properties</option>
                <option value="36" >36 Properties</option>
                <option value="48" >48 Properties</option>
                <!--option value="60" >60 Properties</option-->
            </select>
        </label>
        <input type="text" id="paginacion-irApagina" class="paginador-irApagina irApagina enviarPostHog" nombreEventoPostHog="Change page" placeholder="#Pag">
    </div>
  </footer>
</section>
<!-- mapapropiedades-1 / Mapa buscador -->
<section id="modulo-mapapropiedades-1" class="modulo-mapapropiedades" seccionPostHog="Properties map" style="background-image: url(img/mapapropiedades/mapapropiedades.gif);">

    <div class="mapapropiedades-contenedor enviarPostHog" nombreEventoPostHog="Show map" onclick="javascript:window.location.href='/index.php?vermapa=1&buscador=1#modulo-paginacionmapa'">
        <img src="img/mapapropiedades/iconoMapa.svg" />
        <span
            lang-data='Properties Map'
            lang-data2='See Map'>Properties Map</span>
        <div id="boton-vermapa">See Map</div>
    </div>

</section><!-- valoramostupiso-1 / Valoramos tu piso -->






    <section id="modulo-valoramostupiso-1" seccionPostHog="Rate Property" class="modulo-valoramostupiso fotosAlVuelo unset" cargaFoto="https://media.apinmo.com/galerias/imagenes/imagen8_*.jpg" imgResponsive="true"">




<div class="parte-izq">
    <div class="titulo">
        <h1 id="titulo-valoramostupido-1">Let's value your property</h1>
        Let´s valuate your property
        <div class="mensaje">Do you want to know the current market price of your property?</div>
    </div>
</div>
<div class="parte-der">
    <!--div class="mensaje">Do you want to know the current market price of your property?</div-->
     <div class="cajas">
         <div style="margin-bottom: 3px;"><input id="valorar-ciudad" type="text" placeholder="City"> <input id="valorar-calle" type="text" placeholder="Street, Number"></div>
         <div><select id="valorar-tipologia">
                 <option value="Piso">Apartment</option>
                 <option value="Duplex">Duplex</option>
                 <option value="Atico">Penthouse</option>
                 <option value="Chalet Independiente">Chalet Separate</option>
                 <option value="Planta Baja">Ground Floor</option>
                 <option value="Local Comercial">Business Premises</option>
             </select>
             <input id="valorar-planta" type="number" min="0" placeholder="Floor">
             <input id="valorar-habitaciones" min="0" type="number" placeholder="Bedrooms">
             <select id="valorar-ascensor">
                 <option value="No">Lift</option>
                 <option value="No">No</option>
                 <option value="Si">Yes</option>
             </select>
         </div>
         <button class="botonValorar enviarPostHog" nombreEventoPostHog="Rate">Value</button>
     </div>
 </div>


<div class="modalesOcultas">
            <div id="segundoPasoValorarmosTuPiso">
            <div id="modal-valoramostupiso">
                <div class="texto-titulo-form-valoramostupiso">You must give this detail so we can offer you the results of your property valuation.</div>
                <form id="formu-valoramostupiso" class="formuEnviar">

                    <input type="hidden" id="valoracion-ciudad">
                    <input type="hidden" id="valoracion-calle">
                    <input type="hidden" id="valoracion-tipologia">
                    <input type="hidden" id="valoracion-planta">
                    <input type="hidden" id="valoracion-habitaciones">

                    <div class="bloqueEnviar">
                        <span>Name (*)</span>
                        <input type="text" id="valoracion-nombre">
                    </div>
                    <div class="bloqueEnviar">
                        <span>Email (*)</span>
                        <input type="text" id="valoracion-email">
                    </div>
                    <div class="bloqueEnviar">
                        <span>Telephone </span>
                        <input type="text" id="valoracion-telefono">
                    </div>
                    <div>
                        <span>
                            <input type="checkbox" id="textolegal-valoracion" class="custom-checkbox">
                            <label for="textolegal-valoracion"></label>
                        </span>
                        <span class="texto-form-politica" onclick="modalNuestra('mytextoprivacidadPublica','Privacy Policy')">
                            When you press the button “SEND” you confirm you’ve read, understood and accepted the conditions of our Privacy Policy shown in this LINK
                        </span>
                    </div>
                </form>
                <div>
                    <button type="button" id="enviarValoracion" onClick="enviarValoracionPropiedad()">Send</button>
                </div>
            </div>
            </div>
        </div>
</section><!-- equipo-1 / equipo -->
<section id="modulo-equipo" class="bloque-modulo">
      

    <div id="equipo-flechas">
    <a href="#" id="equipo-prev" class="equipo-flecha"></a>
    <a href="#" id="equipo-next" class="equipo-flecha"></a>
  </div>
  <div id="equipo-contenedor">
    <section id="equipo-carrusel">
      
          
          
        <article class="equipo-bloque">
            <div  class="equipo-imagen"  style="" 
            ></div>
          <div class="equipo-bloquederecha">
              <div class="equipo-bloqueinfo">
                  <div class="equipo-nombre">Nombre y Apellidos</div>
                  <div class="equipo-puesto"></div>
              </div>

            <div class="equipo-descripcion"><p title=""></p></div>
            
          </div>
        </article>
        
    </section>

      
  </div>

    
        <div id="equipo-paginacion"></div>
    

    
    </section>
    
</section>
<!-- suscribete-1 / suscríbete -->






    <section id="modulo-suscribete-1" style="color: var(--color1);" cargaFoto="https://media.apinmo.com/galerias/imagenes/imagen2_*.jpg" imgResponsive="true" class="modulos-suscribete fotosAlVuelo unset">


    <div class="titulo">
        <h1 id="titulo-suscribete-1">Subscribe</h1>
        Subscribe to our mailing list and you will be first to receive new properties
    </div>
    <div class="cajas">
        <input id="emailSuscripcion" class="emailSuscripcion" type="text" placeholder="E-mail @">
        <button class="botonEnviar accionEnviar">Send</button>
        <div class="resultadoSuscribete"></div>
        <div class="opciones">
            <p><input id="checkPolitica" type="checkbox"> <label id="txtPoliticaSuscribete">Accept Privacy Policy</label></p>
            <p><input id="checkNewsletter" type="checkbox"> <label>Accept to receive advertisement</label></p>
        </div>
    </div>
</section>
<!-- ultimasentradas-1 / Noticias -->

</section><!-- pie-1 / pie -->

<footer id="modulo-pie-1" class="bloque-modulo modulo-pie">
    <div id="pie-fila1">
        <div id="pie-subfila1">
            <div id="pie-menu" seccionPostHog="Footer">
                <menu><li class="enviarPostHog" nombreEventoPostHog="Link"><a href="index.php" >Home</a></li><li class="enviarPostHog" nombreEventoPostHog="Link"><a href="for-sale/" >For sale</a></li><li class="enviarPostHog" nombreEventoPostHog="Link"><a href="rental/" >Rental</a></li><li class="enviarPostHog" nombreEventoPostHog="Link"><a href="promotions/" >Promotions</a></li><li class="enviarPostHog" nombreEventoPostHog="Link"><a href="seccion.php?sec=company&amp;nombre=company" >Company</a></li><li class="enviarPostHog" nombreEventoPostHog="Link"><a href="alertas.php" >Alerts</a></li><li class="enviarPostHog" nombreEventoPostHog="Link"><a href='./publica-tu-inmueble/'>List your property</a></li><li class="enviarPostHog" nombreEventoPostHog="Link"><a href="#" onclick="event.preventDefault();modalNuestra('mytextoprivacidadFooter','Privacy policy');">Privacy policy</a></li><li class="enviarPostHog" nombreEventoPostHog="Link"><a href="#" onclick="event.preventDefault();modalNuestra('mytextolegal','Legal advice');">Legal advice</a></li><li class="enviarPostHog" nombreEventoPostHog="Link"><a href="#" onclick='event.preventDefault(); modalPoliticaCookies(politicacookies, textoaviso, aceptar_todas,rechazar,gestionarcookies, textocookies, aceptar_selec, cerrar);'>Cookies policy</a></li></menu>
            </div>
            <div class="pie-agencia" seccionPostHog="Footer">


                <div class="pie-datosagenciaBloque1">
                    <div class="pie-datosagencia">
                        <ul>
                            <li class="titulo">Promociones Apihogares S.l</li>
                            
                            <li><a href="mailto:apihogares@gmail.com">apihogares@gmail.com</a></li>
                            <li><a href="https://www.gessicon.com">https://www.gessicon.com</a></li>
                                <li>
                                    <a href="tel:638 062 858">638 062 858</a>
                                    <br><span id="textotel">
                                        
                                    </span>
                                     <br> 
                                    <a href="tel:638 062 858">638 062 858</a>
                                    <br><span id="textotel">
                                        
                                    </span>
                                </li>
                            <li>Extremadura, bajo 3 Orihuela 03300 (Alicante)</li>
                        </ul>
                    </div>
                    <div class="pie-datosagenciaLogo">
                        <img src="img/header/logo.png" alt="Logo Promociones Apihogares S.l">
                    </div>
                </div>
                
                    <button type="button" id=mostrarMapa_0" class="botonMostarMapa" onclick="mostrar_ocultar_mapa(0);">Map</button>

                    
                        <div id="mapaOficina_0" class="pie-datosagenciaBloque2">
                    
                        <iframe class="pie-iframemapa srcAlVuelo enviarPostHog" nombreEventoPostHog="Map" loading="lazy" frameborder="0" marginwidth="0" marginheight="0" rutaSrc="https://procesos.apinmo.com/externo/googleplano.php?individual=si&coordenadas=38.07831253,-0.94617752"></iframe>
                    </div>
                


            


            </div>
            <div id="pie-contacto" seccionPostHog="Contact">
                <form class="contacto">
                    <fieldset>
                        <legend>Contact us</legend>
                        <dl>
                            <dt>
                                <input type="text" id="pie-nombre" placeholder="Name (*)">
                            </dt>
                        </dl>
                        <dl>
                            <dt>
                                <input type="text" id="pie-email" placeholder="Email (*)">
                            </dt>
                        </dl>
                        <dl>
                            <dt>
                                <input type="text" id="pie-telefono" placeholder="Telephone">
                            </dt>
                        </dl>
                        
                        <dl>
                            <dt>
                                <textarea id="pie-descripcion" placeholder="Description (*)"></textarea>
                            </dt>
                        </dl>
                        <dl>
                            <dd>
                                <div class="bloque-checkbox">
                                    <input type="checkbox" id="textolegal3" class="custom-checkbox">
                                    <label for="textolegal3"></label>
                                </div>
                                <span class="textolegal" id="eltextolegal3">When you press the button “SEND” you confirm you’ve read, understood and accepted the conditions of our Privacy Policy shown in this LINK</span>
                            </dd>
                        </dl>
                        <dl>
                            <dt>
                                <span class="resultadoInfo"></span>
                                <button type="button" class="botonEnviar enviaForm enviarPostHog" nombreEventoPostHog="Send contact">Send</button>
                            </dt>
                        </dl>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
    <aside id="pie-filaSocial">
        <menu lang-data="Follow us">
  <span id="titulo-pie-pagina">Follow us</span>
            <li>
              <a target="_blank" rel="noopener noreferrer" href="/rss"><img src="img/social/rss2.png" alt="RSS" style="height: 40px;opacity: 0.8;"></a>
          </li>
      </menu>
    </aside>
</footer>



<div id="modulo-disenyadoinmovilla-1" class="bloque-modulo">
  <span>Designed by <a href="http://www.facebook.com/crminmovilla" rel="noreferrer" target="_blank">CRM Inmovilla</a></span>
</div>
    </div>
    <script src="js/lib/jquery-3.5.1.min.js"></script>
    <script src="js/lib/jquery-ui.min.js"></script>
    <script src='https://www.google.com/recaptcha/api.js?render=6LeFvHcUAAAAADkYzbLtZuO5lRdgl6gpLYovrRwl'></script>
    <script>
    var numagencia = 8569;
    var inmonombre = 'Promociones Apihogares S.l';
    var urlBase = `https://www.gessicon.com`;
    var listados = {};
    var hastagPaginacion = '#modulo-paginacion';
    var hastagPaginacionMapa = '#modulo-paginacionmapa';
    var desactivarNotificacionPush = false;
    var esMovil = 0;
    var unsolocontacto = '1';
    var soyIframe = false;
    var soyWebPortuguesa = false;
    var actual = 'index.php';
    var esListado = true;
    var idio = '2';
    var idio_txt = 'en';
    var urlAreas = 'https://apiweb.inmovilla.com/apiweb/config/8569_185.57.173.244_1/areas.json';
</script>    <script src="js/EnviarPostHog.js?x=20260506150310"></script>
    <script src="js/funciones.js?x=20260506150310"></script>
    <script src="buscadorareas/componentes-v3-externo.js?x=20260506150310"></script>
    <!-- posthog -->
    <script>
        /*
        !function(t,e){var o,n,p,r;e.__SV||(window.posthog=e,e._i=[],e.init=function(i,s,a){function g(t,e){var o=e.split(".");2==o.length&&(t=t[o[0]],e=o[1]),t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}}(p=t.createElement("script")).type="text/javascript",p.async=!0,p.src=s.api_host+"/static/array.js",(r=t.getElementsByTagName("script")[0]).parentNode.insertBefore(p,r);var u=e;for(void 0!==a?u=e[a]=[]:a="posthog",u.people=u.people||[],u.toString=function(t){var e="posthog";return"posthog"!==a&&(e+="."+a),t||(e+=" (stub)"),e},u.people.toString=function(){return u.toString(1)+".people (stub)"},o="capture identify alias people.set people.set_once set_config register register_once unregister opt_out_capturing has_opted_out_capturing opt_in_capturing reset isFeatureEnabled onFeatureFlags getFeatureFlag getFeatureFlagPayload reloadFeatureFlags group updateEarlyAccessFeatureEnrollment getEarlyAccessFeatures getActiveMatchingSurveys getSurveys onSessionId".split(" "),n=0;n<o.length;n++)g(u,o[n]);e._i.push([i,s,a])},e.__SV=1)}(document,window.posthog||[]);
        posthog.init('phc_gMjYRPEacx4ZPimRXWQhrGueXINnBrAoLwxAoJloief',{api_host:'https://posthog.inmovilla.com'})

        let EnviarPostHogObj = new EnviarPostHog();
         */
    </script>
    <script src="js/modulos/comun/comun-buscadores.js?x=20260506150310"></script>


<script>
    var provinciaSeleccionadaPorDefecto = false;
</script>
<script src="js/modulos/comun/buscador.js?x=20260506150310"></script>


<script>
    var mostrarBuscadorAvanzado = false;
        var provinciaSeleccionadaPorDefecto = false;
    </script>
<script src="js/modulos/comun/buscadorAvanzado.js?x=20260506150310"></script>

<script>
    var header,browser,browserModuloPadre,headerBrowser,sticky,stickyBrowser,idiomas,telefono,logo,section,buscadorCabecera;
    var opCabecera = 1;

    $(document).ready(function () {

        if(!parseInt(esMovil) || window.innerWidth > 600) {
            //alert(esMovil);
            header = document.getElementById("modulo-cabecera-1");
            browser = document.querySelector('.buscadorRapido:not(#cabecera-buscador)');
            browserModuloPadre = $(browser).closest('.bloque-modulo');
            headerBrowser = document.querySelector('#cabecera-bloque-buscador');
            sticky = header.offsetTop + 41;
            if (browser != null)
                stickyBrowser = browser.offsetTop + browserModuloPadre[0].offsetTop - 15;
            else
                stickyBrowser = false;
            idiomas = document.querySelector('#header-bloqueidiomas');
            telefono = document.querySelector('#header-bloquetfno');
            logo = document.querySelector('#header-logo');
            section = document.querySelector('#supercontenedor');
            buscadorCabecera = document.querySelector('#cabecera-buscador');

            if ($(window).scrollTop()) {
                setSticky();
            }
            window.onscroll = function () {
                setSticky()
            };

        } else {

            if (opCabecera == 0) {
                sliimage = document.querySelector('.slider-1');
                sliimage.style.display = 'none';
                mbavanzado = document.querySelector('#buscAvanzado-buscador');
                mbavanzado.style.marginTop = "20px";
            }
        }

    });


    function setSticky() {
        if (window.innerWidth < 960) {
            section.style.marginTop = '0';
            return false;
        }
        if (window.pageYOffset > sticky) {
            header.classList.add("sticky");
            idiomas.style.display = 'none';
            telefono.style.display = '';
            if(window.pageYOffset > stickyBrowser || stickyBrowser === false)
                headerBrowser.style.display = 'block';
            else
                headerBrowser.style.display = 'none';

            $(logo).fadeIn()
                .css({position:'absolute',top:-70})
                .animate({top:-200}, 222, function() {
                });
            section.style.marginTop = '140px';
            if (buscadorCabecera) {
                if (document.querySelector('#slider-bloque-buscador.slider-bloque-buscador-1')){
                    if (window.pageYOffset > (document.querySelector('section[id *= "modulo-slider-"]').offsetHeight - header.offsetHeight)){
                        buscadorCabecera.classList.remove('d-none');
                    }else{
                        buscadorCabecera.classList.add('d-none')
                    }
                }else{
                    buscadorCabecera.classList.remove('d-none');
                }
            }
        } else {
            header.classList.remove("sticky");
            idiomas.style.display = 'flex';
            telefono.style.display = 'flex';
            $(logo).stop(true);
            $(logo).css("top", "");
            $(logo).css("position", "");
            section.style.marginTop = '0';
            if (buscadorCabecera) {
                buscadorCabecera.classList.add('d-none')
            }
        }
    }

    //Sustituimos el parámetro del idioma por el que nos llegue
    function idioma(nuevoidio, event=false) {

        const button = event.which || event.button;
        //Si el botón es 2 significa que se ha pulsado la rueda del ratón

        const input = window.location.toString();
        const comprobar = new RegExp("/" + nuevoidio + "\\/?$")

        const comprobaridioma = comprobar.test(input);
        if(comprobaridioma == true){
            return;
        }
        const regex = /\/[A-Za-z]{2}\/?$/g;
        const result = regex.test(input);

        if(result == true){
            const output = input.replace(regex, `/${nuevoidio}/`);
            if(button == 2){
                newurl = window.location.href.toString().replace(regex, `/${nuevoidio}/`);
                window.open(newurl,'_blank');
            } else {
                window.location.replace(output);
            }

        }
        else if (input.includes("idio=")) {
            let url = new URL(window.location.href);
            let params = new URLSearchParams((url.search));
            let number = params.get("idio");
            params.set("idio", idiomanumero(nuevoidio));
            if(button == 2){
                console.log(number)
                newurl = window.location.href.toString().replace("idio="+number,"idio="+idiomanumero(nuevoidio))
                window.open(newurl,'_blank');
            } else {
                window.location.replace(url.origin + url.pathname + '?' + params);
            }

        }
        else if(input.includes("/noticia/")){
            if(button == 2){
                newurl = window.location.href.toString().concat("/" + nuevoidio )
                window.open(newurl,'_blank');
            } else{
                window.location.replace(input.concat("/" + nuevoidio ));
            }

        }
        else if(input.includes(".php")){

            if(button == 2){
                newurl = window.location.toString().concat("?idio=" + idiomanumero(nuevoidio))
                window.open(newurl,'_blank');
            } else{
                let inicioParametros = window.location.href.includes('?') ? '&' : '?';
                let nuevaUrl = `${input}${inicioParametros}idio=${idiomanumero(nuevoidio)}`;
                window.location.replace(nuevaUrl);
            }

        }
        else if(input.includes("/promocion/") || input.includes("/empreendimentos/")){
            var path = input.split("/")
            if (path[path.length-2] == 8){
                path[path.length-2] = 'pt';
            }

            var newurl = ""

            path[path.length-2] = idiomanumero(nuevoidio)

            path.forEach((element) =>  newurl += element+"/");

            newurl = newurl.slice(0,-1)

            if(button == 2){
                window.open(newurl,'_blank');
            } else{
                window.location.href = newurl;
            }

        }
        else {
            if(button == 2){
                newurl = window.location.href.toString().concat("" + nuevoidio )
                window.open(newurl,'_blank');
            } else{
                if ((input.includes("plantilla_prev=") || input.includes("agente=")) && !input.includes("idio=")) {
                    window.location.replace(input.concat("&idio=" + idiomanumero(nuevoidio)));
                }else{
                    window.location.replace(input.concat("" + nuevoidio ));
                }
            }

        }
    }
    //Mapeo de idiomas para comprobar su número
    function idiomanumero(nuevoidio) {
        switch(nuevoidio) {
            case "es":
                return 1;
            case "ca":
                return 12;
            case "eu":
                return 16;
            case "en":
                return 2;
            case "de":
                return 3;
            case "fr":
                return 4;
            case "it":
                return 15;
            case "no":
                return 6;
            case "fi":
                return 10;
            case "sv":
                return 9;
            case "ru":
                return 7;
            case "nl":
                return 5;
            case "zh":
                return 11;
            case "pl":
                return 17;
            case "pt":
                return 8;
            case "lt":
                return 22;
            case "da":
                return 19;
            case "gl":
                return 18;
            case "uk":
                return 24;
            case "bg":
                return 25;
        }
    }

</script>
<script src="js/modulos/cabecera/cabecera.js?x=20260506150310"></script>
<script>
    listados.destacadosestrella = [{"posicion":1,"elementos":1,"total":1},{"cod_ofer":12341515,"keyacci":1,"banyos":1,"ref":"002520","nodisponible":0,"precioinmo":87999,"preciotraspaso":0,"key_loca":41199,"key_zona":3355899,"key_tipo":3399,"m_parcela":0,"balcon":1,"m_cons":101,"m_uties":80,"conservacion":50,"calefacentral":0,"airecentral":0,"plaza_gara":0,"terraza":0,"ascensor":0,"montacargas":0,"muebles":0,"calefaccion":1,"aire_con":1,"primera_line":0,"piscina_com":0,"piscina_prop":0,"habitaciones":0,"total_hab":2,"sumaseos":1,"repercusion":871.27722772277,"nbtipo":"Flat","nbconservacion":"Refurbished","exclu":0,"parking":0,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":25,"eninternet":1,"zonaauxiliar":"","urbanizacion":0,"destacado":2,"habdobles":2,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.95066438137715,"latitud":38.083417983154,"mls":0,"numfotos":18,"fotoletra":13,"keypromo":0,"fechacambio":"2025-02-27 02:18:28","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":89900,"aseos":0,"tipomensual":"MES","srvfotos":15,"soysrv":15,"ciudad":"Orihuela","zona":"Zona Centro","keyprov":4,"foto":"https:\/\/fotos15.apinmo.com\/8569\/12341515\/13-1.jpg","tituloauto":"Flat Orihuela","tituloautoSliderdestacado":"Flat - Orihuela (Zona Centro) ","precioauto":"87.999 \u20ac","superficieauto":"101 mts","banyosauto":1,"fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/12341515\/13-1s.jpg","urlfichaauto":"ficha\/flat\/orihuela\/zona-centro\/8569\/12341515\/en\/"}];
    var destacadosestrellaActual = 1;

    var imagesCab = ["img/slider/1_*.jpg","","","img/slider/2_*.jpg","","","img/slider/3_*.jpg","","","img/slider/4_*.jpg","",""];</script>

<script src="js/modulos/slider/slider.js?x=20260506150310"></script>


<script src="js/lib/revolution/jquery.themepunch.revolution.min.js"></script>
<script src="js/lib/carrusel/carrusel.min.js"></script>
<script src="js/lib/carrusel/jquery.carouFredSel-6.2.1-packed.js"></script>
<script src="js/modulos/destacados/destacados.js?x=20260506150310"></script>
<script>
    listados.destacados = {"1":{"cod_ofer":12341101,"keyacci":1,"banyos":1,"ref":"002111","nodisponible":0,"precioinmo":89900,"tour_virtual":0,"preciotraspaso":0,"key_loca":41199,"key_zona":3720299,"key_tipo":7499,"m_parcela":0,"balcon":1,"m_cons":65,"m_uties":60,"conservacion":50,"calefacentral":0,"airecentral":0,"plaza_gara":0,"terraza":0,"ascensor":0,"montacargas":0,"muebles":1,"calefaccion":1,"aire_con":1,"primera_line":0,"piscina_com":1,"piscina_prop":0,"habitaciones":0,"total_hab":2,"sumaseos":1,"repercusion":1383.0769230769,"nbtipo":"Bungalow Ground Floor","nbconservacion":"Refurbished","exclu":0,"parking":0,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":25,"eninternet":1,"zonaauxiliar":"La Campanets","urbanizacion":1,"destacado":1,"habdobles":2,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.89504526610114,"latitud":38.089090553509,"mls":0,"numfotos":11,"fotoletra":4,"keypromo":0,"fechacambio":"2025-02-27 02:18:23","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":95000,"aseos":0,"tipomensual":"MES","srvfotos":15,"soysrv":15,"ciudad":"Orihuela","zona":"Molins-Campaneta-San Bartolom\u00e9","keyprov":4,"foto":"https:\/\/fotos15.apinmo.com\/8569\/12341101\/4-1.jpg","tituloauto":"Bungalow Ground Floor - Orihuela (Molins-Campaneta-San Bartolom\u00e9) ","tituloDefecto":"Bungalow Ground Floor - Orihuela...","precioauto":"89.900 \u20ac","superficieauto":"65 m2","banyosauto":1,"fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/12341101\/4-1s.jpg","urlfichaauto":"ficha\/bungalow-ground-floor\/orihuela\/molins-campaneta-san-bartolome\/8569\/12341101\/en\/"},"2":{"cod_ofer":12340691,"keyacci":1,"banyos":1,"ref":"001251","nodisponible":0,"precioinmo":94999,"tour_virtual":0,"preciotraspaso":0,"key_loca":42699,"key_zona":2188811,"key_tipo":3399,"m_parcela":0,"balcon":0,"m_cons":94.99,"m_uties":90,"conservacion":15,"calefacentral":0,"airecentral":0,"plaza_gara":0,"terraza":0,"ascensor":1,"montacargas":0,"muebles":1,"calefaccion":1,"aire_con":1,"primera_line":0,"piscina_com":0,"piscina_prop":0,"habitaciones":0,"total_hab":3,"sumaseos":1,"repercusion":1000.0947468155,"nbtipo":"Flat","nbconservacion":"Reformar Parcialment","exclu":0,"parking":0,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":25,"eninternet":1,"zonaauxiliar":"","urbanizacion":0,"destacado":1,"habdobles":3,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.906975043,"latitud":38.113658715,"mls":0,"numfotos":20,"fotoletra":9,"keypromo":0,"fechacambio":"2025-02-27 02:18:16","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":98000,"aseos":0,"tipomensual":"MES","srvfotos":15,"soysrv":15,"ciudad":"Redovan","zona":"Ayuntamiento","keyprov":4,"foto":"https:\/\/fotos15.apinmo.com\/8569\/12340691\/9-1.jpg","tituloauto":"Flat - Redovan (Ayuntamiento) ","tituloDefecto":"Flat - Redovan (Ayuntamiento) ","precioauto":"94.999 \u20ac","superficieauto":"94.99 m2","banyosauto":1,"fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/12340691\/9-1s.jpg","urlfichaauto":"ficha\/flat\/redovan\/ayuntamiento\/8569\/12340691\/en\/"},"3":{"cod_ofer":21208505,"keyacci":1,"banyos":2,"ref":"5958659","nodisponible":0,"precioinmo":159999,"tour_virtual":0,"preciotraspaso":0,"key_loca":42699,"key_zona":3963899,"key_tipo":299,"m_parcela":0,"balcon":1,"m_cons":130,"m_uties":125,"conservacion":70,"calefacentral":0,"airecentral":1,"plaza_gara":2,"terraza":0,"ascensor":0,"montacargas":0,"muebles":1,"calefaccion":1,"aire_con":1,"primera_line":0,"piscina_com":1,"piscina_prop":0,"habitaciones":0,"total_hab":3,"sumaseos":3,"repercusion":1230.7615384615,"nbtipo":"Bungalow","nbconservacion":"New","exclu":0,"parking":2,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":25,"eninternet":1,"zonaauxiliar":"","urbanizacion":1,"destacado":1,"habdobles":3,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.91587726907437,"latitud":38.118229301765,"mls":0,"numfotos":20,"fotoletra":45,"keypromo":0,"fechacambio":"2025-08-20 19:20:07","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":165000,"aseos":1,"tipomensual":"MES","srvfotos":15,"soysrv":15,"ciudad":"Redovan","zona":"Comunidad valenciana","keyprov":4,"foto":"https:\/\/fotos15.apinmo.com\/8569\/21208505\/45-1.jpg","tituloauto":"Bungalow - Redovan (Comunidad valenciana) ","tituloDefecto":"Bungalow - Redovan (Comunidad valenciana) ","precioauto":"159.999 \u20ac","superficieauto":"130 m2","banyosauto":3,"fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/21208505\/45-1s.jpg","urlfichaauto":"ficha\/bungalow\/redovan\/comunidad-valenciana\/8569\/21208505\/en\/"},"4":{"cod_ofer":28837866,"keyacci":1,"banyos":2,"ref":"001212125","nodisponible":0,"precioinmo":168000,"tour_virtual":0,"preciotraspaso":0,"key_loca":41199,"key_zona":3355899,"key_tipo":3399,"m_parcela":0,"balcon":1,"m_cons":214,"m_uties":100,"conservacion":60,"calefacentral":0,"airecentral":1,"plaza_gara":2,"terraza":0,"ascensor":1,"montacargas":0,"muebles":1,"calefaccion":1,"aire_con":1,"primera_line":0,"piscina_com":0,"piscina_prop":0,"habitaciones":0,"total_hab":3,"sumaseos":2,"repercusion":785.04672897196,"nbtipo":"Flat","nbconservacion":"Semi New","exclu":0,"parking":2,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":23,"eninternet":1,"zonaauxiliar":"","urbanizacion":0,"destacado":1,"habdobles":3,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.94623026509197,"latitud":38.078661764461,"mls":0,"numfotos":25,"fotoletra":71,"keypromo":0,"fechacambio":"2025-08-22 00:07:34","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":175000,"aseos":0,"tipomensual":"MES","srvfotos":15,"soysrv":15,"ciudad":"Orihuela","zona":"Zona Centro","keyprov":4,"foto":"https:\/\/fotos15.apinmo.com\/8569\/28837866\/71-1.jpg","tituloauto":"Flat - Orihuela (Zona Centro) ","tituloDefecto":"Flat - Orihuela (Zona Centro) ","precioauto":"168.000 \u20ac","superficieauto":"214 m2","banyosauto":2,"fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/28837866\/71-1s.jpg","urlfichaauto":"ficha\/flat\/orihuela\/zona-centro\/8569\/28837866\/en\/"},"5":{"cod_ofer":15970004,"keyacci":1,"banyos":2,"ref":"13256988","nodisponible":0,"precioinmo":169000,"tour_virtual":0,"preciotraspaso":0,"key_loca":41199,"key_zona":3355899,"key_tipo":3399,"m_parcela":0,"balcon":1,"m_cons":104.99,"m_uties":100,"conservacion":30,"calefacentral":0,"airecentral":0,"plaza_gara":1,"terraza":1,"ascensor":1,"montacargas":0,"muebles":1,"calefaccion":1,"aire_con":1,"primera_line":0,"piscina_com":0,"piscina_prop":0,"habitaciones":0,"total_hab":3,"sumaseos":2,"repercusion":1609.6771121059,"nbtipo":"Flat","nbconservacion":"Good condition","exclu":0,"parking":0,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":11,"eninternet":1,"zonaauxiliar":"","urbanizacion":0,"destacado":1,"habdobles":3,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.9440036,"latitud":38.08365922,"mls":0,"numfotos":26,"fotoletra":11,"keypromo":0,"fechacambio":"2025-02-27 02:18:39","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":180000,"aseos":0,"tipomensual":"MES","srvfotos":15,"soysrv":15,"ciudad":"Orihuela","zona":"Zona Centro","keyprov":4,"foto":"https:\/\/fotos15.apinmo.com\/8569\/15970004\/11-1.jpg","tituloauto":"Flat - Orihuela (Zona Centro) ","tituloDefecto":"Flat - Orihuela (Zona Centro) ","precioauto":"169.000 \u20ac","superficieauto":"104.99 m2","banyosauto":2,"fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/15970004\/11-1s.jpg","urlfichaauto":"ficha\/flat\/orihuela\/zona-centro\/8569\/15970004\/en\/"},"6":{"cod_ofer":23534390,"keyacci":1,"banyos":2,"ref":"5265326352","nodisponible":0,"precioinmo":259900,"tour_virtual":0,"preciotraspaso":0,"key_loca":41199,"key_zona":3406899,"key_tipo":21199,"m_parcela":0,"balcon":1,"m_cons":180,"m_uties":150,"conservacion":30,"calefacentral":1,"airecentral":1,"plaza_gara":2,"terraza":1,"ascensor":0,"montacargas":0,"muebles":1,"calefaccion":1,"aire_con":1,"primera_line":0,"piscina_com":0,"piscina_prop":0,"habitaciones":0,"total_hab":4,"sumaseos":3,"repercusion":1443.8888888889,"nbtipo":"House Type Duplex","nbconservacion":"Good condition","exclu":0,"parking":2,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":23,"eninternet":1,"zonaauxiliar":"","urbanizacion":1,"destacado":1,"habdobles":4,"destestrella":0,"opcioncompra":0,"m_terraza":30,"interesante":0,"altitud":-0.94738136854414,"latitud":38.078988627854,"mls":0,"numfotos":24,"fotoletra":46,"keypromo":0,"fechacambio":"2025-06-10 13:07:24","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":285000,"aseos":1,"tipomensual":"MES","srvfotos":15,"soysrv":15,"ciudad":"Orihuela","zona":"Los Andenes","keyprov":4,"foto":"https:\/\/fotos15.apinmo.com\/8569\/23534390\/46-1.jpg","tituloauto":"House Type Duplex - Orihuela (Los Andenes) ","tituloDefecto":"House Type Duplex - Orihuela (Los Andenes) ","precioauto":"259.900 \u20ac","superficieauto":"180 m2","banyosauto":3,"fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/23534390\/46-1s.jpg","urlfichaauto":"ficha\/house-type-duplex\/orihuela\/los-andenes\/8569\/23534390\/en\/"}};
    listados.destacadosTipos = {"tipo":{"1":{"cod_ofer":12341101,"keyacci":1,"banyos":1,"ref":"002111","nodisponible":0,"precioinmo":89900,"tour_virtual":0,"preciotraspaso":0,"key_loca":41199,"key_zona":3720299,"key_tipo":7499,"m_parcela":0,"balcon":1,"m_cons":65,"m_uties":60,"conservacion":50,"calefacentral":0,"airecentral":0,"plaza_gara":0,"terraza":0,"ascensor":0,"montacargas":0,"muebles":1,"calefaccion":1,"aire_con":1,"primera_line":0,"piscina_com":1,"piscina_prop":0,"habitaciones":0,"total_hab":2,"sumaseos":1,"repercusion":1383.0769230769,"nbtipo":"Bungalow Ground Floor","nbconservacion":"Refurbished","exclu":0,"parking":0,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":25,"eninternet":1,"zonaauxiliar":"La Campanets","urbanizacion":1,"destacado":1,"habdobles":2,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.89504526610114,"latitud":38.089090553509,"mls":0,"numfotos":11,"fotoletra":4,"keypromo":0,"fechacambio":"2025-02-27 02:18:23","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":95000,"aseos":0,"tipomensual":"MES","srvfotos":15,"soysrv":15,"ciudad":"Orihuela","zona":"Molins-Campaneta-San Bartolom\u00e9","keyprov":4,"foto":"https:\/\/fotos15.apinmo.com\/8569\/12341101\/4-1.jpg","tituloauto":"Bungalow Ground Floor - Orihuela (Molins-Campaneta-San Bartolom\u00e9) ","tituloDefecto":"Bungalow Ground Floor - Orihuela...","precioauto":"89.900 \u20ac","superficieauto":"65 m2","banyosauto":1,"fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/12341101\/4-1s.jpg","urlfichaauto":"ficha\/bungalow-ground-floor\/orihuela\/molins-campaneta-san-bartolome\/8569\/12341101\/en\/"},"2":{"cod_ofer":12340691,"keyacci":1,"banyos":1,"ref":"001251","nodisponible":0,"precioinmo":94999,"tour_virtual":0,"preciotraspaso":0,"key_loca":42699,"key_zona":2188811,"key_tipo":3399,"m_parcela":0,"balcon":0,"m_cons":94.99,"m_uties":90,"conservacion":15,"calefacentral":0,"airecentral":0,"plaza_gara":0,"terraza":0,"ascensor":1,"montacargas":0,"muebles":1,"calefaccion":1,"aire_con":1,"primera_line":0,"piscina_com":0,"piscina_prop":0,"habitaciones":0,"total_hab":3,"sumaseos":1,"repercusion":1000.0947468155,"nbtipo":"Flat","nbconservacion":"Reformar Parcialment","exclu":0,"parking":0,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":25,"eninternet":1,"zonaauxiliar":"","urbanizacion":0,"destacado":1,"habdobles":3,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.906975043,"latitud":38.113658715,"mls":0,"numfotos":20,"fotoletra":9,"keypromo":0,"fechacambio":"2025-02-27 02:18:16","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":98000,"aseos":0,"tipomensual":"MES","srvfotos":15,"soysrv":15,"ciudad":"Redovan","zona":"Ayuntamiento","keyprov":4,"foto":"https:\/\/fotos15.apinmo.com\/8569\/12340691\/9-1.jpg","tituloauto":"Flat - Redovan (Ayuntamiento) ","tituloDefecto":"Flat - Redovan (Ayuntamiento) ","precioauto":"94.999 \u20ac","superficieauto":"94.99 m2","banyosauto":1,"fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/12340691\/9-1s.jpg","urlfichaauto":"ficha\/flat\/redovan\/ayuntamiento\/8569\/12340691\/en\/"},"3":{"cod_ofer":21208505,"keyacci":1,"banyos":2,"ref":"5958659","nodisponible":0,"precioinmo":159999,"tour_virtual":0,"preciotraspaso":0,"key_loca":42699,"key_zona":3963899,"key_tipo":299,"m_parcela":0,"balcon":1,"m_cons":130,"m_uties":125,"conservacion":70,"calefacentral":0,"airecentral":1,"plaza_gara":2,"terraza":0,"ascensor":0,"montacargas":0,"muebles":1,"calefaccion":1,"aire_con":1,"primera_line":0,"piscina_com":1,"piscina_prop":0,"habitaciones":0,"total_hab":3,"sumaseos":3,"repercusion":1230.7615384615,"nbtipo":"Bungalow","nbconservacion":"New","exclu":0,"parking":2,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":25,"eninternet":1,"zonaauxiliar":"","urbanizacion":1,"destacado":1,"habdobles":3,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.91587726907437,"latitud":38.118229301765,"mls":0,"numfotos":20,"fotoletra":45,"keypromo":0,"fechacambio":"2025-08-20 19:20:07","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":165000,"aseos":1,"tipomensual":"MES","srvfotos":15,"soysrv":15,"ciudad":"Redovan","zona":"Comunidad valenciana","keyprov":4,"foto":"https:\/\/fotos15.apinmo.com\/8569\/21208505\/45-1.jpg","tituloauto":"Bungalow - Redovan (Comunidad valenciana) ","tituloDefecto":"Bungalow - Redovan (Comunidad valenciana) ","precioauto":"159.999 \u20ac","superficieauto":"130 m2","banyosauto":3,"fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/21208505\/45-1s.jpg","urlfichaauto":"ficha\/bungalow\/redovan\/comunidad-valenciana\/8569\/21208505\/en\/"},"4":{"cod_ofer":28837866,"keyacci":1,"banyos":2,"ref":"001212125","nodisponible":0,"precioinmo":168000,"tour_virtual":0,"preciotraspaso":0,"key_loca":41199,"key_zona":3355899,"key_tipo":3399,"m_parcela":0,"balcon":1,"m_cons":214,"m_uties":100,"conservacion":60,"calefacentral":0,"airecentral":1,"plaza_gara":2,"terraza":0,"ascensor":1,"montacargas":0,"muebles":1,"calefaccion":1,"aire_con":1,"primera_line":0,"piscina_com":0,"piscina_prop":0,"habitaciones":0,"total_hab":3,"sumaseos":2,"repercusion":785.04672897196,"nbtipo":"Flat","nbconservacion":"Semi New","exclu":0,"parking":2,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":23,"eninternet":1,"zonaauxiliar":"","urbanizacion":0,"destacado":1,"habdobles":3,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.94623026509197,"latitud":38.078661764461,"mls":0,"numfotos":25,"fotoletra":71,"keypromo":0,"fechacambio":"2025-08-22 00:07:34","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":175000,"aseos":0,"tipomensual":"MES","srvfotos":15,"soysrv":15,"ciudad":"Orihuela","zona":"Zona Centro","keyprov":4,"foto":"https:\/\/fotos15.apinmo.com\/8569\/28837866\/71-1.jpg","tituloauto":"Flat - Orihuela (Zona Centro) ","tituloDefecto":"Flat - Orihuela (Zona Centro) ","precioauto":"168.000 \u20ac","superficieauto":"214 m2","banyosauto":2,"fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/28837866\/71-1s.jpg","urlfichaauto":"ficha\/flat\/orihuela\/zona-centro\/8569\/28837866\/en\/"},"5":{"cod_ofer":15970004,"keyacci":1,"banyos":2,"ref":"13256988","nodisponible":0,"precioinmo":169000,"tour_virtual":0,"preciotraspaso":0,"key_loca":41199,"key_zona":3355899,"key_tipo":3399,"m_parcela":0,"balcon":1,"m_cons":104.99,"m_uties":100,"conservacion":30,"calefacentral":0,"airecentral":0,"plaza_gara":1,"terraza":1,"ascensor":1,"montacargas":0,"muebles":1,"calefaccion":1,"aire_con":1,"primera_line":0,"piscina_com":0,"piscina_prop":0,"habitaciones":0,"total_hab":3,"sumaseos":2,"repercusion":1609.6771121059,"nbtipo":"Flat","nbconservacion":"Good condition","exclu":0,"parking":0,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":11,"eninternet":1,"zonaauxiliar":"","urbanizacion":0,"destacado":1,"habdobles":3,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.9440036,"latitud":38.08365922,"mls":0,"numfotos":26,"fotoletra":11,"keypromo":0,"fechacambio":"2025-02-27 02:18:39","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":180000,"aseos":0,"tipomensual":"MES","srvfotos":15,"soysrv":15,"ciudad":"Orihuela","zona":"Zona Centro","keyprov":4,"foto":"https:\/\/fotos15.apinmo.com\/8569\/15970004\/11-1.jpg","tituloauto":"Flat - Orihuela (Zona Centro) ","tituloDefecto":"Flat - Orihuela (Zona Centro) ","precioauto":"169.000 \u20ac","superficieauto":"104.99 m2","banyosauto":2,"fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/15970004\/11-1s.jpg","urlfichaauto":"ficha\/flat\/orihuela\/zona-centro\/8569\/15970004\/en\/"},"6":{"cod_ofer":23534390,"keyacci":1,"banyos":2,"ref":"5265326352","nodisponible":0,"precioinmo":259900,"tour_virtual":0,"preciotraspaso":0,"key_loca":41199,"key_zona":3406899,"key_tipo":21199,"m_parcela":0,"balcon":1,"m_cons":180,"m_uties":150,"conservacion":30,"calefacentral":1,"airecentral":1,"plaza_gara":2,"terraza":1,"ascensor":0,"montacargas":0,"muebles":1,"calefaccion":1,"aire_con":1,"primera_line":0,"piscina_com":0,"piscina_prop":0,"habitaciones":0,"total_hab":4,"sumaseos":3,"repercusion":1443.8888888889,"nbtipo":"House Type Duplex","nbconservacion":"Good condition","exclu":0,"parking":2,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":23,"eninternet":1,"zonaauxiliar":"","urbanizacion":1,"destacado":1,"habdobles":4,"destestrella":0,"opcioncompra":0,"m_terraza":30,"interesante":0,"altitud":-0.94738136854414,"latitud":38.078988627854,"mls":0,"numfotos":24,"fotoletra":46,"keypromo":0,"fechacambio":"2025-06-10 13:07:24","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":285000,"aseos":1,"tipomensual":"MES","srvfotos":15,"soysrv":15,"ciudad":"Orihuela","zona":"Los Andenes","keyprov":4,"foto":"https:\/\/fotos15.apinmo.com\/8569\/23534390\/46-1.jpg","tituloauto":"House Type Duplex - Orihuela (Los Andenes) ","tituloDefecto":"House Type Duplex - Orihuela (Los Andenes) ","precioauto":"259.900 \u20ac","superficieauto":"180 m2","banyosauto":3,"fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/23534390\/46-1s.jpg","urlfichaauto":"ficha\/house-type-duplex\/orihuela\/los-andenes\/8569\/23534390\/en\/"}}};

    //ponemos el id del modulo destacado en concreto
    //xHaceRx poner que se mueva solo si lo tiene asi en opciones
    $(document).ready(function(){
        //carrusel destacados
        $('#modulo-destacados-1-2 .destacados-carrusel').carouFredSel({
            // width: '100%',
            items: {
                visible: visibleCarrusel,
                direction:"left", // right,left,up,bottom
                start: 1
            },
            scroll: {
                items: 1,
                duration: 1000,
                timeoutDuration: 4000 ,
                fx:'directscroll', // "scroll", "directscroll", "fade", "crossfade", "cover", "cover-fade", "uncover" or "uncover-fade".
                easing:'swing',   // swing, elastic, quadratic,cubic
                pauseOnHover:true,
                onBefore:function(data) {

                    if(typeof data.items == 'undefined' || typeof data.items.visible == 'undefined') return true;

                    var visibles = data.items.visible;

                    visibles.each(function(key, val){
                        mostrarFotosDestacados(key, val);
                    });

                }
            },
            auto:{
                play: false            },
            prev: '#modulo-destacados-1-2 #destacados-prev',
            next: '#modulo-destacados-1-2 #destacados-next',
            pagination: {
                container: '#modulo-destacados-1-2 #destacados-paginacion',
                deviation: 0
            }
        });

    });
</script><script>
    listados.paginacion = {"0":{"posicion":1,"elementos":12,"total":67},"1":{"cod_ofer":12341498,"keyacci":1,"banyos":0,"ref":"002507","nodisponible":0,"precioreal":12000,"preciotraspaso":0,"precioinmo":12000,"key_loca":41199,"key_zona":3355899,"key_tipo":2399,"m_parcela":0,"balcon":0,"m_cons":16,"m_uties":14,"conservacion":0,"calefacentral":0,"airecentral":0,"plaza_gara":0,"terraza":0,"ascensor":1,"montacargas":0,"muebles":0,"calefaccion":0,"aire_con":0,"primera_line":0,"piscina_com":0,"piscina_prop":0,"habitaciones":0,"total_hab":0,"sumaseos":0,"repercusion":750,"exclu":0,"parking":0,"todoext":0,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":0,"eninternet":1,"zonaauxiliar":"","urbanizacion":0,"destacado":0,"habdobles":0,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.94447072341758,"latitud":38.08245926525,"mls":0,"numfotos":6,"fotoletra":2,"keypromo":0,"fechacambio":"2025-05-07 15:31:54","fechacambisitemap":"2025-06-29 12:40:05","fechaact":"2025-05-07 15:31:54","fecha":"2020-09-24 00:00:00","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":3,"vistasdespejadas":0,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":0,"aseos":0,"tipomensual":"MES","keyagente":119409,"tour_virtual":0,"srvfotos":15,"soysrv":15,"agencia":"Promociones Apihogares S.l","ciudad":"Orihuela","zona":"Zona Centro","nbtipo":"Garage","nbconservacion":"None","keyprov":4,"nombreagente":"GESSICON ","emailagente":"apihogares@gmail.com","telefono1agente":638062858,"telefono2agente":669871698,"prefijotel1agente":34,"prefijotel2agente":34,"fotoagente":"img\/nofotoagente.jpg","foto":"https:\/\/fotos15.apinmo.com\/8569\/12341498\/2-1.jpg","tituloauto":"Garage - Orihuela (Zona Centro) , Built Surface 16m<sup>2<\/sup>, Lift.","tituloDefecto":"Garage - Orihuela (Zona Centro) ","precioauto":"For sale 12.000 \u20ac","precioauto2":"For sale 12.000 \u20ac","outletauto":"","rebajaauto":"","superficieauto":"16 mts","fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/12341498\/2-1s.jpg","mostrarHabitacionOrBanyo":true,"urlfichaauto":"ficha\/garage\/orihuela\/zona-centro\/8569\/12341498\/en\/","clasesPaginacionVista":"","agenciaWeb":"8569","agenciaPropiedad":8569,"telefonoagente":"+34 669 871 698","estadofichaLetrero":"Free","mostrarLetreroEstadoFicha":false},"2":{"cod_ofer":21848847,"keyacci":1,"banyos":2,"ref":"85696595","nodisponible":0,"precioreal":16500,"preciotraspaso":0,"precioinmo":16500,"key_loca":41199,"key_zona":3355899,"key_tipo":2599,"m_parcela":0,"balcon":1,"m_cons":328,"m_uties":15,"conservacion":0,"calefacentral":0,"airecentral":0,"plaza_gara":0,"terraza":1,"ascensor":1,"montacargas":0,"muebles":0,"calefaccion":0,"aire_con":0,"primera_line":0,"piscina_com":0,"piscina_prop":0,"habitaciones":3,"total_hab":3,"sumaseos":2,"repercusion":50.30487804878,"exclu":0,"parking":0,"todoext":0,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":0,"eninternet":1,"zonaauxiliar":"Orihuela Ciudad","urbanizacion":0,"destacado":0,"habdobles":0,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.94515255401112,"latitud":38.086861022877,"mls":0,"numfotos":5,"fotoletra":4,"keypromo":0,"fechacambio":"2025-05-07 15:31:54","fechacambisitemap":"2025-06-04 00:05:35","fechaact":"2025-05-07 15:31:54","fecha":"2024-05-28 20:30:26","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":3,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":0,"aseos":0,"tipomensual":"MES","keyagente":119154,"tour_virtual":0,"srvfotos":15,"soysrv":15,"agencia":"Promociones Apihogares S.l","ciudad":"Orihuela","zona":"Zona Centro","nbtipo":"Parking","nbconservacion":"None","keyprov":4,"nombreagente":"oficina ","telefono1agente":638062858,"telefono2agente":669871698,"prefijotel1agente":34,"prefijotel2agente":34,"fotoagente":"img\/nofotoagente.jpg","foto":"https:\/\/fotos15.apinmo.com\/8569\/21848847\/4-1.jpg","tituloauto":"Parking - Orihuela (Zona Centro) , Built Surface 328m<sup>2<\/sup>, 3 Bedrooms, 2 Bathrooms, Lift.","tituloDefecto":"Parking - Orihuela (Zona Centro) ","precioauto":"For sale 16.500 \u20ac","precioauto2":"For sale 16.500 \u20ac","outletauto":"","rebajaauto":"","superficieauto":"328 mts","fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/21848847\/4-1s.jpg","mostrarHabitacionOrBanyo":true,"urlfichaauto":"ficha\/parking\/orihuela\/zona-centro\/8569\/21848847\/en\/","clasesPaginacionVista":"","agenciaWeb":"8569","agenciaPropiedad":8569,"telefonoagente":"+34 669 871 698","estadofichaLetrero":"Free","mostrarLetreroEstadoFicha":false,"emailagente":""},"3":{"cod_ofer":27575322,"keyacci":1,"banyos":0,"ref":"00202602","nodisponible":0,"precioreal":18500,"preciotraspaso":0,"precioinmo":18500,"key_loca":41199,"key_zona":3352999,"key_tipo":2399,"m_parcela":0,"balcon":0,"m_cons":20,"m_uties":20,"conservacion":30,"calefacentral":0,"airecentral":0,"plaza_gara":2,"terraza":0,"ascensor":0,"montacargas":0,"muebles":0,"calefaccion":0,"aire_con":0,"primera_line":0,"piscina_com":0,"piscina_prop":0,"habitaciones":0,"total_hab":0,"sumaseos":0,"repercusion":925,"exclu":0,"parking":2,"todoext":0,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":0,"eninternet":1,"zonaauxiliar":"","urbanizacion":0,"destacado":0,"habdobles":0,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.94500073,"latitud":38.08404263,"mls":0,"numfotos":9,"fotoletra":3,"keypromo":0,"fechacambio":"2026-02-04 13:31:27","fechacambisitemap":"2026-01-02 11:36:07","fechaact":"2026-02-04 13:31:27","fecha":"2026-01-02 11:36:07","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":3,"vistasdespejadas":0,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":18900,"aseos":0,"tipomensual":"MES","keyagente":119409,"tour_virtual":0,"srvfotos":15,"soysrv":15,"agencia":"Promociones Apihogares S.l","ciudad":"Orihuela","zona":"Barrio de la Ocarasa","nbtipo":"Garage","nbconservacion":"Good condition","keyprov":4,"nombreagente":"GESSICON ","emailagente":"apihogares@gmail.com","telefono1agente":638062858,"telefono2agente":669871698,"prefijotel1agente":34,"prefijotel2agente":34,"fotoagente":"img\/nofotoagente.jpg","foto":"https:\/\/fotos15.apinmo.com\/8569\/27575322\/3-1.jpg","tituloauto":"Garage - Orihuela (Barrio de la Ocarasa) , Built Surface 20m<sup>2<\/sup>.","tituloDefecto":"Garage - Orihuela (Barrio de la Ocarasa) ","precioauto":"For sale 18.500 \u20ac","precioauto2":"For sale 18.500 \u20ac","outletauto":"18.900 \u20ac","rebajaauto":"- 2&#37;","superficieauto":"20 mts","fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/27575322\/3-1s.jpg","mostrarHabitacionOrBanyo":true,"urlfichaauto":"ficha\/garage\/orihuela\/barrio-de-la-ocarasa\/8569\/27575322\/en\/","clasesPaginacionVista":"","agenciaWeb":"8569","agenciaPropiedad":8569,"telefonoagente":"+34 669 871 698","estadofichaLetrero":"Free","mostrarLetreroEstadoFicha":false},"4":{"cod_ofer":27609111,"keyacci":6,"banyos":0,"ref":"003528","nodisponible":0,"precioreal":35000,"preciotraspaso":0,"precioinmo":35000,"key_loca":41199,"key_zona":3355899,"key_tipo":1299,"m_parcela":0,"balcon":0,"m_cons":140,"m_uties":122,"conservacion":30,"calefacentral":0,"airecentral":1,"plaza_gara":0,"terraza":0,"ascensor":0,"montacargas":0,"muebles":1,"calefaccion":1,"aire_con":0,"primera_line":0,"piscina_com":0,"piscina_prop":0,"habitaciones":0,"total_hab":0,"sumaseos":2,"repercusion":250,"exclu":0,"parking":0,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":714,"keycalefa":0,"eninternet":1,"zonaauxiliar":"","urbanizacion":0,"destacado":0,"habdobles":0,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.94935370914061,"latitud":38.08175880188,"mls":0,"numfotos":17,"fotoletra":7,"keypromo":0,"fechacambio":"2026-04-08 10:18:21","fechacambisitemap":"2026-01-08 11:17:29","fechaact":"2026-04-08 10:18:21","fecha":"2026-01-08 11:17:29","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":44000,"aseos":2,"tipomensual":"MES","keyagente":119409,"tour_virtual":0,"srvfotos":15,"soysrv":15,"agencia":"Promociones Apihogares S.l","ciudad":"Orihuela","zona":"Zona Centro","nbtipo":"Business Premise","nbconservacion":"Good condition","keyprov":4,"nombreagente":"GESSICON ","emailagente":"apihogares@gmail.com","telefono1agente":638062858,"telefono2agente":669871698,"prefijotel1agente":34,"prefijotel2agente":34,"fotoagente":"img\/nofotoagente.jpg","foto":"https:\/\/fotos15.apinmo.com\/8569\/27609111\/7-1.jpg","tituloauto":"Business Premise - Orihuela (Zona Centro) , Built Surface 140m<sup>2<\/sup>, 2 Toilets.","tituloDefecto":"Business Premise - Orihuela (Zona Centro) ","precioauto":"35.000 \u20ac - 714 \u20ac\/month","precioauto2":"35.000 \u20ac - 714 \u20ac\/month","outletauto":"44.000 \u20ac","rebajaauto":"- 20&#37;","superficieauto":"140 mts","fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/27609111\/7-1s.jpg","mostrarHabitacionOrBanyo":true,"urlfichaauto":"ficha\/business-premise\/orihuela\/zona-centro\/8569\/27609111\/en\/","clasesPaginacionVista":"","agenciaWeb":"8569","agenciaPropiedad":8569,"telefonoagente":"+34 669 871 698","estadofichaLetrero":"Free","mostrarLetreroEstadoFicha":false},"5":{"cod_ofer":12340765,"keyacci":1,"banyos":1,"ref":"001417","nodisponible":0,"precioreal":76999,"preciotraspaso":0,"precioinmo":76999,"key_loca":39399,"key_zona":39399,"key_tipo":6299,"m_parcela":0,"balcon":1,"m_cons":210,"m_uties":180,"conservacion":5,"calefacentral":0,"airecentral":0,"plaza_gara":2,"terraza":1,"ascensor":0,"montacargas":0,"muebles":1,"calefaccion":0,"aire_con":0,"primera_line":0,"piscina_com":0,"piscina_prop":0,"habitaciones":0,"total_hab":3,"sumaseos":2,"repercusion":366.6619047619,"exclu":0,"parking":2,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":0,"eninternet":1,"zonaauxiliar":"jacarilla","urbanizacion":0,"destacado":0,"habdobles":3,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.86831098591387,"latitud":38.062010481795,"mls":0,"numfotos":31,"fotoletra":14,"keypromo":0,"fechacambio":"2026-02-25 20:56:32","fechacambisitemap":"2025-02-27 02:18:18","fechaact":"2026-02-25 20:56:32","fecha":"2015-09-24 00:00:00","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":80000,"aseos":1,"tipomensual":"MES","keyagente":119408,"tour_virtual":0,"srvfotos":15,"soysrv":15,"agencia":"Promociones Apihogares S.l","ciudad":"Jacarilla","zona":"JACARILLA","nbtipo":"Village house","nbconservacion":"To refurbish","keyprov":4,"nombreagente":"JESSICA JESSICA","apellidosagente":"JESSICA","fotoagente":"img\/nofotoagente.jpg","foto":"https:\/\/fotos15.apinmo.com\/8569\/12340765\/14-1.jpg","tituloauto":"Village house - Jacarilla , Built Surface 210m<sup>2<\/sup>, 3 Bedrooms, 1 Bathrooms.","tituloDefecto":"Village house - Jacarilla (JACARILLA) ","precioauto":"For sale 76.999 \u20ac","precioauto2":"For sale 76.999 \u20ac","outletauto":"80.000 \u20ac","rebajaauto":"- 4&#37;","superficieauto":"210 mts","fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/12340765\/14-1s.jpg","mostrarHabitacionOrBanyo":true,"urlfichaauto":"ficha\/village-house\/jacarilla\/jacarilla\/8569\/12340765\/en\/","clasesPaginacionVista":"","agenciaWeb":"8569","agenciaPropiedad":8569,"telefonoagente":"","estadofichaLetrero":"Free","mostrarLetreroEstadoFicha":false,"emailagente":""},"6":{"cod_ofer":26770541,"keyacci":1,"banyos":2,"ref":"009999765","nodisponible":0,"precioreal":77999,"preciotraspaso":0,"precioinmo":77999,"key_loca":41199,"key_zona":3354599,"key_tipo":399,"m_parcela":0,"balcon":0,"m_cons":283,"m_uties":168,"conservacion":5,"calefacentral":0,"airecentral":0,"plaza_gara":0,"terraza":0,"ascensor":0,"montacargas":0,"muebles":0,"calefaccion":0,"aire_con":0,"primera_line":0,"piscina_com":0,"piscina_prop":0,"habitaciones":0,"total_hab":3,"sumaseos":3,"repercusion":275.6148409894,"exclu":0,"parking":0,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":0,"eninternet":1,"zonaauxiliar":"","urbanizacion":0,"destacado":0,"habdobles":3,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.92198694291835,"latitud":38.05920189429,"mls":0,"numfotos":20,"fotoletra":11,"keypromo":0,"fechacambio":"2026-02-04 19:54:38","fechacambisitemap":"2025-10-03 09:45:23","fechaact":"2026-02-04 19:54:38","fecha":"2025-10-03 09:45:23","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":0,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":85000,"aseos":1,"tipomensual":"MES","keyagente":119154,"tour_virtual":0,"srvfotos":15,"soysrv":15,"agencia":"Promociones Apihogares S.l","ciudad":"Orihuela","zona":"Hurchillo","nbtipo":"House","nbconservacion":"To refurbish","keyprov":4,"nombreagente":"oficina ","telefono1agente":638062858,"telefono2agente":669871698,"prefijotel1agente":34,"prefijotel2agente":34,"fotoagente":"img\/nofotoagente.jpg","foto":"https:\/\/fotos15.apinmo.com\/8569\/26770541\/11-1.jpg","tituloauto":"House - Orihuela (Hurchillo) , Built Surface 283m<sup>2<\/sup>, 3 Bedrooms, 2 Bathrooms.","tituloDefecto":"House - Orihuela (Hurchillo) ","precioauto":"For sale 77.999 \u20ac","precioauto2":"For sale 77.999 \u20ac","outletauto":"85.000 \u20ac","rebajaauto":"- 8&#37;","superficieauto":"283 mts","fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/26770541\/11-1s.jpg","mostrarHabitacionOrBanyo":true,"urlfichaauto":"ficha\/house\/orihuela\/hurchillo\/8569\/26770541\/en\/","clasesPaginacionVista":"","agenciaWeb":"8569","agenciaPropiedad":8569,"telefonoagente":"+34 669 871 698","estadofichaLetrero":"Free","mostrarLetreroEstadoFicha":false,"emailagente":""},"7":{"cod_ofer":12341515,"keyacci":1,"banyos":1,"ref":"002520","nodisponible":0,"precioreal":87999,"preciotraspaso":0,"precioinmo":87999,"key_loca":41199,"key_zona":3355899,"key_tipo":3399,"m_parcela":0,"balcon":1,"m_cons":101,"m_uties":80,"conservacion":50,"calefacentral":0,"airecentral":0,"plaza_gara":0,"terraza":0,"ascensor":0,"montacargas":0,"muebles":0,"calefaccion":1,"aire_con":1,"primera_line":0,"piscina_com":0,"piscina_prop":0,"habitaciones":0,"total_hab":2,"sumaseos":1,"repercusion":871.27722772277,"exclu":0,"parking":0,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":25,"eninternet":1,"zonaauxiliar":"","urbanizacion":0,"destacado":2,"habdobles":2,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.95066438137715,"latitud":38.083417983154,"mls":0,"numfotos":18,"fotoletra":13,"keypromo":0,"fechacambio":"2026-04-27 14:42:05","fechacambisitemap":"2025-02-27 02:18:28","fechaact":"2026-04-27 14:42:05","fecha":"2020-11-24 00:00:00","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":89900,"aseos":0,"tipomensual":"MES","keyagente":119409,"tour_virtual":0,"srvfotos":15,"soysrv":15,"agencia":"Promociones Apihogares S.l","ciudad":"Orihuela","zona":"Zona Centro","nbtipo":"Flat","nbconservacion":"Refurbished","keyprov":4,"nombreagente":"GESSICON ","emailagente":"apihogares@gmail.com","telefono1agente":638062858,"telefono2agente":669871698,"prefijotel1agente":34,"prefijotel2agente":34,"fotoagente":"img\/nofotoagente.jpg","foto":"https:\/\/fotos15.apinmo.com\/8569\/12341515\/13-1.jpg","tituloauto":"Flat - Orihuela (Zona Centro) , Built Surface 101m<sup>2<\/sup>, 2 Bedrooms, 1 Bathrooms.","tituloDefecto":"Flat - Orihuela (Zona Centro) ","precioauto":"For sale 87.999 \u20ac","precioauto2":"For sale 87.999 \u20ac","outletauto":"89.900 \u20ac","rebajaauto":"- 2&#37;","superficieauto":"101 mts","fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/12341515\/13-1s.jpg","mostrarHabitacionOrBanyo":true,"urlfichaauto":"ficha\/flat\/orihuela\/zona-centro\/8569\/12341515\/en\/","clasesPaginacionVista":"","agenciaWeb":"8569","agenciaPropiedad":8569,"telefonoagente":"+34 669 871 698","estadofichaLetrero":"Free","mostrarLetreroEstadoFicha":false},"8":{"cod_ofer":27761236,"keyacci":1,"banyos":2,"ref":"850000002","nodisponible":0,"precioreal":87999,"preciotraspaso":0,"precioinmo":87999,"key_loca":41199,"key_zona":3677699,"key_tipo":3499,"m_parcela":0,"balcon":0,"m_cons":85,"m_uties":80,"conservacion":40,"calefacentral":0,"airecentral":0,"plaza_gara":0,"terraza":0,"ascensor":0,"montacargas":0,"muebles":0,"calefaccion":0,"aire_con":0,"primera_line":0,"piscina_com":0,"piscina_prop":0,"habitaciones":0,"total_hab":3,"sumaseos":2,"repercusion":1035.2823529412,"exclu":0,"parking":0,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":3,"eninternet":1,"zonaauxiliar":"","urbanizacion":0,"destacado":0,"habdobles":3,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.96274225295923,"latitud":38.174067900966,"mls":0,"numfotos":27,"fotoletra":11,"keypromo":0,"fechacambio":"2026-03-23 11:59:02","fechacambisitemap":"2026-01-26 12:51:17","fechaact":"2026-03-23 11:59:02","fecha":"2026-01-26 12:51:17","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":99000,"aseos":0,"tipomensual":"MES","keyagente":119154,"tour_virtual":0,"srvfotos":15,"soysrv":15,"agencia":"Promociones Apihogares S.l","ciudad":"Orihuela","zona":"La Murada-Los Vicentes","nbtipo":"Ground floor apartment","nbconservacion":"Partially refurbished","keyprov":4,"nombreagente":"oficina ","telefono1agente":638062858,"telefono2agente":669871698,"prefijotel1agente":34,"prefijotel2agente":34,"fotoagente":"img\/nofotoagente.jpg","foto":"https:\/\/fotos15.apinmo.com\/8569\/27761236\/11-1.jpg","tituloauto":"Ground floor apartment - Orihuela (La Murada-Los Vicentes) , Built Surface 85m<sup>2<\/sup>, 3 Bedrooms, 2 Bathrooms.","tituloDefecto":"Ground floor apartment - Orihuela (La Murada-Los Vicentes) ","precioauto":"For sale 87.999 \u20ac","precioauto2":"For sale 87.999 \u20ac","outletauto":"99.000 \u20ac","rebajaauto":"- 11&#37;","superficieauto":"85 mts","fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/27761236\/11-1s.jpg","mostrarHabitacionOrBanyo":true,"urlfichaauto":"ficha\/ground-floor-apartment\/orihuela\/la-murada-los-vicentes\/8569\/27761236\/en\/","clasesPaginacionVista":"","agenciaWeb":"8569","agenciaPropiedad":8569,"telefonoagente":"+34 669 871 698","estadofichaLetrero":"Free","mostrarLetreroEstadoFicha":false,"emailagente":""},"9":{"cod_ofer":12341101,"keyacci":1,"banyos":1,"ref":"002111","nodisponible":0,"precioreal":89900,"preciotraspaso":0,"precioinmo":89900,"key_loca":41199,"key_zona":3720299,"key_tipo":7499,"m_parcela":0,"balcon":1,"m_cons":65,"m_uties":60,"conservacion":50,"calefacentral":0,"airecentral":0,"plaza_gara":0,"terraza":0,"ascensor":0,"montacargas":0,"muebles":1,"calefaccion":1,"aire_con":1,"primera_line":0,"piscina_com":1,"piscina_prop":0,"habitaciones":0,"total_hab":2,"sumaseos":1,"repercusion":1383.0769230769,"exclu":0,"parking":0,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":25,"eninternet":1,"zonaauxiliar":"La Campanets","urbanizacion":1,"destacado":1,"habdobles":2,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.89504526610114,"latitud":38.089090553509,"mls":0,"numfotos":11,"fotoletra":4,"keypromo":0,"fechacambio":"2026-04-14 02:39:09","fechacambisitemap":"2025-02-27 02:18:23","fechaact":"2026-04-14 02:39:09","fecha":"2016-02-18 00:00:00","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":95000,"aseos":0,"tipomensual":"MES","keyagente":119409,"tour_virtual":0,"srvfotos":15,"soysrv":15,"agencia":"Promociones Apihogares S.l","ciudad":"Orihuela","zona":"Molins-Campaneta-San Bartolom\u00e9","nbtipo":"Bungalow Ground Floor","nbconservacion":"Refurbished","keyprov":4,"nombreagente":"GESSICON ","emailagente":"apihogares@gmail.com","telefono1agente":638062858,"telefono2agente":669871698,"prefijotel1agente":34,"prefijotel2agente":34,"fotoagente":"img\/nofotoagente.jpg","foto":"https:\/\/fotos15.apinmo.com\/8569\/12341101\/4-1.jpg","tituloauto":"Bungalow Ground Floor - Orihuela (Molins-Campaneta-San Bartolom\u00e9) , Built Surface 65m<sup>2<\/sup>, 2 Bedrooms, 1 Bathrooms,...","tituloDefecto":"Bungalow Ground Floor - Orihuela (Molins-Campaneta-San Bartolom\u00e9) ","precioauto":"For sale 89.900 \u20ac","precioauto2":"For sale 89.900 \u20ac","outletauto":"95.000 \u20ac","rebajaauto":"- 5&#37;","superficieauto":"65 mts","fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/12341101\/4-1s.jpg","mostrarHabitacionOrBanyo":true,"urlfichaauto":"ficha\/bungalow-ground-floor\/orihuela\/molins-campaneta-san-bartolome\/8569\/12341101\/en\/","clasesPaginacionVista":"","agenciaWeb":"8569","agenciaPropiedad":8569,"telefonoagente":"+34 669 871 698","estadofichaLetrero":"Free","mostrarLetreroEstadoFicha":false},"10":{"cod_ofer":12340691,"keyacci":1,"banyos":1,"ref":"001251","nodisponible":0,"precioreal":94999,"preciotraspaso":0,"precioinmo":94999,"key_loca":42699,"key_zona":2188811,"key_tipo":3399,"m_parcela":0,"balcon":0,"m_cons":94.99,"m_uties":90,"conservacion":15,"calefacentral":0,"airecentral":0,"plaza_gara":0,"terraza":0,"ascensor":1,"montacargas":0,"muebles":1,"calefaccion":1,"aire_con":1,"primera_line":0,"piscina_com":0,"piscina_prop":0,"habitaciones":0,"total_hab":3,"sumaseos":1,"repercusion":1000.0947468155,"exclu":0,"parking":0,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":25,"eninternet":1,"zonaauxiliar":"","urbanizacion":0,"destacado":1,"habdobles":3,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.906975043,"latitud":38.113658715,"mls":0,"numfotos":20,"fotoletra":9,"keypromo":0,"fechacambio":"2026-04-20 19:55:39","fechacambisitemap":"2025-02-27 02:18:16","fechaact":"2026-04-20 19:55:39","fecha":"2010-05-24 00:00:00","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":98000,"aseos":0,"tipomensual":"MES","keyagente":119412,"tour_virtual":0,"srvfotos":15,"soysrv":15,"agencia":"Promociones Apihogares S.l","ciudad":"Redovan","zona":"Ayuntamiento","nbtipo":"Flat","nbconservacion":"Reformar Parcialment","keyprov":4,"nombreagente":"mary ","fotoagente":"img\/nofotoagente.jpg","foto":"https:\/\/fotos15.apinmo.com\/8569\/12340691\/9-1.jpg","tituloauto":"Flat - Redovan (Ayuntamiento) , Built Surface 94.99m<sup>2<\/sup>, 3 Bedrooms, 1 Bathrooms, Lift.","tituloDefecto":"Flat - Redovan (Ayuntamiento) ","precioauto":"For sale 94.999 \u20ac","precioauto2":"For sale 94.999 \u20ac","outletauto":"98.000 \u20ac","rebajaauto":"- 3&#37;","superficieauto":"94.99 mts","fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/12340691\/9-1s.jpg","mostrarHabitacionOrBanyo":true,"urlfichaauto":"ficha\/flat\/redovan\/ayuntamiento\/8569\/12340691\/en\/","clasesPaginacionVista":"","agenciaWeb":"8569","agenciaPropiedad":8569,"telefonoagente":"","estadofichaLetrero":"Free","mostrarLetreroEstadoFicha":false,"emailagente":""},"11":{"cod_ofer":12342018,"keyacci":1,"banyos":0,"ref":"002355","nodisponible":0,"precioreal":94999,"preciotraspaso":0,"precioinmo":94999,"key_loca":41199,"key_zona":3355899,"key_tipo":1199,"m_parcela":0,"balcon":0,"m_cons":140,"m_uties":130,"conservacion":0,"calefacentral":0,"airecentral":0,"plaza_gara":0,"terraza":0,"ascensor":1,"montacargas":0,"muebles":0,"calefaccion":0,"aire_con":0,"primera_line":0,"piscina_com":0,"piscina_prop":0,"habitaciones":1,"total_hab":1,"sumaseos":1,"repercusion":678.56428571429,"exclu":0,"parking":0,"todoext":0,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":0,"eninternet":1,"zonaauxiliar":"","urbanizacion":0,"destacado":0,"habdobles":0,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-0.94526124086761,"latitud":38.081479406344,"mls":0,"numfotos":14,"fotoletra":5,"keypromo":0,"fechacambio":"2025-11-05 14:07:03","fechacambisitemap":"2025-05-07 15:31:54","fechaact":"2025-11-05 14:07:03","fecha":"2019-10-07 00:00:00","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":0,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":99999,"aseos":1,"tipomensual":"MES","keyagente":119409,"tour_virtual":0,"srvfotos":15,"soysrv":15,"agencia":"Promociones Apihogares S.l","ciudad":"Orihuela","zona":"Zona Centro","nbtipo":"Office","nbconservacion":"None","keyprov":4,"nombreagente":"GESSICON ","emailagente":"apihogares@gmail.com","telefono1agente":638062858,"telefono2agente":669871698,"prefijotel1agente":34,"prefijotel2agente":34,"fotoagente":"img\/nofotoagente.jpg","foto":"https:\/\/fotos15.apinmo.com\/8569\/12342018\/5-1.jpg","tituloauto":"Office - Orihuela (Zona Centro) , Built Surface 140m<sup>2<\/sup>, 1 Room, Lift.","tituloDefecto":"Office - Orihuela (Zona Centro) ","precioauto":"For sale 94.999 \u20ac","precioauto2":"For sale 94.999 \u20ac","outletauto":"99.999 \u20ac","rebajaauto":"- 5&#37;","superficieauto":"140 mts","fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/12342018\/5-1s.jpg","mostrarHabitacionOrBanyo":true,"urlfichaauto":"ficha\/office\/orihuela\/zona-centro\/8569\/12342018\/en\/","clasesPaginacionVista":"","agenciaWeb":"8569","agenciaPropiedad":8569,"telefonoagente":"+34 669 871 698","estadofichaLetrero":"Free","mostrarLetreroEstadoFicha":false},"12":{"cod_ofer":12341144,"keyacci":1,"banyos":1,"ref":"002147","nodisponible":0,"precioreal":99000,"preciotraspaso":0,"precioinmo":99000,"key_loca":41199,"key_zona":3354899,"key_tipo":199,"m_parcela":300,"balcon":1,"m_cons":90,"m_uties":85,"conservacion":15,"calefacentral":0,"airecentral":0,"plaza_gara":2,"terraza":0,"ascensor":0,"montacargas":0,"muebles":0,"calefaccion":0,"aire_con":0,"primera_line":0,"piscina_com":0,"piscina_prop":0,"habitaciones":0,"total_hab":3,"sumaseos":1,"repercusion":1100,"exclu":0,"parking":2,"todoext":2,"distmar":0,"numagencia":8569,"estadoficha":1,"precioalq":0,"keycalefa":0,"eninternet":1,"zonaauxiliar":"","urbanizacion":0,"destacado":0,"habdobles":3,"destestrella":0,"opcioncompra":0,"m_terraza":0,"interesante":0,"altitud":-1.0147221767252,"latitud":38.143996901154,"mls":0,"numfotos":10,"fotoletra":10,"keypromo":0,"fechacambio":"2026-01-29 13:25:51","fechacambisitemap":"2025-02-27 02:18:23","fechaact":"2026-01-29 13:25:51","fecha":"2016-12-26 00:00:00","entidadbancaria":0,"vistasalmar":0,"grupomls":0,"numsucursal":8569,"energiarecibido":1,"vistasdespejadas":1,"grupoxmls":0,"grupomil":0,"x_personal":0,"mascotas":0,"aconsultar":0,"outlet":99000,"aseos":0,"tipomensual":"MES","keyagente":119409,"tour_virtual":0,"srvfotos":15,"soysrv":15,"agencia":"Promociones Apihogares S.l","ciudad":"Orihuela","zona":"La Matanza","nbtipo":"Terraced house","nbconservacion":"Reformar Parcialment","keyprov":4,"nombreagente":"GESSICON ","emailagente":"apihogares@gmail.com","telefono1agente":638062858,"telefono2agente":669871698,"prefijotel1agente":34,"prefijotel2agente":34,"fotoagente":"img\/nofotoagente.jpg","foto":"https:\/\/fotos15.apinmo.com\/8569\/12341144\/10-1.jpg","tituloauto":"Terraced house - Orihuela (La Matanza) , Built Surface 90m<sup>2<\/sup>, Plot Surface 300m<sup>2<\/sup>, 3 Bedrooms, 1 Bathrooms.","tituloDefecto":"Terraced house - Orihuela (La Matanza) ","precioauto":"For sale 99.000 \u20ac","precioauto2":"For sale 99.000 \u20ac","outletauto":"","rebajaauto":"","superficieauto":"90 mts","fotoprincipalauto":"https:\/\/fotos15.apinmo.com\/8569\/12341144\/10-1s.jpg","mostrarHabitacionOrBanyo":true,"urlfichaauto":"ficha\/terraced-house\/orihuela\/la-matanza\/8569\/12341144\/en\/","clasesPaginacionVista":"","agenciaWeb":"8569","agenciaPropiedad":8569,"telefonoagente":"+34 669 871 698","estadofichaLetrero":"Free","mostrarLetreroEstadoFicha":false}};
    var paginaActual = 1;
    var paginasTotales = 6;
</script>

<script src="js/modulos/paginacion/paginacion.js?x=20260506150310"></script>

<script>
    var FALTA_CIUDAD = 'City name missing';
    var FALTA_CALLE = 'Street name missing';
    var FALTA_PLANTA = 'You must point out the floor';
    var FALTA_HABITACIONES = 'You must point out the bedrooms';
    var VALORAMOS_TU_PROPIEDAD = 'Let\'s value your property';
    var ACEPTAR_PRIVACIDAD = 'You must accept the Privacy Policy and Terms of Use.';
    var FALTA_NOMBRE = 'You need to indicate the name';
    var EMAIL_INCORRECTO = 'Email is not valid.';
    var ERROR_TELEFONO = 'You must enter a valid phone number';
    //var TLF_OBLIGATORIO = '';
</script>

<script src="js/modulos/valoramostupiso/valoramostupiso.js?x=20260506150310"></script>
<script src="js/modulos/equipo/equipo.js?x=20260506150310"></script>

<script>

    $(document).ready(function(){
        //carrusel equipo
        $('#equipo-carrusel').carouFredSel({
            // width: '100%',
            items: {
                visible: 1,
                direction:"left", // right,left,up,bottom
                start: 0
            },
            scroll: {
                items: 1,
                duration: 1000,
                timeoutDuration: 4000 ,
                fx:'fade', // "scroll", "directscroll", "fade", "crossfade", "cover", "cover-fade", "uncover" or "uncover-fade".
                easing:'swing',   // falseswing, elastic, quadratic,cubic
                pauseOnHover:true
            },
            auto:{
                play: false            },
            prev: '#equipo-prev',
            next: '#equipo-next',
            pagination: {
                container: '#equipo-paginacion',
                deviation: 0
            }
        });

        $('#equipo-ver-mas-comerciales').click(function(){
            $("section#equipo-carrusel-peq").slideDown();
            $("section#equipo-carrusel-peq").css("display","flex");
            $('#equipo-ver-mas-comerciales').fadeOut(100);
        });

    });

</script>

<script>
    var EMAIL_INCORRECTO = 'Email is not valid.';
    var ACEPTAR_PRIVACIDAD = 'You must accept the Privacy Policy and Terms of Use.';
    var ACEPTAR_NEWSLETTERS = 'You must accept to receive newsletters';
    var POLITICA_PRIVACIDAD = 'Privacy Policy';
</script>

<script src="js/modulos/suscribete/suscribete.js?x=20260506150310"></script>
<script>
    var ACEPTAR_PRIVACIDAD = 'You must accept the Privacy Policy and Terms of Use.';
    var POLITICA_PRIVACIDAD = 'Privacy Policy';
    var ERROR_TLF = 'You must enter a valid phone number';
    var ERROR_EML = 'Wrong email address';
    var ERROR_NOM = 'Please fill in your name';
    var ERROR_CONSULTA = 'You must type your question';
    var TLF_OBLIGATORIO = '';
    var TEXTO_COOKIE_FIJO = '0';
</script>

<script src="js/modulos/pie/pie.js?x=20260506150310"></script>
<script src="js/suscribirsePush.js?x=20260506150310"></script>

<aside id="plugin-llamamos">
    <div>
        <i class="fas fa-comment fa-2x"></i>
        <span id="texto">QUESTION?</span>
    </div>
    <span id="tellamamos" class="plugin-llamamos-oculto">We'll call you back</span>
</aside>

<div id="plugin-llamamos-modal">
    <div id="plugin-llamamos-texto">
        Send this form with your name and phone number and we will contact you as soon as possible.    </div>
    <form id="plugin-llamamos-form">
        <label for="plugin-llamamos-nombre">Name:</label>
        <input type="text" id="plugin-llamamos-nombre" name="plugin-llamamos-nombre">
        <label for="plugin-llamamos-telefono">Telephone:</label>
        <input type="tel" id="plugin-llamamos-telefono" name="plugin-llamamos-telefono">
        <label for="plugin-llamamos-comentario">Questions, comments, contact schedule...</label>
        <textarea id="plugin-llamamos-comentario" name="plugin-llamamos-comentario"></textarea>

        <span class="textolegal" id="plugin-llamamos-textolegal">
            <div class="flex">
                <div class="bloque-checkbox">
                    <input type="checkbox" id="textolegal61" class="custom-checkbox">
                    <label for="textolegal61"></label>
                </div>
                <span class="textolegal" id="eltextolegal61">When you press the button “SEND” you confirm you’ve read, understood and accepted the conditions of our Privacy Policy shown in this LINK</span>
            </div>
        </span>
        <span class="resultadoInfo"></span>
        <button type="button" id="plugin-llamamos-enviar">
            Send        </button>
    </form>
</div><script>

    $(document).ready(function() {

        $("#plugin-llamamos").click(function () {
            modalNuestra('plugin-llamamos-modal', 'We\'ll call you back');

            $("#plugin-llamamos-textolegal #eltextolegal61").click(function () {
                modalNuestra('mytextoprivacidadFooter', POLITICA_PRIVACIDAD);
            });


            $("#plugin-llamamos-enviar").click(function () {

                var nombre = $("#plugin-llamamos-form #plugin-llamamos-nombre").val();
                if(nombre==""){
                    alerta("Introduce tu nombre");
                    return false;
                }
                var telefono = $("#plugin-llamamos-form #plugin-llamamos-telefono").val();
                if(telefono.length<9 || isNaN(telefono) ){
                    alerta("Introduce tu teléfono");
                    return false;
                }
                var comentario = $("#plugin-llamamos-form #plugin-llamamos-comentario").val();
                if(comentario==""){
                    alerta("Introduce tu comentario, duda u horario de contacto");
                    return false;
                }

                if(!document.getElementById('textolegal61').checked) {
                    alerta(ACEPTAR_PRIVACIDAD);
                    return false;
                }

                function enviandoTeLlamamos() {
                    $("#plugin-llamamos-form .resultadoInfo").text('');
                    $("#plugin-llamamos-form .resultadoInfo").removeClass('ok ko');
                    $("#plugin-llamamos-form .resultadoInfo").addClass("enviando");
                    $("#plugin-llamamos-form .resultadoInfo").fadeIn(50);
                };

                grecaptcha.ready(function () {
                    grecaptcha.execute('6LeFvHcUAAAAADkYzbLtZuO5lRdgl6gpLYovrRwl', {
                        action: 'llamamos'
                    }).then(function (token) {
                        $.post("modulos/__ajx/envios/enviosFormularios.php", {
                            beforeSend: enviandoTeLlamamos,
                            token: token,
                            nombre: nombre,
                            telefono: telefono,
                            comentario: comentario
                        }, function (data) {
                            $("#plugin-llamamos-form .resultadoInfo").removeClass('ok ko enviando');
                            if (data.resultado == false) {
                                $("#plugin-llamamos-form .resultadoInfo").addClass('ko');
                                $("#plugin-llamamos-form .resultadoInfo").text(data.mensaje);
                            }
                            else {
                                $("#plugin-llamamos-form .resultadoInfo").addClass('ok');
                                $("#plugin-llamamos-form .resultadoInfo").text(data.mensaje);
                            }

                            $("#plugin-llamamos-form .resultadoInfo").fadeIn();
                            setTimeout(function () {
                                $("#plugin-llamamos-form .resultadoInfo").fadeOut();
                            }, 4000);
                        }, "json");
                    });
                });
            });
        });
        var controlador=0;
        $(window).scroll(function() {
            if ($(document).height()-100 <= (($(window).height() + $(window).scrollTop()))) {
                if(controlador==0) {
                    $("#plugin-llamamos").fadeOut('fast');
                    controlador = 1;
                }
            }
            else {
                if(controlador==1) {
                    $("#plugin-llamamos").fadeIn('fast');
                    controlador=0;
                }

            }

        });


    });




</script><aside id="plugin-whatsapp" class="sombreado enviarPostHog" nombreEventoPostHog="Whatsapp" seccionPostHog="Contact">
        <i class="fab fa-whatsapp fa-2x"></i>
</aside>

<aside id="plugin-whatsapp-conversacion" clasS="sombreado">
    <div class="plugin-whatsapp-titulo">
        <span>WhatsApp</span>
        <span class="circle">X</span>
    </div>
    <div class="plugin-whatsapp-mensajes">
                <div>Hi!<span class="hora">18:22</span></div>
        <div>Click here to send us your questions through Whatsapp<span class="hora">18:22</span></div>
    </div>
    <div class="plugin-whatsapp-pie">
            <div class="emoji">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" id="smiley" x="3147" y="3209"><path fill-rule="evenodd" clip-rule="evenodd" d="M9.153 11.603c.795 0 1.44-.88 1.44-1.962s-.645-1.96-1.44-1.96c-.795 0-1.44.88-1.44 1.96s.645 1.965 1.44 1.965zM5.95 12.965c-.027-.307-.132 5.218 6.062 5.55 6.066-.25 6.066-5.55 6.066-5.55-6.078 1.416-12.13 0-12.13 0zm11.362 1.108s-.67 1.96-5.05 1.96c-3.506 0-5.39-1.165-5.608-1.96 0 0 5.912 1.055 10.658 0zM11.804 1.01C5.61 1.01.978 6.034.978 12.23s4.826 10.76 11.02 10.76S23.02 18.424 23.02 12.23c0-6.197-5.02-11.22-11.216-11.22zM12 21.355c-5.273 0-9.38-3.886-9.38-9.16 0-5.272 3.94-9.547 9.214-9.547a9.548 9.548 0 0 1 9.548 9.548c0 5.272-4.11 9.16-9.382 9.16zm3.108-9.75c.795 0 1.44-.88 1.44-1.963s-.645-1.96-1.44-1.96c-.795 0-1.44.878-1.44 1.96s.645 1.963 1.44 1.963z" fill="#7d8489"></path></svg>
            </div>
            <input id="mensajeWhatsapp" class="input-msg" name="input" placeholder="Write your message" autocomplete="off">
            <div class="photo">
                <i class="fas fa-camera"></i>
            </div>
            <button class="send">
                <div class="circle" id="envioWhatsapp">
                    <i class="fab fa-telegram-plane"></i>
                </div>
            </button>
    </div>

</aside>
<script>

    $(document).ready(function() {

        $("#plugin-whatsapp").click(function () {
            $("#plugin-whatsapp-conversacion").css("bottom","10px");
            //whatsapp://send?abid=username&text=Hello%2C%20World!
        });

        $("#envioWhatsapp").click(function () {
            var inmotelefono="34669871698";
            if($("#mensajeWhatsapp").val()!="") {
                if(actual == 'fichapropiedad.php')
                    var elMensaje = '"Ask from the web about reference ' + listados.fichapropiedad[1].ref + '": ' + $("#mensajeWhatsapp").val();
                else
                    var elMensaje = '"Ask from the web": ' + $("#mensajeWhatsapp").val();

                window.open("https://api.whatsapp.com/send?phone=" + inmotelefono + "&text=" + elMensaje, "", "_blank");
            }else
                alert("You can't send a blank message.");
        });



    });



    $(document).on('click', function (e) {
        if (($(e.target).closest("#plugin-whatsapp-conversacion").length === 0 && $(e.target).closest("#plugin-whatsapp").length === 0) || $(e.target).closest(".plugin-whatsapp-titulo .circle").length > 0) {
            $("#plugin-whatsapp-conversacion").css("bottom","-280px");
        }
    });


</script>    <script>
    </script>
<div class="modalesOcultas">
  <div id="mytextolegal">
      </div>

  <div id="mytextoprivacidadAlerta">
      <div class="rpgdPrivacid" style="margin-bottom: 20px;">
          <p><b>Responsable:</b> XXXXX</p>
          <p><b>Finalidad:</b> To send information about real estate that match the requirements of the client presented by filling this form.</p>
    <p><b>Legitimación:</b> To implement pre-contract measures to the clients request (budget request or information about our professional services).</p>
    <p><b>Destinatarios:</b> This data will arrive at the office and there is no expected data transfer if not for legal obligation.</p>
    <p><b>Derechos:</b> You may use your right to access, modify, suppress, oppose, transfer or withdraw your consent on your personal data through the email XXXXXX@XXXXXXX.es</p>
  </div>
    </div>

  <div id="mytextoprivacidadPublica">
      <div class="rpgdPrivacid" style="margin-bottom: 20px;">
          <p><b>Responsable:</b> XXXXX</p>
          <p><b>Finalidad:</b> To send information about your property to the real estate agency so it can evaluate if it will offer your property to its clients to try to sell or rent it.</p>
    <p><b>Legitimación:</b> The legitimacy is based on the consent you gave us when clicking the button “I accept the data protection policy”.</p>
    <p><b>Destinatarios:</b> The client’s data won’t be transferred to anyone, if not for legal obligation. The real estate’s data might be delivered to collaborating real estate agencies or published on web pages and real estate portals.</p>
    <p><b>Derechos:</b> You may use your right to access, modify, suppress, oppose, transfer or withdraw your consent on your personal data through the email XXXXXX@XXXXXXX.es</p>
  </div>
    </div>

  <div id="mytextoprivacidadFooter">
      <div class="rpgdPrivacid" style="margin-bottom: 20px;">
          <p><b>Responsable:</b> XXXXX</p>
          <p><b>Finalidad:</b> To handle information requests through the website, aiming to offer real estate professional services and to give information about what’s requested.</p>
    <p><b>Legitimación:</b> The legitimacy is based on the consent you gave us when clicking the button “I accept the data protection policy”.</p>
    <p><b>Destinatarios:</b> Your data won’t be transferred to anyone, if not for legal obligation.</p>
    <p><b>Derechos:</b> You may use your right to access, modify, suppress, oppose, transfer or withdraw your consent on your personal data through the email XXXXXX@XXXXXXX.es</p>
  </div>
    </div>

  <div id="mytextoprivacidadInfoProp">
      <div class="rpgdPrivacid" style="margin-bottom: 20px;">
          <p><b>Responsable:</b> XXXXX</p>
          <p><b>Finalidad:</b> To handle information requests through the website, aiming to offer real estate professional services and to give information about what’s requested.</p>
    <p><b>Legitimación:</b> The legitimacy is based on the consent you gave us when clicking the button “I accept the data protection policy”.</p>
    <p><b>Destinatarios:</b> Your data won’t be transferred to anyone, if not for legal obligation.</p>
    <p><b>Derechos:</b> You may use your right to access, modify, suppress, oppose, transfer or withdraw your consent on your personal data through the email XXXXXX@XXXXXXX.es</p>
  </div>
    </div>

  <div id="mytextocookies">
      </div>
</div>




<div class="modalesOcultas">
    <div id="modalContacto">
        <form id="formu7" class="formmodalContacto" method="get" enctype="text/plain">
            <div class="modalContactoInput">
                <span>Name</span>
                <input type="text" id="txtnombremodalContacto" name="txtnombremodalContacto">
            </div>
            <div class="modalContactoInput">
                <span>Email</span>
                <input type="text" id="txtemailmodalContacto" name="txtemailmodalContacto">
            </div>
            <div class="modalContactoInput">
                <span>Telephone</span>
                <input type="text"  id="txttelefonomodalContacto" name="txttelefonomodalContacto">
            </div>
            <div class="bloquemodalTextarea">
                <span>Notes</span>
                <textarea name="txtconsultamodalContacto" id="txtconsultamodalContacto"></textarea>
            </div>
            <div class="bloqueProponerCheckbox">
                <div class="bloque-checkbox">
                    <input type="checkbox" id="textolegal9" name="textolegal9" class="custom-checkbox">
                    <label for="textolegal9"></label>
                </div>
                <span onclick="modalNuestra('mytextoprivacidadInfoProp','Privacy Policy')">
                    When you press the button “SEND” you confirm you’ve read, understood and accepted the conditions of our Privacy Policy shown in this LINK                </span>
            </div>
        </form>
        <div class="bloquemodalContactoButton" id="bloquemodalContactoButton">
            <button type="button" id="enviarmodalContacto" class="enviarmodalContacto" onclick="enviacontactomodal();">Send</button>
            <div class="resultadomodalContacto"></div>
        </div>
    </div>
</div>

<script>

   function enviacontactomodal() {

        if (!$("#textolegal9").is(":checked")) {
            alerta(ACEPTAR_PRIVACIDAD);
            return false;
        }

        var nombre=$("#formu7 #txtnombremodalContacto").val();
        var email=$("#formu7 #txtemailmodalContacto").val();
        var telefono=$("#formu7 #txttelefonomodalContacto").val();
        var descripcion=$("#formu7 #txtconsultamodalContacto").val();

       if( !validarEmail( email) ){
           alerta($('#erroremail').val());
           return false;
       }

        function enviandoModalContacto(){$("#bloquemodalContactoButton .resultadomodalContacto").text('');$("#bloquemodalContactoButton .resultadomodalContacto").removeClass('ok ko');$("#bloquemodalContactoButton .enviarmodalContacto").addClass("enviando");$("#formu7 .resultadomodalContacto").fadeIn(50);};

        grecaptcha.ready(function() {
            grecaptcha.execute('6LeFvHcUAAAAADkYzbLtZuO5lRdgl6gpLYovrRwl', {action: 'enviarContactoModal'}).then(function(token) {
                $.post( "modulos/__ajx/envios/enviosFormularios.php", {beforeSend: enviandoModalContacto, token: token, nombre: nombre, email: email, telefono: telefono, descripcion: descripcion}, function( data ) {
                    $("#bloquemodalContactoButton .resultadomodalContacto").removeClass('ok ko enviando');
                    if(data.resultado==false) {
                        $("#bloquemodalContactoButton .resultadomodalContacto").addClass('ko');
                        $("#bloquemodalContactoButton .resultadomodalContacto").text(data.mensaje);
                    }
                    else {
                        $("#bloquemodalContactoButton .resultadomodalContacto").addClass('ok');
                        $("#bloquemodalContactoButton .resultadomodalContacto").text(data.mensaje);
                    }
                    $("#bloquemodalContactoButton .enviarmodalContacto").removeClass("enviando");



                    $("#bloquemodalContactoButton .enviarmodalContacto").slideUp();$("#bloquemodalContactoButton .resultadomodalContacto").slideDown();
                    setTimeout(function(){$("#bloquemodalContactoButton .resultadomodalContacto").slideUp();$("#bloquemodalContactoButton .enviarmodalContacto").slideDown(); }, 4000);


                },"json");
            });
        });
    };

    $("#eltextolegal9").click(function () {
        modalNuestra('mytextoprivacidadFooter',POLITICA_PRIVACIDAD);
    });

</script>

<div class="modalesOcultas">
    <div id="modalContactoPersonalizado">
        <form id="formu8" class="formmodalContactoPersonalizado" method="get" enctype="text/plain">
            <div class="modalContactoInputPersonalizado">
                <span>Name</span>
                <input type="text" id="txtnombremodalContactoPersonalizado" name="txtnombremodalContactoPersonalizado">
            </div>
            <div class="modalContactoInputPersonalizado">
                <span>Email</span>
                <input type="text" id="txtemailmodalContactoPersonalizado" name="txtemailmodalContactoPersonalizado">
            </div>
            <div class="modalContactoInputPersonalizado">
                <span>Telephone</span>
                <input type="text"  id="txttelefonomodalContactoPersonalizado" name="txttelefonomodalContactoPersonalizado">
            </div>
            <div class="bloquemodalTextareaPersonalizado">
                <span>Notes</span>
                <textarea name="txtconsultamodalContactoPersonalizado" id="txtconsultamodalContactoPersonalizado"></textarea>
            </div>
            <div class="bloqueModalCheckboxPersonalizado">
                <div class="bloque-checkbox">
                    <input type="checkbox" id="textolegal10" name="textolegal10" class="custom-checkbox">
                    <label for="textolegal10"></label>
                </div>
                <span onclick="modalNuestra('mytextoprivacidadInfoProp','Privacy Policy')">
                    When you press the button “SEND” you confirm you’ve read, understood and accepted the conditions of our Privacy Policy shown in this LINK                </span>
            </div>
        </form>
        <div class="bloquemodalContactoButtonPersonalizado" id="bloquemodalContactoButtonPersonalizado">
            <button type="button" id="enviarmodalContactoPersonalizado" class="enviarmodalContactoPersonalizado" onclick="enviacontactomodalPerso();">Send</button>
            <div class="resultadomodalContactoPersonalizado"></div>
        </div>
    </div>
</div>

<script>

    function enviacontactomodalPerso() {

        if (!$("#textolegal10").is(":checked")) {
            alerta(ACEPTAR_PRIVACIDAD);
            return false;
        }

        var nombre=$("#formu8 #txtnombremodalContactoPersonalizado").val();
        var email=$("#formu8 #txtemailmodalContactoPersonalizado").val();
        var telefono=$("#formu8 #txttelefonomodalContactoPersonalizado").val();
        var descripcion=$("#formu8 #txtconsultamodalContactoPersonalizado").val();
        var asunto=$(".modulo-personalizadobanner .parte-izq div#tituloAsunto").html();

        if( !validarEmail( email) ){
            alerta($('#erroremail').val());
            return false;
        }

        function enviandoModalContacto(){$("#bloquemodalContactoButtonPersonalizado .resultadomodalContactoPersonalizado").text('');$("#bloquemodalContactoButtonPersonalizado .resultadomodalContactoPersonalizado").removeClass('ok ko');$("#bloquemodalContactoButtonPersonalizado .enviarmodalContactoPersonalizado").addClass("enviando");$("#formu8 .resultadomodalContactoPersonalizado").fadeIn(50);};

        grecaptcha.ready(function() {
            grecaptcha.execute('6LeFvHcUAAAAADkYzbLtZuO5lRdgl6gpLYovrRwl', {action: 'enviarContactoModalPersonalizado'}).then(function(token) {
                $.post( "modulos/__ajx/envios/enviosFormularios.php", {beforeSend: enviandoModalContacto, token: token, nombre: nombre, email: email, telefono: telefono, descripcion: descripcion, asunto: asunto}, function( data ) {
                    $("#bloquemodalContactoButtonPersonalizado .resultadomodalContactoPersonalizado").removeClass('ok ko enviando');
                    if(data.resultado==false) {
                        $("#bloquemodalContactoButtonPersonalizado .resultadomodalContactoPersonalizado").addClass('ko');
                        $("#bloquemodalContactoButtonPersonalizado .resultadomodalContactoPersonalizado").text(data.mensaje);
                    }
                    else {
                        $("#bloquemodalContactoButtonPersonalizado .resultadomodalContactoPersonalizado").addClass('ok');
                        $("#bloquemodalContactoButtonPersonalizado .resultadomodalContactoPersonalizado").text(data.mensaje);
                    }
                    $("#bloquemodalContactoButtonPersonalizado .enviarmodalContactoPersonalizado").removeClass("enviando");



                    $("#bloquemodalContactoButtonPersonalizado .enviarmodalContactoPersonalizado").slideUp();$("#bloquemodalContactoButtonPersonalizado .resultadomodalContactoPersonalizado").slideDown();
                    setTimeout(function(){$("#bloquemodalContactoButtonPersonalizado .resultadomodalContactoPersonalizado").slideUp();$("#bloquemodalContactoButtonPersonalizado .enviarmodalContactoPersonalizado").slideDown(); }, 4000);


                },"json");
            });
        });
    };

    $("#eltextolegal9").click(function () {
        modalNuestra('mytextoprivacidadFooter',POLITICA_PRIVACIDAD);
    });

</script>
    <script>
        var textocookies = `<link rel=\"stylesheet\" href=\"css/estiloCookies.css\" type=\"text/css\">
<div class=\"grid-container\">
    <div>
        <H4><strong>DEFINITION OF COOKIES</strong></H4>
        <br/>

        <p>Cookies are identifiers that we send to your computer\'s hard drive through your Web browser so that our systems can recognize your browser and offer you certain services. In general, these technologies can serve very different purposes, for example, to recognize you as a user, obtain information about your browsing habits, or customize the way the content is displayed. This page uses different types of cookies. Some cookies are placed by third-party services that appear on our pages. Cookies can be:</p>

        <h3>Preference cookies</h3>
        <p>Preference cookies allow the website to remember information that changes the way the page behaves or the way it looks, such as your preferred language or the region in which you are located.</p>

        <h3>Statistics Cookies</h3>
        <p>Statistical cookies help web page owners understand how visitors interact with web pages by collecting and providing information anonymously. To disable Google Analytics cookies, you can install the Google Analytics opt-out for browsers add-on that will allow you not to send statistical information. It is available at the following link: https://tools.google.com/dlpage/gaoptout?hl=es</p>

        <h3>Marketing cookies</h3>
        <p>Marketing cookies are used to track visitors on web pages. The intention is to display ads that are relevant and attractive to the individual user, and therefore more valuable to publishers and third-party advertisers.</p>

        <p> </p>
        <H4><strong>HOW TO DISABLE COOKIES IN THE MAIN BROWSERS:</strong></H4>
        <br/>
        <p>It is normally possible to stop accepting browser Cookies, or stop accepting Cookies from a particular Service.</p>
        <p>All modern browsers allow you to change the cookie settings. These settings are usually found in the \'options\' or \'Preferences\' of your browser menu. You can also configure your browser or your email manager.</p>
        <p>The following provides guidance to the User on the steps to access the cookie configuration menu and, where appropriate, private browsing in each of the main browsers:</p>
        <p>Internet Explorer: Tools -> Internet Options -> Privacy -> Configuration. For more information, you can consult Microsoft support or browser Help.</p>
        <p>Firefox: Tools -> Options -> Privacy -> History -> Custom Settings. For more information, you can consult Mozilla support or browser Help.</p>
        <p>Chrome: Settings -> Show advanced options -> Privacy -> Content settings. For more information, you can consult Google support or browser Help.</p>
        <p>Safari: Preferences -> Security. For more information, you can consult Apple support or browser Help.</p>
        <p>What happens if Cookies are disabled?</p>
        <p>Some functionalities of the Services will be disabled.</p>

        <br/>


    </div>
    <div>


        <h3>Cookies used:</h3>
        <p>Next, we show you the cookies that this webpage uses:</p>

        <table border=\"0px\" cellpadding=\"0px\" cellspacing=\"0px\" style=\"width:100%\">
            <tbody>
            <tr>
                <td style=\"height:13px; width:89px\">
                    <p><strong>Name</strong></p>
                </td>
                <td style=\"height:13px; width:47px\">
                    <p><strong>Type</strong></p>
                </td>
                <td style=\"height:13px; width:246px\">
                    <p><strong>Description/Purpose</strong></p>
                </td>
                <td style=\"height:13px; width:132px\">
                    <p><strong>Duration</strong></p>
                </td>
                <td style=\"height:13px; width:85px\">
                    <p><strong>Owner</strong></p>
                </td>
                <td style=\"height:13px; width:85px\">
                    <p><strong>Accept</strong></p>
                </td>
            </tr>
            <tr>
                <td style=\"height:77px; width:89px\">
                    <p><strong>cookies_accepted,<br />
                        cookies_accepted_vdf,<br />
                        cookies_accepted_add_1,
                        cookies_accepted_metric,
                        cookies_accepted_google</strong></p>
                </td>
                <td style=\"height:77px; width:47px\">
                    <p>Technique</p>
                </td>
                <td style=\"height:77px; width:246px\">
                    <p>Enabling/disabling the cookie information bar and the selected cookies.</p>
                </td>
                <td style=\"height:77px; width:132px\">
                    <p>1 years from start, browser session.</p>
                </td>
                <td style=\"height:77px; width:85px\">
                    <p>Inmovilla</p>
                </td>
                <td style=\"height:77px; width:85px\"><input checked=\"checked\" disabled=\"disabled\" id=\"cookies_accepted_ca\" type=\"checkbox\" /> <span style=\"color: grey\">Cookie required</span></td>
            </tr>
            <tr>
                <td style=\"height:30px; width:89px\">
                    <p><strong>PHPSESSID</strong></p>
                </td>
                <td style=\"height:30px; width:47px\">
                    <p>Technique</p>
                </td>
                <td style=\"height:30px; width:246px\">
                    <p>Login information, for quick start page loading</p>
                </td>
                <td style=\"height:30px; width:132px\">
                    <p>Session</p>
                </td>
                <td style=\"height:30px; width:85px\">
                    <p>Inmovilla</p>
                </td>
                <td style=\"height:77px; width:85px\"><input checked=\"checked\" disabled=\"disabled\" id=\"cookies_accepted_phpsid\" type=\"checkbox\" /> <span style=\"color: grey\">Cookie required</span></td>
            </tr>
            <tr>
                <td style=\"height:30px; width:89px\">
                    <p><strong>vistas,<br />
                        favoritas,<br />
                        descartadas</strong></p>
                </td>
                <td style=\"height:30px; width:47px\">
                    <p>Preference cookies</p>
                </td>
                <td style=\"height:30px; width:246px\">
                    <p>This cookie is used to save the viewed, discarded or favorite properties.</p>
                </td>
                <td style=\"height:30px; width:132px\">
                    <p>Session</p>
                </td>
                <td style=\"height:30px; width:85px\">
                    <p>Inmovilla</p>
                </td>
                <td style=\"height:77px; width:85px\"><input id=\"cookies_accepted_vdf\" type=\"checkbox\" /></td>
            </tr>
            </tbody>
        </table>
        &nbsp;

        <h3><u>Third party cookies:</u></h3>
        &nbsp;

        <table border=\"0px\" cellpadding=\"0px\" cellspacing=\"0px\" style=\"width:100%\">
            <tbody>
            <tr>
                <td style=\"height:13px; width:89px\">
                    <p><strong>Name</strong></p>
                </td>
                <td style=\"height:13px; width:47px\">
                    <p><strong>Type</strong></p>
                </td>
                <td style=\"height:13px; width:246px\">
                    <p><strong>Descrption/Purpose</strong></p>
                </td>
                <td style=\"height:13px; width:132px\">
                    <p><strong>Duration</strong></p>
                </td>
                <td style=\"height:13px; width:85px\">
                    <p><strong>Owner</strong></p>
                </td>
                <td style=\"height:13px; width:85px\">
                    <p><strong>Accept</strong></p>
                </td>
            </tr>
            <tr>
                <td style=\"height:30px; width:89px\">
                    <p><strong>__cfduid</strong></p>
                </td>
                <td style=\"height:30px; width:47px\">
                    <p>Technique</p>
                </td>
                <td style=\"height:30px; width:246px\">
                    <p>It is established by the CloudFlare service to identify trusted web traffic. It does not correspond to any user id in the web application, nor does it save any personally identifiable data.</p>
                </td>
                <td style=\"height:30px; width:132px\">
                    <p>1 years from login</p>
                </td>
                <td style=\"height:30px; width:85px\">
                    <p>CloudFlare</p>
                </td>
                <td rowspan=\"2\" style=\"height:77px; width:85px\"><input id=\"cookies_accepted_add_1\" type=\"checkbox\" /></td>
            </tr>
            <tr>
                <td style=\"height:30px; width:89px\">
                    <p><strong>uvc</strong></p>
                </td>
                <td style=\"height:30px; width:47px\">
                    <p>Marketing</p>
                </td>
                <td style=\"height:30px; width:246px\">
                    <p>See policy: https://www.addtoany.com/buttons/faq/#gdpr and https://www.addtoany.com/privacy</p>
                </td>
                <td style=\"height:30px; width:132px\">
                    <p>1 day</p>
                </td>
                <td style=\"height:30px; width:85px\">
                    <p>Addtoany.com</p>
                </td>
                <!--td style=\"height:77px; width:85px\">
                            <input type=\"checkbox\" id=\"cookies_accepted_add_2\" checked=\"checked\"/> <span></span>
                        </td-->
            </tr>
            <!-- -->
            <tr>
                <td style=\"height:30px; width:89px\">
                    <p><strong>ANID, NID</strong></p>
                </td>
                <td style=\"height:30px; width:47px\">
                    <p>Marketing</p>
                </td>
                <td style=\"height:30px; width:246px\">
                    <p>For the count, by Google, of the number of users that use the maps.</p>
                </td>
                <td style=\"height:30px; width:132px\">
                    <p>6 Months</p>
                </td>
                <td style=\"height:30px; width:85px\">
                    <p>google maps</p>
                </td>
                <td style=\"height:77px; width:85px\"><input checked=\"checked\" disabled=\"disabled\" id=\"cookies_accepted_google1\" type=\"checkbox\" /> <span style=\"color: grey\">Cookie required</span></td>
            </tr>
            <tr>
                <td style=\"height:30px; width:89px\">
                    <p><strong>CONSENT</strong></p>
                </td>
                <td style=\"height:30px; width:47px\">
                    <p>Marketing</p>
                </td>
                <td style=\"height:30px; width:246px\">
                    <p>Technical cookie to control the acceptance of cookies.</p>
                </td>
                <td style=\"height:30px; width:132px\">
                    <p>Permanent</p>
                </td>
                <td style=\"height:30px; width:85px\">
                    <p>google.com</p>
                </td>
                <td style=\"height:77px; width:85px\"><input checked=\"checked\" disabled=\"disabled\" id=\"cookies_accepted_google2\" type=\"checkbox\" /> <span style=\"color: grey\">CCookie required</span></td>
            </tr>
            <tr>
                <td style=\"height:30px; width:89px\">
                    <p><strong>DV</strong></p>
                </td>
                <td style=\"height:30px; width:47px\">
                    <p>Msrketing</p>
                </td>
                <td style=\"height:30px; width:246px\">
                    <p>It is used by Google to provide services and extract anonymous information about browsing.</p>
                </td>
                <td style=\"height:30px; width:132px\">
                    <p>24 hours</p>
                </td>
                <td style=\"height:30px; width:85px\">
                    <p>google.com</p>
                </td>
                <td style=\"height:77px; width:85px\"><input checked=\"checked\" disabled=\"disabled\" id=\"cookies_accepted_google3\" type=\"checkbox\" /> <span style=\"color: grey\">Cookie required</span></td>
            </tr>
            <tr>
                <td style=\"height:30px; width:89px\">
                    <p><strong>1P_JAR</strong></p>
                </td>
                <td style=\"height:30px; width:47px\">
                    <p>Marketing</p>
                </td>
                <td style=\"height:30px; width:246px\">
                    <p>To personalize the ads according to the user\'s interests.</p>
                </td>
                <td style=\"height:30px; width:132px\">
                    <p>1 month</p>
                </td>
                <td style=\"height:30px; width:85px\">
                    <p>google.com</p>
                </td>
                <td style=\"height:77px; width:85px\"><input checked=\"checked\" disabled=\"disabled\" id=\"cookies_accepted_google4\" type=\"checkbox\" /> <span style=\"color: grey\">Cookie required</span></td>
            </tr>
            </tbody>
        </table>
    </div>
</div>`;
        var aceptar_todas = `Accept all`;
        var rechazar = `Reject`;
        var aceptar_selec = `Accept selected`;
        var cerrar = `Close`;
        var gestionarcookies = `Manage Cookies`;
        var textoaviso = `This site uses cookies.`;
        var politicacookies = `Cookies policy`;
    </script>
                    <script>
                    function textoBoton() {
                        if (document.getElementById('aceptarCookies_boton').innerHTML == aceptar_todas)
                            return aceptar_selec;

                        if (document.getElementById('aceptarCookies_boton').innerHTML == aceptar_selec)
                            return aceptar_todas;

                        if (document.getElementById('botonrechazar_aviso_entrada').innerHTML == rechazar)
                            return aceptar_selec;
                    }
                    function textoBottonGestionar() {
                        if (document.getElementById('cookieShowMoreInfo').innerHTML == gestionarcookies)
                            return cerrar;

                        if (document.getElementById('cookieShowMoreInfo').innerHTML == cerrar)
                            return gestionarcookies;
                    }
                </script>
                <div id='aviso-cookies'>
                    This site uses cookies.<br/>
                    <a id="aceptarCookies_boton" onclick='cookieHide()'>Accept all</a>
                    <a id="cookieShowMoreInfo" href='#' onclick='cookieShowMoreInfo(event,textocookies,textoBoton(),textoBottonGestionar())'>Manage Cookies</a>
                    <a id="rechazarCookies_boton" onclick='cookieHideRechazar()'>Reject</a>
                    <div id="mas-detalles-cookies"></div>
                </div>
              </body>
</html>